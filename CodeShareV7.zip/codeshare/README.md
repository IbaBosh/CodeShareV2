# CodeShare — Code à deux 🚀

Éditeur de code collaboratif en temps réel avec IA intégrée.

## Stack
- **Backend** : Express 5 + WebSocket (ws)
- **Frontend** : React 19 + Vite + TailwindCSS
- **DB** : PostgreSQL + Drizzle ORM
- **IA** : Google Gemini (serveur)
- **Langages** : Python (exécution réelle), JavaScript, HTML/CSS, TypeScript, Lua, Java, C++, PHP, Go, Rust

## Variables d'environnement

| Variable | Description |
|---|---|
| `DATABASE_URL` | URL PostgreSQL (ex: `postgresql://user:pass@host/db`) |
| `GEMINI_API_KEY` | Clé API Google Gemini (gratuite sur aistudio.google.com) |
| `NODE_ENV` | `production` sur Render |
| `PORT` | Port du serveur (Render le définit automatiquement) |

## Déploiement sur Render

### 1. Créer une base de données PostgreSQL
Dans Render > New > PostgreSQL → copier le `Internal Database URL`

### 2. Créer le service Web
- **Build Command** : `npm install && npm run build`
- **Start Command** : `npm run start`
- **Node Version** : 22

### 3. Variables d'environnement
Ajouter dans Environment :
- `DATABASE_URL` = URL de ta base Render
- `GEMINI_API_KEY` = ta clé Gemini
- `NODE_ENV` = production

### 4. Initialiser la base de données
Dans la console Shell de Render :
```bash
npx tsx scripts/init-db.ts
```

## Garder le site actif (UptimeRobot)

1. Va sur **uptimerobot.com** → New Monitor
2. Monitor Type : **HTTP(s)**
3. URL : `https://ton-app.onrender.com/ping`
4. Interval : **5 minutes**

Le endpoint `/ping` répond toujours `{"status":"ok"}`.

## Dev local
```bash
npm install
cp .env.example .env  # remplir DATABASE_URL et GEMINI_API_KEY
npx tsx scripts/init-db.ts  # créer les tables
npm run dev
```
