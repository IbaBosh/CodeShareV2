import express, { type Express } from "express";
import cors from "cors";
import path from "path";
import { fileURLToPath } from "url";
import sessionsRouter from "./routes/sessions";
import aiRouter from "./routes/ai";

const __dirname = path.dirname(fileURLToPath(import.meta.url));

const app: Express = express();

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Keepalive pour UptimeRobot
app.get("/ping", (_req, res) => res.json({ status: "ok", ts: Date.now() }));
app.get("/api/healthz", (_req, res) => res.json({ status: "ok" }));

app.use("/api", sessionsRouter);
app.use("/api", aiRouter);

// Serve frontend en production
const distPath = path.join(__dirname, "../../client/dist");
app.use(express.static(distPath));
app.get("*", (_req, res) => {
  res.sendFile(path.join(distPath, "index.html"));
});

export default app;
