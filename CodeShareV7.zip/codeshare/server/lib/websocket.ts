import { WebSocketServer, WebSocket } from "ws";
import http from "http";
import { db, sessionsTable } from "./db";
import { eq } from "drizzle-orm";
import { spawn, type ChildProcessWithoutNullStreams } from "child_process";
import { writeFile, unlink } from "fs/promises";
import { tmpdir } from "os";
import { join } from "path";
import { execSync } from "child_process";

function findPython(): string {
  const candidates = [
    "/nix/store/flbj8bq2vznkcwss7sm0ky8rd0k6kar7-python-wrapped-0.1.0/bin/python3",
    "python3",
    "python",
  ];
  for (const c of candidates) {
    try { execSync(`${c} --version`, { timeout: 3000, stdio: "pipe" }); return c; } catch {}
  }
  return "python3";
}

const PYTHON_BIN = findPython();
const INPUT_MARKER = "\x00INPUT_REQ\x00";

const PYTHON_WRAPPER = [
  "import sys as __sys, builtins as __builtins_mod",
  "def input(prompt=''):",
  "    __sys.stdout.write('\\x00INPUT_REQ\\x00' + str(prompt))",
  "    __sys.stdout.flush()",
  "    return __sys.stdin.readline().rstrip('\\n')",
  "__builtins_mod.input = input",
  "",
].join("\n");

interface Client {
  ws: WebSocket;
  sessionCode: string;
  hwid: string;
}

const clients: Client[] = [];

function getSessionClients(sessionCode: string) {
  return clients.filter((c) => c.sessionCode === sessionCode && c.ws.readyState === WebSocket.OPEN);
}

export function setupWebSocket(server: http.Server) {
  const wss = new WebSocketServer({ server, path: "/ws" });

  wss.on("connection", (ws) => {
    let sessionCode = "";
    let hwid = "";

    const exec = {
      proc: null as ChildProcessWithoutNullStreams | null,
      buf: "",
      waitingInput: false,
      tmpFile: "",
    };

    function send(obj: object) {
      if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(obj));
    }

    function flushOutput(text: string, isError = false) {
      if (text) send({ type: "output_chunk", text, isError });
    }

    function processBuffer() {
      const idx = exec.buf.indexOf(INPUT_MARKER);
      if (idx !== -1) {
        flushOutput(exec.buf.slice(0, idx));
        const prompt = exec.buf.slice(idx + INPUT_MARKER.length);
        exec.buf = "";
        exec.waitingInput = true;
        send({ type: "input_needed", prompt });
      } else {
        flushOutput(exec.buf);
        exec.buf = "";
      }
    }

    ws.on("message", async (rawMsg) => {
      try {
        const msg = JSON.parse(rawMsg.toString());

        // ── JOIN ──────────────────────────────────────────────────
        if (msg.type === "join") {
          sessionCode = msg.sessionCode as string;
          hwid = (msg.hwid as string) || "unknown";

          const existing = clients.findIndex((c) => c.ws === ws);
          if (existing !== -1) clients.splice(existing, 1);

          const othersInSession = getSessionClients(sessionCode);
          const isNewUser = othersInSession.length > 0 && !othersInSession.some((c) => c.hwid === hwid);

          clients.push({ ws, sessionCode, hwid });

          const [session] = await db.select().from(sessionsTable).where(eq(sessionsTable.code, sessionCode));
          if (!session) {
            // Session doesn't exist → send error so client redirects
            send({ type: "session_not_found" });
            return;
          }
          send({ type: "init", content: session.content, language: session.language });

          if (isNewUser) {
            for (const client of getSessionClients(sessionCode).filter((c) => c.ws !== ws)) {
              client.ws.send(JSON.stringify({ type: "user_joined" }));
            }
          }

          const count = getSessionClients(sessionCode).length;
          for (const client of getSessionClients(sessionCode)) {
            client.ws.send(JSON.stringify({ type: "user_count", count }));
          }
          console.log(`[WS] Client joined session ${sessionCode} (hwid=${hwid})`);
        }

        // ── CODE UPDATE ───────────────────────────────────────────
        if (msg.type === "code_update" && sessionCode) {
          const content: string = msg.content;
          await db.update(sessionsTable).set({ content, updatedAt: new Date() }).where(eq(sessionsTable.code, sessionCode));
          for (const client of getSessionClients(sessionCode)) {
            if (client.ws !== ws) client.ws.send(JSON.stringify({ type: "code_update", content }));
          }
        }

        // ── EXECUTE ───────────────────────────────────────────────
        if (msg.type === "execute") {
          if (exec.proc) {
            try { exec.proc.kill("SIGKILL"); } catch {}
            exec.proc = null;
          }
          if (exec.tmpFile) { unlink(exec.tmpFile).catch(() => {}); exec.tmpFile = ""; }
          exec.buf = "";
          exec.waitingInput = false;

          const userCode = (msg.code as string) ?? "";
          const tmpFile = join(tmpdir(), `cs_${Date.now()}_${Math.random().toString(36).slice(2)}.py`);
          exec.tmpFile = tmpFile;

          try {
            await writeFile(tmpFile, PYTHON_WRAPPER + "\n" + userCode, "utf8");
          } catch (err) {
            console.error("[WS] Failed to write tmp file", err);
            send({ type: "execution_done", exitCode: 1 });
            return;
          }

          const proc = spawn(PYTHON_BIN, [tmpFile], {
            stdio: ["pipe", "pipe", "pipe"],
          });
          exec.proc = proc;

          proc.stdout.on("data", (chunk: Buffer) => {
            if (exec.waitingInput) return;
            exec.buf += chunk.toString();
            processBuffer();
          });

          proc.stderr.on("data", (chunk: Buffer) => {
            flushOutput(chunk.toString(), true);
          });

          proc.on("close", (exitCode) => {
            exec.proc = null;
            exec.waitingInput = false;
            if (exec.buf) { flushOutput(exec.buf); exec.buf = ""; }
            send({ type: "execution_done", exitCode: exitCode ?? 0 });
            unlink(tmpFile).catch(() => {});
            exec.tmpFile = "";
          });

          proc.on("error", (err) => {
            console.error("[WS] Python spawn error", err);
            send({ type: "output_chunk", text: `Error: ${err.message}`, isError: true });
            send({ type: "execution_done", exitCode: 1 });
          });
        }

        // ── INPUT RESPONSE ────────────────────────────────────────
        if (msg.type === "input_response") {
          if (exec.proc && exec.proc.stdin && exec.waitingInput) {
            exec.waitingInput = false;
            exec.proc.stdin.write((msg.value as string) + "\n");
          }
        }

        // ── KILL ──────────────────────────────────────────────────
        if (msg.type === "kill_execution") {
          if (exec.proc) {
            try { exec.proc.kill("SIGKILL"); } catch {}
            exec.proc = null;
          }
          exec.waitingInput = false;
          exec.buf = "";
          send({ type: "execution_done", exitCode: -1 });
        }

      } catch (err) {
        console.error("[WS] Message error", err);
      }
    });

    ws.on("close", () => {
      const idx = clients.findIndex((c) => c.ws === ws);
      if (idx !== -1) clients.splice(idx, 1);
      if (exec.proc) { try { exec.proc.kill("SIGKILL"); } catch {} }
      if (exec.tmpFile) unlink(exec.tmpFile).catch(() => {});
      if (sessionCode) {
        const count = getSessionClients(sessionCode).length;
        for (const client of getSessionClients(sessionCode)) {
          client.ws.send(JSON.stringify({ type: "user_count", count }));
        }
      }
    });

    ws.on("error", (err) => console.error("[WS] Error", err));
  });

  console.log("[WS] WebSocket server running at /ws");
  return wss;
}
