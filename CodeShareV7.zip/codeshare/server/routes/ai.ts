import { Router } from "express";

const router = Router();

const GEMINI_MODEL = "gemini-2.5-flash";

async function callGemini(prompt: string): Promise<string> {
  const apiKey = process.env["GEMINI_API_KEY"];
  if (!apiKey) throw new Error("GEMINI_API_KEY not set");

  const url = `https://generativelanguage.googleapis.com/v1beta/models/${GEMINI_MODEL}:generateContent?key=${apiKey}`;
  const body = {
    contents: [{ role: "user", parts: [{ text: prompt }] }],
    generationConfig: { temperature: 0.3, maxOutputTokens: 2048 },
  };

  const res = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });

  if (!res.ok) {
    const errText = await res.text();
    throw new Error(`Gemini ${res.status}: ${errText.slice(0, 200)}`);
  }

  const data = await res.json() as any;
  return data?.candidates?.[0]?.content?.parts?.[0]?.text ?? "";
}

async function callGeminiChat(messages: { role: string; text: string }[]): Promise<string> {
  const apiKey = process.env["GEMINI_API_KEY"];
  if (!apiKey) throw new Error("GEMINI_API_KEY not set");

  const url = `https://generativelanguage.googleapis.com/v1beta/models/${GEMINI_MODEL}:generateContent?key=${apiKey}`;
  const contents = messages.map(m => ({
    role: m.role === "assistant" ? "model" : "user",
    parts: [{ text: m.text }],
  }));

  const res = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ contents, generationConfig: { temperature: 0.5, maxOutputTokens: 2048 } }),
  });

  if (!res.ok) {
    const errText = await res.text();
    throw new Error(`Gemini ${res.status}: ${errText.slice(0, 200)}`);
  }

  const data = await res.json() as any;
  return data?.candidates?.[0]?.content?.parts?.[0]?.text ?? "";
}

// Auto-fix: analyse une erreur et retourne explication + code corrigé
router.post("/ai/fix", async (req, res) => {
  try {
    const { code, error, language } = req.body as { code: string; error: string; language: string };

    const prompt = `Tu es un expert en programmation ${language}.
Analyse ce code et cette erreur. Réponds UNIQUEMENT avec du JSON valide, sans backticks, sans markdown.
Format exact: {"lines":[1],"explanation":"explication courte en français, 1-2 phrases max","fixedCode":"code complet corrigé"}

Code:
\`\`\`${language}
${code}
\`\`\`

Erreur:
${error}`;

    const raw = await callGemini(prompt);
    const jsonMatch = raw.match(/\{[\s\S]*\}/);
    if (!jsonMatch) {
      res.json({ explanation: raw.trim(), fixedCode: null, lines: [] });
      return;
    }
    const parsed = JSON.parse(jsonMatch[0]);
    res.json({ explanation: parsed.explanation ?? "", fixedCode: parsed.fixedCode ?? null, lines: parsed.lines ?? [] });
  } catch (err: any) {
    console.error("AI fix error:", err.message);
    res.status(500).json({ error: err.message });
  }
});

// Chat: multi-tour avec contexte du code actuel
router.post("/ai/chat", async (req, res) => {
  try {
    const { messages, currentCode, language } = req.body as {
      messages: { role: string; text: string }[];
      currentCode: string;
      language: string;
    };

    const systemText = `Tu es un assistant expert en programmation ${language} intégré dans un éditeur collaboratif. Tu réponds toujours en français.
Règles: commence directement sans salutation, sois concis et précis. Si tu fournis du code, utilise des blocs markdown. Si on te demande de modifier/améliorer le code, fournis le code complet modifié.

Code actuel de l'utilisateur:
\`\`\`${language}
${currentCode || "(vide)"}
\`\`\``;

    const allMessages = [
      { role: "user", text: systemText },
      { role: "model", text: "Compris. Je suis prêt à t'aider avec ton code." },
      ...messages.map(m => ({ role: m.role === "assistant" ? "model" : "user", text: m.text })),
    ];

    const response = await callGeminiChat(allMessages);
    const codeBlockMatch = response.match(/```(?:python|html|py|js|javascript|typescript|lua|java|cpp|php|go|rust)?\n?([\s\S]*?)```/);
    const codeBlock = codeBlockMatch ? codeBlockMatch[1].trim() : null;

    res.json({ response, codeBlock });
  } catch (err: any) {
    console.error("AI chat error:", err.message);
    res.status(500).json({ error: err.message });
  }
});

export default router;
