import { Router } from "express";
import { db, sessionsTable } from "../lib/db";
import { eq } from "drizzle-orm";
import { execSync } from "child_process";

function findPython(): string {
  const candidates = [
    "/nix/store/flbj8bq2vznkcwss7sm0ky8rd0k6kar7-python-wrapped-0.1.0/bin/python3",
    "python3", "python",
  ];
  for (const c of candidates) {
    try { execSync(`${c} --version`, { timeout: 3000, stdio: "pipe" }); return c; } catch {}
  }
  return "python3";
}

const router = Router();

const SUPPORTED_LANGUAGES = [
  "python", "html", "javascript", "typescript", "lua",
  "java", "cpp", "php", "go", "rust",
];

function generateCode(): string {
  return Array.from({ length: 10 }, () => Math.floor(Math.random() * 10)).join("");
}

const DEFAULT_CONTENT: Record<string, string> = {
  python: '# Code Python\nprint("Hello, world!")\n',
  html: '<!DOCTYPE html>\n<html lang="fr">\n<head>\n  <meta charset="UTF-8">\n  <title>Ma Page</title>\n  <style>\n    body { font-family: sans-serif; background: #0d0d1a; color: white; display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; }\n    h1 { color: #a78bfa; }\n  </style>\n</head>\n<body>\n  <h1>Hello, world!</h1>\n</body>\n</html>\n',
  javascript: '// JavaScript\nconsole.log("Hello, world!");\n\nconst nombres = [1, 2, 3, 4, 5];\nconst doubles = nombres.map(n => n * 2);\nconsole.log(doubles);\n',
  typescript: '// TypeScript\nconst message: string = "Hello, world!";\nconsole.log(message);\n\nfunction additionner(a: number, b: number): number {\n  return a + b;\n}\nconsole.log(additionner(3, 7));\n',
  lua: '-- Lua\nprint("Hello, world!")\n',
  java: '// Java\npublic class Main {\n    public static void main(String[] args) {\n        System.out.println("Hello, world!");\n    }\n}\n',
  cpp: '// C++\n#include <iostream>\nusing namespace std;\nint main() {\n    cout << "Hello, world!" << endl;\n    return 0;\n}\n',
  php: '<?php\necho "Hello, world!\\n";\n?>',
  go: '// Go\npackage main\nimport "fmt"\nfunc main() {\n    fmt.Println("Hello, world!")\n}\n',
  rust: '// Rust\nfn main() {\n    println!("Hello, world!");\n}\n',
};

router.post("/sessions", async (req, res) => {
  try {
    const { language } = req.body;
    if (!SUPPORTED_LANGUAGES.includes(language)) {
      res.status(400).json({ error: `Language must be one of: ${SUPPORTED_LANGUAGES.join(", ")}` });
      return;
    }

    let code = generateCode();
    for (let i = 0; i < 10; i++) {
      const existing = await db.select({ id: sessionsTable.id }).from(sessionsTable).where(eq(sessionsTable.code, code));
      if (existing.length === 0) break;
      code = generateCode();
    }

    const defaultContent = DEFAULT_CONTENT[language] ?? `// ${language}\n`;
    const [session] = await db.insert(sessionsTable).values({ code, language, content: defaultContent }).returning();

    res.status(201).json({
      id: session.id, code: session.code, language: session.language,
      content: session.content,
      createdAt: session.createdAt.toISOString(),
      updatedAt: session.updatedAt.toISOString(),
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to create session" });
  }
});

router.get("/sessions/:code", async (req, res) => {
  try {
    const { code } = req.params;
    const [session] = await db.select().from(sessionsTable).where(eq(sessionsTable.code, code));
    if (!session) { res.status(404).json({ error: "Session not found" }); return; }
    res.json({
      id: session.id, code: session.code, language: session.language,
      content: session.content,
      createdAt: session.createdAt.toISOString(),
      updatedAt: session.updatedAt.toISOString(),
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to get session" });
  }
});

router.delete("/sessions/:code", async (req, res) => {
  try {
    const { code } = req.params;
    const deleted = await db.delete(sessionsTable).where(eq(sessionsTable.code, code)).returning({ id: sessionsTable.id });
    if (deleted.length === 0) { res.status(404).json({ error: "Session not found" }); return; }
    res.json({ success: true });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to delete session" });
  }
});

export default router;
