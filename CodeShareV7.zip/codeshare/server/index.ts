import http from "http";
import app from "./app";
import { setupWebSocket } from "./lib/websocket";

const port = Number(process.env["PORT"] ?? 5000);
const server = http.createServer(app);
setupWebSocket(server);

server.listen(port, "0.0.0.0", () => {
  console.log(`[Server] Listening on port ${port}`);
});
