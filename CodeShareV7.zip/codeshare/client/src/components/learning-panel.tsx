import { useState } from "react";
import { X, ChevronRight, ChevronDown, Search } from "lucide-react";

interface Lesson { title: string; description: string; example: string; }
interface Category { emoji: string; name: string; lessons: Lesson[]; }

// ═══════════════════════════════════════════════════════
//  PYTHON
// ═══════════════════════════════════════════════════════
const PYTHON: Category[] = [
  { emoji: "🖨️", name: "Affichage & Saisie", lessons: [
    {
      title: "print() — afficher",
      description: "print() affiche du texte ou des valeurs dans la console. Tu peux y mettre plusieurs choses séparées par des virgules — Python ajoute un espace entre elles automatiquement. Les f-strings permettent d'insérer une variable directement dans le texte en écrivant f\"bonjour {variable}\".",
      example: `nom = "Ibo"
age = 17
print("Bonjour", nom)        # → Bonjour Ibo
print(f"Tu as {age} ans")    # → Tu as 17 ans
print(2 + 2)                 # → 4
print("A", "B", "C", sep="-")  # → A-B-C`,
    },
    {
      title: "input() — saisie utilisateur",
      description: "input() met le programme en pause et attend que l'utilisateur tape quelque chose au clavier. Il retourne TOUJOURS du texte (une chaîne de caractères). Si tu veux un nombre, tu dois le convertir avec int() ou float().",
      example: `prenom = input("Ton prénom : ")
print(f"Salut {prenom} !")

age = int(input("Ton âge : "))   # conversion texte → entier
if age >= 18:
    print("Tu es majeur")
else:
    print("Tu es mineur")`,
    },
    {
      title: "print() — formatage avancé",
      description: "Avec les f-strings, tu peux mettre des formats directement : .2f pour afficher 2 décimales, :>6 pour aligner à droite dans 6 caractères, :0>6 pour remplir de zéros.",
      example: `pi = 3.14159
prix = 9.5
print(f"Pi = {pi:.2f}")      # → Pi = 3.14
print(f"Prix: {prix:.2f}€")  # → Prix: 9.50€

score = 42
print(f"{score:>6}")   # →     42  (aligné à droite)
print(f"{score:0>6}")  # → 000042  (rempli de zéros)`,
    },
  ]},
  { emoji: "📦", name: "Variables & Types", lessons: [
    {
      title: "Variables — stocker des données",
      description: "Une variable, c'est comme une boîte avec un nom. Tu y mets une valeur et tu peux la réutiliser ou la modifier plus tard. Python devine le type automatiquement (int pour les entiers, float pour les décimaux, str pour le texte, bool pour vrai/faux, None pour rien).",
      example: `age = 17           # int — nombre entier
prix = 9.99        # float — nombre décimal
nom = "Alice"      # str — texte
actif = True       # bool — vrai/faux
vide = None        # None — absence de valeur

print(type(age))   # → <class 'int'>
print(type(nom))   # → <class 'str'>`,
    },
    {
      title: "Conversions de types",
      description: "int() convertit en entier (coupe les décimales), float() en décimal, str() en texte. C'est indispensable après input() qui retourne toujours du texte, même si l'utilisateur tape un chiffre.",
      example: `texte = "42"
n = int(texte)      # → 42  (entier)
d = float(texte)    # → 42.0 (décimal)
t = str(n)          # → "42" (texte)

# Après input(), toujours convertir !
x = int(input("Premier nombre : "))
y = int(input("Deuxième nombre : "))
print(f"Somme : {x + y}")`,
    },
    {
      title: "Opérateurs mathématiques",
      description: "+ addition, - soustraction, * multiplication, / division (donne toujours un float), // division entière (sans décimale), % modulo (reste de la division), ** puissance. Les opérateurs += -= *= permettent de modifier une variable sur elle-même.",
      example: `print(10 / 3)    # → 3.3333...
print(10 // 3)   # → 3       (partie entière)
print(10 % 3)    # → 1       (reste)
print(2 ** 8)    # → 256     (2 exposant 8)

x = 10
x += 5    # x vaut maintenant 15
x *= 2    # x vaut maintenant 30
print(x)  # → 30`,
    },
    {
      title: "Variables — bonnes pratiques",
      description: "Les noms de variables doivent commencer par une lettre ou un _, jamais par un chiffre. Évite les accents. Utilise le style snake_case (mots séparés par _) comme en Python standard.",
      example: `# ✅ Bons noms
age_utilisateur = 17
nom_complet = "Ibo Martin"
score_max = 100
est_actif = True

# ❌ Mauvais noms
# 2joueur = ...   (commence par un chiffre)
# mon-score = ... (tiret non autorisé)

print(nom_complet, score_max)  # → Ibo Martin 100`,
    },
  ]},
  { emoji: "🔀", name: "Conditions", lessons: [
    {
      title: "if / elif / else",
      description: "Le if teste une condition. Si c'est vrai, il exécute le code indenté en dessous. elif (sinon si) teste une autre condition. else (sinon) s'exécute si aucune condition n'est vraie. L'indentation (4 espaces) est OBLIGATOIRE en Python.",
      example: `note = 14

if note >= 16:
    print("Très bien")    # exécuté si note >= 16
elif note >= 12:
    print("Bien")         # si note >= 12 mais < 16
elif note >= 10:
    print("Passable")     # si note >= 10 mais < 12
else:
    print("Insuffisant")  # sinon

# → Bien`,
    },
    {
      title: "Opérateurs de comparaison",
      description: "== vérifie l'égalité (attention : = c'est l'affectation), != vérifie l'inégalité, > plus grand, < plus petit, >= plus grand ou égal, <= plus petit ou égal. Ces opérateurs retournent True ou False.",
      example: `x = 10
print(x == 10)   # → True
print(x == 5)    # → False
print(x != 5)    # → True
print(x > 7)     # → True
print(x <= 10)   # → True

# Comparaison chaînée (unique à Python !)
print(5 <= x <= 15)  # → True  (10 est entre 5 et 15)`,
    },
    {
      title: "and / or / not",
      description: "and vérifie que TOUTES les conditions sont vraies. or vérifie qu'AU MOINS UNE condition est vraie. not inverse la condition (True devient False et vice-versa).",
      example: `age = 20
permis = True

if age >= 18 and permis:
    print("Peut conduire")    # → Peut conduire

if age < 16 or not permis:
    print("Ne peut pas conduire")
else:
    print("Conditions remplies")  # → Conditions remplies`,
    },
    {
      title: "in / not in — chercher dans une collection",
      description: "in vérifie si une valeur est présente dans une liste, un texte, ou un dictionnaire. not in vérifie l'absence. C'est très pratique et lisible.",
      example: `fruits = ["pomme", "banane", "kiwi"]

if "pomme" in fruits:
    print("Pomme trouvée !")   # → Pomme trouvée !

if "mangue" not in fruits:
    print("Pas de mangue")     # → Pas de mangue

texte = "Bonjour le monde"
if "monde" in texte:
    print("Mot trouvé")        # → Mot trouvé`,
    },
    {
      title: "Condition en une ligne (ternaire)",
      description: "Python permet d'écrire une condition simple en une seule ligne : valeur_si_vrai if condition else valeur_si_faux. Très utile pour assigner une valeur selon une condition.",
      example: `age = 20
statut = "majeur" if age >= 18 else "mineur"
print(statut)  # → majeur

note = 14
emoji = "✅" if note >= 10 else "❌"
print(emoji)   # → ✅

# Equivalent à :
# if note >= 10:
#     emoji = "✅"
# else:
#     emoji = "❌"`,
    },
  ]},
  { emoji: "🔁", name: "Boucles", lessons: [
    {
      title: "for + range() — répéter N fois",
      description: "for avec range() répète du code un nombre précis de fois. range(n) génère les nombres de 0 à n-1. range(a, b) de a à b-1. range(a, b, pas) avec un pas (peut être négatif pour compter à rebours).",
      example: `for i in range(5):
    print(i, end=" ")    # → 0 1 2 3 4
print()

for i in range(1, 6):
    print(i, end=" ")    # → 1 2 3 4 5
print()

for i in range(10, 0, -2):
    print(i, end=" ")    # → 10 8 6 4 2
print()`,
    },
    {
      title: "for — parcourir une liste",
      description: "for peut parcourir directement les éléments d'une liste, un texte (lettre par lettre), ou tout autre objet itérable. enumerate() permet d'obtenir l'index en même temps que la valeur.",
      example: `fruits = ["pomme", "banane", "kiwi"]
for fruit in fruits:
    print(fruit)
# → pomme
# → banane
# → kiwi

# Avec l'index (commence à 0) :
for i, fruit in enumerate(fruits):
    print(f"{i+1}. {fruit}")
# → 1. pomme
# → 2. banane`,
    },
    {
      title: "while — répéter TANT QUE",
      description: "while répète le code tant qu'une condition est vraie. Attention à ne pas créer une boucle infinie ! Pense toujours à modifier la variable de condition à l'intérieur de la boucle.",
      example: `compte = 1
while compte <= 5:
    print(compte, end=" ")
    compte += 1    # ← IMPORTANT ! Sans ça, boucle infinie
print()
# → 1 2 3 4 5

# Demander jusqu'à bonne réponse :
while True:
    rep = input("Tape 'oui' pour continuer : ")
    if rep == "oui":
        break      # sort de la boucle
    print("Essaie encore...")`,
    },
    {
      title: "break — sortir d'une boucle",
      description: "break arrête immédiatement la boucle courante, même si la condition n'est pas terminée. Très utile quand tu cherches quelque chose et que tu veux arrêter dès que tu le trouves.",
      example: `nombres = [3, 7, 2, 9, 1, 5]
recherche = 9

for i, n in enumerate(nombres):
    if n == recherche:
        print(f"Trouvé {recherche} à l'index {i}")
        break    # → Trouvé 9 à l'index 3
    print(f"Pas {n}...")
# → Pas 3...
# → Pas 7...
# → Pas 2...
# → Trouvé 9 à l'index 3`,
    },
    {
      title: "continue — sauter une itération",
      description: "continue saute le reste du code de l'itération actuelle et passe directement à la suivante. Utile pour ignorer certains cas sans utiliser un if/else imbriqué.",
      example: `print("Nombres impairs entre 0 et 9 :")
for i in range(10):
    if i % 2 == 0:    # si le nombre est pair
        continue      # sauter les pairs
    print(i, end=" ")
# → 1 3 5 7 9

print()
print("Sans les multiples de 3 :")
for i in range(1, 11):
    if i % 3 == 0:
        continue
    print(i, end=" ")
# → 1 2 4 5 7 8 10`,
    },
  ]},
  { emoji: "🧩", name: "Fonctions", lessons: [
    {
      title: "def — créer une fonction",
      description: "Une fonction est un bloc de code réutilisable qui a un nom. Tu la définis une fois avec def et tu peux l'appeler autant de fois que tu veux. return envoie un résultat à celui qui a appelé la fonction.",
      example: `def saluer(prenom):
    return f"Bonjour {prenom} !"

def calculer_bmi(poids, taille):
    bmi = poids / (taille ** 2)
    return round(bmi, 1)

print(saluer("Ibo"))           # → Bonjour Ibo !
print(calculer_bmi(70, 1.75))  # → 22.9`,
    },
    {
      title: "Paramètres par défaut",
      description: "Tu peux donner une valeur par défaut à un paramètre en écrivant param=valeur dans la définition. Si l'utilisateur ne fournit pas ce paramètre, la valeur par défaut est utilisée. Les paramètres avec défaut doivent toujours être en dernier.",
      example: `def saluer(prenom, langue="fr"):
    if langue == "fr":
        return f"Bonjour {prenom}"
    elif langue == "en":
        return f"Hello {prenom}"
    return f"Hi {prenom}"

print(saluer("Ibo"))          # → Bonjour Ibo  (fr par défaut)
print(saluer("Ibo", "en"))    # → Hello Ibo
print(saluer("Ibo", "es"))    # → Hi Ibo`,
    },
    {
      title: "Fonctions avec plusieurs retours",
      description: "Une fonction Python peut retourner plusieurs valeurs en même temps en les séparant par des virgules. En réalité, Python retourne un tuple que tu peux décompacter directement.",
      example: `def statistiques(notes):
    return min(notes), max(notes), sum(notes) / len(notes)

notes = [14, 18, 11, 16, 12]
mini, maxi, moyenne = statistiques(notes)
print(f"Min: {mini}, Max: {maxi}, Moy: {moyenne:.1f}")
# → Min: 11, Max: 18, Moy: 14.2`,
    },
    {
      title: "lambda — fonction anonyme courte",
      description: "lambda crée une petite fonction en une seule ligne sans lui donner de nom. Parfait quand tu as besoin d'une fonction simple pour trier, filtrer ou transformer des données.",
      example: `double = lambda x: x * 2
print(double(5))   # → 10

# Trier une liste par longueur de mot
noms = ["Charlie", "Ali", "Bastien", "Eve"]
tries = sorted(noms, key=lambda n: len(n))
print(tries)   # → ['Ali', 'Eve', 'Charlie', 'Bastien']

# Utiliser avec map()
nombres = [1, 2, 3, 4]
carres = list(map(lambda x: x**2, nombres))
print(carres)  # → [1, 4, 9, 16]`,
    },
  ]},
  { emoji: "📋", name: "Listes", lessons: [
    {
      title: "Créer & accéder à une liste",
      description: "Une liste est une collection ordonnée d'éléments. L'index commence à 0. Un index négatif compte depuis la fin (-1 = dernier élément). Le slicing [a:b] extrait une portion de la liste.",
      example: `fruits = ["pomme", "banane", "kiwi", "mangue"]
print(fruits[0])      # → pomme   (premier)
print(fruits[-1])     # → mangue  (dernier)
print(fruits[1:3])    # → ['banane', 'kiwi']
print(fruits[:2])     # → ['pomme', 'banane']
print(len(fruits))    # → 4`,
    },
    {
      title: "Modifier une liste",
      description: "append() ajoute à la fin. insert(i, val) insère à une position. remove(val) supprime la première occurrence. pop() retire et retourne le dernier. sort() trie sur place. sorted() retourne une nouvelle liste triée.",
      example: `scores = [85, 92, 78]
scores.append(95)         # → [85, 92, 78, 95]
scores.insert(0, 100)     # → [100, 85, 92, 78, 95]
scores.remove(78)         # → [100, 85, 92, 95]
dernier = scores.pop()    # dernier = 95
scores.sort()             # → [85, 92, 100]
print(scores)`,
    },
    {
      title: "Méthodes utiles",
      description: "count() compte les occurrences d'un élément. index() trouve la position. reverse() inverse la liste. copy() fait une copie (important !). extend() ajoute tous les éléments d'une autre liste.",
      example: `nombres = [3, 1, 4, 1, 5, 9, 2, 6, 1]
print(nombres.count(1))    # → 3  (il y a trois 1)
print(nombres.index(5))    # → 4  (5 est à l'index 4)

a = [1, 2, 3]
b = [4, 5, 6]
a.extend(b)
print(a)   # → [1, 2, 3, 4, 5, 6]

# Copie correcte (pas juste = !)
c = a.copy()`,
    },
    {
      title: "List comprehension — liste express",
      description: "La compréhension de liste permet de créer une liste en une seule ligne élégante. C'est beaucoup plus court qu'une boucle for classique. Tu peux aussi ajouter un filtre avec if.",
      example: `# Carré des nombres de 1 à 5
carres = [x**2 for x in range(1, 6)]
print(carres)    # → [1, 4, 9, 16, 25]

# Seulement les nombres pairs
pairs = [x for x in range(20) if x % 2 == 0]
print(pairs)     # → [0, 2, 4, 6, 8, 10, 12, 14, 16, 18]

# Mettre des mots en majuscules
mots = ["bonjour", "monde", "python"]
majus = [m.upper() for m in mots]
print(majus)     # → ['BONJOUR', 'MONDE', 'PYTHON']`,
    },
  ]},
  { emoji: "📖", name: "Dictionnaires", lessons: [
    {
      title: "Créer & accéder",
      description: "Un dictionnaire stocke des paires clé:valeur. L'accès se fait par la clé (comme un vrai dictionnaire avec des mots). get() est plus sûr car il retourne None (ou une valeur par défaut) si la clé n'existe pas.",
      example: `joueur = {
    "nom": "Ibo",
    "score": 1500,
    "niveau": 3,
    "actif": True
}

print(joueur["nom"])             # → Ibo
print(joueur["score"])           # → 1500
print(joueur.get("rang", 0))     # → 0  (pas de "rang", défaut = 0)

joueur["score"] = 1600           # modifier
joueur["vies"] = 3               # ajouter
print(joueur["score"])           # → 1600`,
    },
    {
      title: "Parcourir un dictionnaire",
      description: "keys() retourne les clés, values() retourne les valeurs, items() retourne les paires clé-valeur (le plus utilisé). On peut aussi vérifier si une clé existe avec in.",
      example: `stock = {"pommes": 5, "bananes": 3, "kiwis": 8}

# Parcourir les paires clé-valeur
for article, quantite in stock.items():
    print(f"{article}: {quantite} en stock")
# → pommes: 5 en stock
# → bananes: 3 en stock

if "pommes" in stock:
    print("On a des pommes !")   # → On a des pommes !

del stock["bananes"]    # supprimer une clé
print(list(stock.keys()))  # → ['pommes', 'kiwis']`,
    },
    {
      title: "Dictionnaire — méthodes utiles",
      description: "update() fusionne deux dictionnaires. pop() retire une clé et retourne sa valeur. len() compte le nombre de paires. La compréhension de dictionnaire fonctionne comme pour les listes.",
      example: `infos = {"nom": "Ibo", "age": 17}
plus = {"ville": "Paris", "age": 18}
infos.update(plus)   # merge, age est mis à jour
print(infos)
# → {'nom': 'Ibo', 'age': 18, 'ville': 'Paris'}

val = infos.pop("ville")   # retire et retourne
print(val)   # → Paris

# Compréhension de dictionnaire
carres = {n: n**2 for n in range(1, 6)}
print(carres)  # → {1: 1, 2: 4, 3: 9, 4: 16, 5: 25}`,
    },
  ]},
  { emoji: "🔤", name: "Chaînes de texte", lessons: [
    {
      title: "Méthodes de base",
      description: "upper() passe en majuscules, lower() en minuscules, capitalize() met la première lettre en majuscule. strip() supprime les espaces en début et fin. replace() remplace un texte par un autre.",
      example: `texte = "  Bonjour Monde  "
print(texte.strip())         # → "Bonjour Monde"
print(texte.lower())         # → "  bonjour monde  "
print(texte.upper())         # → "  BONJOUR MONDE  "
print(texte.strip().replace("Monde", "Python"))
# → "Bonjour Python"

titre = "python est cool"
print(titre.capitalize())   # → "Python est cool"
print(titre.title())        # → "Python Est Cool"`,
    },
    {
      title: "split() / join() — couper et coller",
      description: "split() découpe un texte en liste selon un séparateur (espace par défaut). join() fait l'inverse : assemble une liste en texte avec un séparateur. Très utile pour traiter des données CSV ou des phrases.",
      example: `phrase = "Python est super cool"
mots = phrase.split()   # → ['Python', 'est', 'super', 'cool']
print(mots[0])          # → Python

csv = "Alice,Bob,Charlie"
noms = csv.split(",")   # → ['Alice', 'Bob', 'Charlie']

# Rejoindre avec un autre séparateur
print(" | ".join(noms))   # → Alice | Bob | Charlie
print("-".join(mots))     # → Python-est-super-cool`,
    },
    {
      title: "find() / count() / startswith()",
      description: "find() retourne l'index de la première occurrence (ou -1 si absent). count() compte les occurrences. startswith() et endswith() vérifient le début ou la fin. in vérifie simplement la présence.",
      example: `texte = "Bonjour, Python est génial !"
print(texte.find("Python"))        # → 9  (index où ça commence)
print(texte.find("Java"))          # → -1 (pas trouvé)
print(texte.count("o"))            # → 2  (nombre de 'o')
print(texte.startswith("Bonjour")) # → True
print(texte.endswith("!"))         # → True

if "Python" in texte:
    print("Python est mentionné")  # → Python est mentionné`,
    },
    {
      title: "Formatage avec f-strings",
      description: "Les f-strings (f\"...\") sont la façon moderne de formater du texte en Python. Tu mets n'importe quelle expression entre {} et Python l'évalue. Tu peux ajouter des formats comme :.2f pour les décimales.",
      example: `nom = "Ibo"
age = 17
pi = 3.14159

print(f"Nom: {nom}, Age: {age}")    # → Nom: Ibo, Age: 17
print(f"Pi = {pi:.2f}")            # → Pi = 3.14
print(f"Pi = {pi:.4f}")            # → Pi = 3.1416
print(f"Double: {age * 2}")        # → Double: 34
print(f"{'centré':^20}")           # →        centré
print(f"{nom!r}")                  # → 'Ibo' (repr)`,
    },
  ]},
  { emoji: "📂", name: "Tuples & Sets", lessons: [
    {
      title: "Tuple — liste immuable",
      description: "Un tuple ressemble à une liste mais on ne peut PAS le modifier après création. Utilise-le quand les données ne doivent pas changer (coordonnées, couleur RGB, etc.). Plus rapide et plus sûr qu'une liste.",
      example: `point = (3, 7)
couleur = (255, 128, 0)   # RGB orange
print(point[0])    # → 3
print(point[1])    # → 7

# Décompactage (unpacking)
x, y = point
print(f"x={x}, y={y}")   # → x=3, y=7

r, g, b = couleur
print(f"Rouge={r}")       # → Rouge=255

# Les tuples peuvent être des clés de dictionnaire
positions = {(0,0): "origine", (1,0): "droite"}`,
    },
    {
      title: "Set — ensemble sans doublons",
      description: "Un set est une collection sans doublons et sans ordre. Parfait pour enlever les doublons d'une liste ou tester rapidement si un élément est présent. Les opérations d'ensemble (union, intersection, différence) sont très rapides.",
      example: `# Enlever les doublons d'une liste
nombres = [1, 2, 2, 3, 3, 3, 4]
uniques = set(nombres)
print(uniques)     # → {1, 2, 3, 4} (ordre variable)

# Opérations d'ensemble
a = {1, 2, 3, 4}
b = {3, 4, 5, 6}
print(a & b)   # → {3, 4}   intersection
print(a | b)   # → {1,2,3,4,5,6}  union
print(a - b)   # → {1, 2}   différence`,
    },
  ]},
  { emoji: "⚠️", name: "Gestion d'erreurs", lessons: [
    {
      title: "try / except — attraper les erreurs",
      description: "Sans try/except, une erreur fait planter tout le programme. Avec try/except, tu attrapes l'erreur et tu peux réagir proprement. Tu peux spécifier le type d'erreur (ValueError, ZeroDivisionError, etc.) pour réagir différemment.",
      example: `try:
    n = int(input("Entier : "))   # peut échouer si non-numérique
    résultat = 100 / n             # peut échouer si n = 0
    print(f"100 / {n} = {résultat}")
except ValueError:
    print("Ce n'est pas un entier !")
except ZeroDivisionError:
    print("Division par zéro impossible !")
except Exception as e:
    print(f"Erreur inattendue : {e}")
finally:
    print("Fin du programme")   # toujours exécuté`,
    },
    {
      title: "raise — déclencher une erreur",
      description: "Tu peux toi-même déclencher une erreur avec raise. Utile pour valider des données dans tes fonctions et prévenir l'utilisateur d'un mauvais usage.",
      example: `def diviser(a, b):
    if b == 0:
        raise ValueError("Le diviseur ne peut pas être zéro !")
    return a / b

def age_valide(age):
    if not isinstance(age, int):
        raise TypeError("L'âge doit être un entier")
    if age < 0 or age > 150:
        raise ValueError(f"Âge {age} invalide")
    return True

try:
    diviser(10, 0)
except ValueError as e:
    print(e)   # → Le diviseur ne peut pas être zéro !`,
    },
  ]},
  { emoji: "🛠️", name: "Fonctions intégrées", lessons: [
    {
      title: "Fonctions essentielles",
      description: "Python a de nombreuses fonctions disponibles directement sans import. len() compte les éléments, range() génère une séquence, enumerate() ajoute un index, zip() combine des listes, sorted() trie.",
      example: `# len() — longueur
print(len("Bonjour"))   # → 7
print(len([1, 2, 3]))   # → 3

# zip() — combiner deux listes en parallèle
noms = ["Alice", "Bob", "Charlie"]
notes = [15, 12, 18]
for nom, note in zip(noms, notes):
    print(f"{nom}: {note}/20")
# → Alice: 15/20
# → Bob: 12/20
# → Charlie: 18/20`,
    },
    {
      title: "map() / filter() / reduce()",
      description: "map() applique une fonction à chaque élément d'une liste. filter() garde seulement les éléments qui passent un test. reduce() (dans functools) réduit une liste à une seule valeur. Ces fonctions fonctionnent bien avec les lambdas.",
      example: `nombres = [1, 2, 3, 4, 5]

# map : appliquer une fonction à chaque élément
doubles = list(map(lambda x: x * 2, nombres))
print(doubles)   # → [2, 4, 6, 8, 10]

# filter : garder ceux qui passent le test
pairs = list(filter(lambda x: x % 2 == 0, nombres))
print(pairs)     # → [2, 4]

# max, min, sum
print(max(nombres))   # → 5
print(min(nombres))   # → 1
print(sum(nombres))   # → 15`,
    },
    {
      title: "sorted() et key=",
      description: "sorted() retourne une nouvelle liste triée sans modifier l'originale. Le paramètre key= permet de définir selon quoi trier. reverse=True pour trier dans l'ordre décroissant.",
      example: `noms = ["Charlie", "Alice", "Bob", "Eve"]

# Tri alphabétique normal
print(sorted(noms))
# → ['Alice', 'Bob', 'Charlie', 'Eve']

# Tri par longueur du nom
print(sorted(noms, key=len))
# → ['Bob', 'Eve', 'Alice', 'Charlie']

# Tri décroissant par longueur
print(sorted(noms, key=len, reverse=True))
# → ['Charlie', 'Alice', 'Bob', 'Eve']

notes = [14, 8, 18, 11, 16]
print(sorted(notes, reverse=True))
# → [18, 16, 14, 11, 8]`,
    },
  ]},
  { emoji: "🎲", name: "Module random", lessons: [
    {
      title: "Génération aléatoire",
      description: "Le module random permet de générer des nombres aléatoires. randint(a, b) donne un entier entre a et b inclus. choice() choisit un élément au hasard dans une liste. shuffle() mélange une liste.",
      example: `import random

# Nombre entier entre 1 et 6 (dé)
de = random.randint(1, 6)
print(f"Dé : {de}")         # → Dé : (1 à 6)

# Choisir un élément au hasard
fruits = ["pomme", "banane", "kiwi", "mangue"]
print(random.choice(fruits)) # → un fruit au hasard

# Mélanger une liste
cartes = list(range(1, 14))
random.shuffle(cartes)
print(cartes[:5])   # → 5 cartes dans un ordre aléatoire`,
    },
  ]},
  { emoji: "🏗️", name: "Classes & POO", lessons: [
    {
      title: "__init__ — le constructeur",
      description: "Une classe est un moule pour créer des objets. __init__ est la méthode appelée automatiquement quand on crée un objet. self représente l'objet lui-même. Les attributs (self.nom) stockent les données de l'objet.",
      example: `class Chien:
    def __init__(self, nom, race):
        self.nom = nom
        self.race = race
        self.energie = 100

    def aboyer(self):
        return f"{self.nom}: Wouf !"

    def manger(self, quantite):
        self.energie += quantite

rex = Chien("Rex", "Berger")
print(rex.aboyer())      # → Rex: Wouf !
rex.manger(20)
print(rex.energie)       # → 120`,
    },
    {
      title: "Héritage — étendre une classe",
      description: "L'héritage permet à une classe enfant de reprendre toutes les fonctionnalités d'une classe parente et d'en ajouter ou modifier. super().__init__() appelle le constructeur du parent.",
      example: `class Animal:
    def __init__(self, nom):
        self.nom = nom

    def parler(self):
        return f"{self.nom} fait un bruit"

class Chat(Animal):   # Chat hérite d'Animal
    def parler(self):  # surcharge la méthode
        return f"{self.nom}: Miaou !"

class Chien(Animal):
    def parler(self):
        return f"{self.nom}: Wouf !"

animaux = [Chat("Misty"), Chien("Rex")]
for a in animaux:
    print(a.parler())
# → Misty: Miaou !
# → Rex: Wouf !`,
    },
  ]},
  { emoji: "📁", name: "Fichiers", lessons: [
    {
      title: "Lire et écrire un fichier",
      description: "open() ouvre un fichier. 'r' pour lire, 'w' pour écrire (efface le fichier existant), 'a' pour ajouter à la fin. with open() ferme automatiquement le fichier après utilisation (recommandé).",
      example: `# Écrire dans un fichier
with open("notes.txt", "w") as f:
    f.write("Note 1: 15\\n")
    f.write("Note 2: 18\\n")

# Lire tout le fichier
with open("notes.txt", "r") as f:
    contenu = f.read()
    print(contenu)

# Lire ligne par ligne
with open("notes.txt", "r") as f:
    for ligne in f:
        print(ligne.strip())   # strip() enlève le \\n`,
    },
  ]},
];

// ═══════════════════════════════════════════════════════
//  JAVASCRIPT
// ═══════════════════════════════════════════════════════
const JAVASCRIPT: Category[] = [
  { emoji: "📦", name: "Variables & Types", lessons: [
    {
      title: "const / let / var",
      description: "const crée une variable dont la référence ne peut pas changer (mais le contenu d'un objet/tableau peut). let est réassignable et limité au bloc {} où elle est déclarée. var est l'ancienne méthode — évite-la car elle a des comportements surprenants.",
      example: `const nom = "Ibo";    // ne peut pas être réassignée
let score = 0;         // peut changer
score = 10;            // OK

const fruits = ["pomme", "banane"];
fruits.push("kiwi");   // OK — on modifie le contenu
// fruits = [];        // ERREUR — on ne peut pas réassigner

console.log(nom);    // → Ibo
console.log(score);  // → 10`,
    },
    {
      title: "Types JavaScript",
      description: "JavaScript a 7 types primitifs : string, number (entiers ET décimaux dans un seul type), boolean, null, undefined, bigint, symbol. typeof retourne le type sous forme de chaîne. Attention : typeof null retourne 'object' — c'est un vieux bug de JavaScript.",
      example: `console.log(typeof "texte")     // → string
console.log(typeof 42)          // → number
console.log(typeof 3.14)        // → number (même type !)
console.log(typeof true)        // → boolean
console.log(typeof null)        // → object  (bug célèbre !)
console.log(typeof undefined)   // → undefined
console.log(typeof [])          // → object
console.log(typeof {})          // → object`,
    },
    {
      title: "Template literals (guillemets inversés)",
      description: "Les template literals utilisent des guillemets inversés et permettent d'insérer des expressions directement dans le texte avec ${expression}, d'écrire sur plusieurs lignes, et d'évaluer n'importe quelle expression JavaScript.",
      example: `const nom = "Ibo";
const age = 17;

// Avec les template literals (guillemets inversés)
const msg = "Bonjour " + nom + ", tu as " + age + " ans";   // ancienne façon
const msg2 = \`Bonjour \${nom}, tu as \${age} ans !\`;          // nouvelle façon
console.log(msg2);   // → Bonjour Ibo, tu as 17 ans !

console.log(\`2 + 2 = \${2 + 2}\`);   // → 2 + 2 = 4

const multiLigne = \`Ligne 1
Ligne 2
Ligne 3\`;
console.log(multiLigne);`,
    },
  ]},
  { emoji: "🔀", name: "Conditions", lessons: [
    {
      title: "if / else if / else",
      description: "Même logique qu'en Python mais avec des accolades {} obligatoires et des parenthèses () autour de la condition. Le point-virgule après les accolades n'est pas nécessaire.",
      example: `const note = 14;

if (note >= 16) {
  console.log("Très bien");
} else if (note >= 12) {
  console.log("Bien");
} else if (note >= 10) {
  console.log("Passable");
} else {
  console.log("Insuffisant");
}
// → Bien`,
    },
    {
      title: "== vs === (toujours utiliser ===)",
      description: "=== vérifie la valeur ET le type (strict). == fait une conversion automatique avant de comparer ce qui cause souvent des surprises. En JavaScript moderne, on utilise TOUJOURS ===.",
      example: `// == avec conversion de type (surprenant !)
console.log(1 == "1")      // → true  (converti)
console.log(0 == false)    // → true  (converti)
console.log("" == false)   // → true  (converti)
console.log(null == undefined)   // → true

// === strict (utilise toujours ça)
console.log(1 === "1")     // → false (types différents)
console.log(0 === false)   // → false
console.log(null === undefined)  // → false`,
    },
    {
      title: "Ternaire && || ??",
      description: "L'opérateur ternaire condition ? vrai : faux est une condition en une ligne. && et || permettent des valeurs par défaut. ?? (nullish coalescing) retourne la droite seulement si la gauche est null ou undefined.",
      example: `const age = 20;
const statut = age >= 18 ? "majeur" : "mineur";
console.log(statut);   // → majeur

// || retourne la première valeur truthy
const nom = "" || "Anonyme";
console.log(nom);      // → Anonyme (car "" est falsy)

// ?? retourne la droite seulement si null/undefined
const score = 0;
console.log(score ?? 100);    // → 0  (0 n'est pas null)
console.log(score || 100);    // → 100 (0 est falsy !)`,
    },
  ]},
  { emoji: "🔁", name: "Boucles", lessons: [
    {
      title: "for classique et for...of",
      description: "for classique avec initialisation, condition et incrément. for...of est la façon moderne de parcourir les valeurs d'un tableau — plus simple et lisible. for...in parcourt les clés d'un objet.",
      example: `// for classique
for (let i = 0; i < 5; i++) {
  process.stdout.write(i + " ");
}
console.log();    // → 0 1 2 3 4

// for...of — parcourir les valeurs
const fruits = ["pomme", "banane", "kiwi"];
for (const fruit of fruits) {
  console.log(fruit);
}
// → pomme
// → banane
// → kiwi`,
    },
    {
      title: "while et méthodes de tableau",
      description: "while répète tant que la condition est vraie. forEach() est une méthode moderne des tableaux pour parcourir sans créer une nouvelle liste. break et continue fonctionnent comme en Python.",
      example: `let i = 0;
while (i < 5) {
  process.stdout.write(i + " ");
  i++;
}
console.log();   // → 0 1 2 3 4

const nombres = [10, 20, 30, 40, 50];
nombres.forEach((n, index) => {
  console.log(\`[\${index}] = \${n}\`);
});
// → [0] = 10
// → [1] = 20  etc.`,
    },
  ]},
  { emoji: "🧩", name: "Fonctions", lessons: [
    {
      title: "function classique et arrow",
      description: "Les fonctions classiques sont 'hoistées' (utilisables avant leur déclaration). Les arrow functions (=>) ont une syntaxe plus courte. Si le corps est une seule expression, le return est implicite.",
      example: `// Fonction classique
function doubler(x) {
  return x * 2;
}

// Arrow function — syntaxe courte
const tripler = x => x * 3;
const additionner = (a, b) => a + b;
const saluer = nom => {
  const msg = \`Bonjour \${nom} !\`;
  return msg;
};

console.log(doubler(5));       // → 10
console.log(tripler(4));       // → 12
console.log(additionner(3,7)); // → 10
console.log(saluer("Ibo"));    // → Bonjour Ibo !`,
    },
    {
      title: "Valeurs par défaut et rest/spread",
      description: "Les paramètres par défaut s'utilisent avec =. L'opérateur rest ...args capture plusieurs arguments dans un tableau. L'opérateur spread ... étale un tableau.",
      example: `function saluer(nom, langue = "fr") {
  return langue === "fr" ? \`Bonjour \${nom}\` : \`Hello \${nom}\`;
}
console.log(saluer("Ibo"));        // → Bonjour Ibo
console.log(saluer("Ibo", "en"));  // → Hello Ibo

// rest : capturer plusieurs arguments
function somme(...nombres) {
  return nombres.reduce((acc, n) => acc + n, 0);
}
console.log(somme(1, 2, 3, 4));   // → 10

// spread : étaler un tableau
const a = [1, 2]; const b = [3, 4];
console.log([...a, ...b]);   // → [1, 2, 3, 4]`,
    },
    {
      title: "Destructuration",
      description: "La destructuration extrait des valeurs d'un tableau ou d'un objet en une seule ligne élégante. Très utilisée en JavaScript moderne, notamment avec les imports et les APIs.",
      example: `// Destructuration de tableau
const [a, b, ...reste] = [1, 2, 3, 4, 5];
console.log(a, b, reste);    // → 1 2 [3, 4, 5]

// Destructuration d'objet
const { nom, age, ville = "Paris" } = { nom: "Ibo", age: 17 };
console.log(nom, age, ville); // → Ibo 17 Paris

// Renommer en destructurant
const { nom: prenom } = { nom: "Ibo" };
console.log(prenom);   // → Ibo`,
    },
  ]},
  { emoji: "📋", name: "Tableaux (Arrays)", lessons: [
    {
      title: "map() — transformer",
      description: "map() crée un NOUVEAU tableau en appliquant une fonction à chaque élément. Il ne modifie pas le tableau original. C'est une des méthodes les plus utilisées en JavaScript moderne.",
      example: `const nombres = [1, 2, 3, 4, 5];

const doubles = nombres.map(n => n * 2);
console.log(doubles);   // → [2, 4, 6, 8, 10]
console.log(nombres);   // → [1, 2, 3, 4, 5]  (inchangé)

const users = [{ nom: "Alice" }, { nom: "Bob" }];
const noms = users.map(u => u.nom);
console.log(noms);   // → ['Alice', 'Bob']`,
    },
    {
      title: "filter() / find() / includes()",
      description: "filter() garde les éléments qui passent un test. find() retourne LE PREMIER élément correspondant. findIndex() retourne son index. includes() vérifie la présence.",
      example: `const notes = [14, 8, 18, 11, 16, 9];

const admis = notes.filter(n => n >= 10);
console.log(admis);   // → [14, 18, 11, 16]

const premierHaut = notes.find(n => n >= 15);
console.log(premierHaut);   // → 18

const idx = notes.findIndex(n => n >= 15);
console.log(idx);           // → 2

console.log(notes.includes(18));   // → true
console.log(notes.includes(20));   // → false`,
    },
    {
      title: "reduce() — tout en un",
      description: "reduce() parcourt le tableau et accumule un résultat. Le premier argument est l'accumulateur, le second est l'élément courant. La valeur initiale est le 2e argument de reduce(). Très puissant mais un peu complexe.",
      example: `const notes = [14, 18, 11, 16, 12];

// Somme
const somme = notes.reduce((acc, n) => acc + n, 0);
console.log(somme);   // → 71

// Moyenne
const moy = notes.reduce((acc, n) => acc + n, 0) / notes.length;
console.log(moy);     // → 14.2

// Créer un objet à partir d'un tableau
const fruits = ["pomme", "banane", "kiwi"];
const obj = fruits.reduce((acc, f) => {
  acc[f] = f.length;
  return acc;
}, {});
console.log(obj);   // → {pomme: 5, banane: 6, kiwi: 4}`,
    },
    {
      title: "sort() / some() / every()",
      description: "sort() trie le tableau EN PLACE (modifie l'original). Pour trier des nombres, il faut fournir une fonction comparateur. some() teste si AU MOINS UN élément passe. every() teste si TOUS passent.",
      example: `const nombres = [64, 25, 12, 22, 11];

// sort sans comparateur : tri alphabétique (bug courant !)
console.log([...nombres].sort());   // → [11, 12, 22, 25, 64] (chance ici)

// sort correct pour les nombres
console.log([...nombres].sort((a, b) => a - b));
// → [11, 12, 22, 25, 64]  (ordre croissant)
console.log([...nombres].sort((a, b) => b - a));
// → [64, 25, 22, 12, 11]  (ordre décroissant)

const notes = [14, 18, 11, 16];
console.log(notes.some(n => n >= 18));    // → true (au moins un)
console.log(notes.every(n => n >= 10));   // → true (tous ≥ 10)`,
    },
  ]},
  { emoji: "📖", name: "Objets", lessons: [
    {
      title: "Créer et utiliser un objet",
      description: "Un objet stocke des données liées (propriétés) et des actions (méthodes). Accès avec point ou crochets. Les méthodes avec function peuvent utiliser this pour accéder aux propriétés de l'objet.",
      example: `const joueur = {
  nom: "Ibo",
  score: 1500,
  niveau: 3,
  saluer() {          // méthode
    return \`Je suis \${this.nom}\`;
  }
};

console.log(joueur.nom);        // → Ibo
console.log(joueur["score"]);   // → 1500
console.log(joueur.saluer());   // → Je suis Ibo

joueur.score += 100;   // modifier
joueur.vies = 3;       // ajouter
console.log(joueur.score);  // → 1600`,
    },
    {
      title: "Object.keys / values / entries et spread",
      description: "Object.keys() retourne les clés, Object.values() les valeurs, Object.entries() les paires [clé, valeur]. L'opérateur spread {...obj} copie ou fusionne des objets.",
      example: `const user = { nom: "Ibo", age: 17, ville: "Paris" };

console.log(Object.keys(user));    // → ['nom', 'age', 'ville']
console.log(Object.values(user));  // → ['Ibo', 17, 'Paris']

for (const [cle, val] of Object.entries(user)) {
  console.log(\`\${cle}: \${val}\`);
}

// Spread — copier et fusionner
const admin = { ...user, role: "admin" };
console.log(admin);
// → {nom: 'Ibo', age: 17, ville: 'Paris', role: 'admin'}`,
    },
  ]},
  { emoji: "⏳", name: "Async / Await", lessons: [
    {
      title: "Promises — valeurs futures",
      description: "Une Promise représente une valeur qui sera disponible dans le futur. Elle est 'en attente' puis soit 'résolue' (succès) soit 'rejetée' (erreur). .then() pour traiter le succès, .catch() pour les erreurs.",
      example: `function attendre(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

function charger(id) {
  return new Promise((resolve, reject) => {
    if (id > 0) resolve({ id, nom: "Ibo" });
    else reject(new Error("ID invalide"));
  });
}

charger(1)
  .then(data => console.log(data.nom))   // → Ibo
  .catch(err => console.error(err));`,
    },
    {
      title: "async / await — code asynchrone propre",
      description: "async/await est une syntaxe qui rend le code asynchrone aussi lisible que du code synchrone. await attend qu'une Promise se résolve. La fonction doit être marquée async. Utilise try/catch pour les erreurs.",
      example: `function pause(ms) {
  return new Promise(r => setTimeout(r, ms));
}

async function chargerUtilisateur(id) {
  try {
    await pause(100);    // simule un délai réseau
    if (id <= 0) throw new Error("ID invalide");
    return { id, nom: "Ibo", score: 1500 };
  } catch (err) {
    console.error("Erreur:", err.message);
    return null;
  }
}

async function main() {
  const user = await chargerUtilisateur(1);
  console.log(user?.nom);   // → Ibo
}
main();`,
    },
  ]},
  { emoji: "⚠️", name: "Erreurs & Classes", lessons: [
    {
      title: "try / catch / finally",
      description: "try exécute le code qui pourrait échouer. catch attrape l'erreur avec son message et son type. finally s'exécute TOUJOURS (utile pour nettoyer des ressources). throw crée une erreur personnalisée.",
      example: `function diviser(a, b) {
  if (typeof a !== "number" || typeof b !== "number") {
    throw new TypeError("Les arguments doivent être des nombres");
  }
  if (b === 0) throw new Error("Division par zéro !");
  return a / b;
}

try {
  console.log(diviser(10, 2));   // → 5
  console.log(diviser(10, 0));   // lance une erreur
} catch (e) {
  console.error(e.message);      // → Division par zéro !
} finally {
  console.log("Terminé");        // → Terminé
}`,
    },
    {
      title: "Classes ES6",
      description: "Les classes JavaScript permettent de créer des objets avec un constructeur et des méthodes. extends permet l'héritage. super() appelle le constructeur parent.",
      example: `class Animal {
  constructor(nom) {
    this.nom = nom;
  }
  parler() {
    return \`\${this.nom} fait un bruit\`;
  }
}

class Chien extends Animal {
  constructor(nom, race) {
    super(nom);    // appelle Animal()
    this.race = race;
  }
  parler() {
    return \`\${this.nom} aboie ! (race: \${this.race})\`;
  }
}

const rex = new Chien("Rex", "Berger");
console.log(rex.parler());
// → Rex aboie ! (race: Berger)`,
    },
  ]},
];

// ═══════════════════════════════════════════════════════
//  HTML / CSS
// ═══════════════════════════════════════════════════════
const HTML: Category[] = [
  { emoji: "🏗️", name: "Structure HTML", lessons: [
    {
      title: "Squelette de base",
      description: "Tout fichier HTML commence par la déclaration DOCTYPE. La balise html contient tout. head contient les informations de la page (titre, style, polices). body contient ce qui est visible. Le charset UTF-8 permet les accents.",
      example: `<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Ma page</title>
</head>
<body>
  <h1>Bonjour !</h1>
  <p>Ceci est un paragraphe.</p>
</body>
</html>`,
    },
    {
      title: "Balises de texte",
      description: "h1 à h6 sont les titres (h1 = plus important, h6 = moins). p pour les paragraphes. strong pour le gras (important sémantiquement). em pour l'italique (emphase). br pour un saut de ligne. hr pour une ligne horizontale.",
      example: `<h1>Titre principal de la page</h1>
<h2>Sous-section importante</h2>
<h3>Sous-sous-section</h3>

<p>Un paragraphe normal avec du <strong>texte gras</strong>
et du <em>texte en italique</em>.</p>

<p>Première ligne<br>Deuxième ligne (même paragraphe)</p>

<hr>

<p>Nouveau paragraphe après la ligne.</p>`,
    },
  ]},
  { emoji: "🔗", name: "Liens & Images", lessons: [
    {
      title: "Liens <a>",
      description: "La balise a crée un lien. href contient l'URL de destination. target='_blank' ouvre dans un nouvel onglet (ajoute toujours rel='noopener' pour la sécurité). Un lien peut entourer n'importe quelle balise.",
      example: `<a href="https://google.com">Aller sur Google</a>

<a href="https://google.com" target="_blank" rel="noopener">
  Ouvrir dans un nouvel onglet
</a>

<!-- Lien vers une section de la même page -->
<a href="#contact">Aller au contact</a>

<!-- Lien email -->
<a href="mailto:contact@example.com">M'envoyer un email</a>

<section id="contact">
  <h2>Contactez-nous</h2>
</section>`,
    },
    {
      title: "Images <img>",
      description: "La balise img affiche une image. src est l'URL ou le chemin. alt est le texte alternatif (obligatoire pour l'accessibilité — décrit l'image). width et height contrôlent la taille. loading='lazy' charge les images au fur et à mesure.",
      example: `<!-- Image depuis internet -->
<img src="https://picsum.photos/400/300"
     alt="Photo aléatoire"
     width="400">

<!-- Image avec style CSS -->
<img src="photo.jpg"
     alt="Ma photo de profil"
     style="border-radius: 50%; width: 100px;">

<!-- Image cliquable (lien autour de l'image) -->
<a href="https://exemple.com">
  <img src="logo.png" alt="Logo du site" width="200">
</a>`,
    },
  ]},
  { emoji: "📋", name: "Listes & Tableaux", lessons: [
    {
      title: "Listes ul et ol",
      description: "ul crée une liste non ordonnée (avec des puces). ol crée une liste ordonnée (avec des numéros). li est chaque élément de la liste. Les listes peuvent être imbriquées pour créer des sous-listes.",
      example: `<!-- Liste non ordonnée (puces) -->
<ul>
  <li>Pomme</li>
  <li>Banane</li>
  <li>Kiwi avec sous-liste :
    <ul>
      <li>Vert</li>
      <li>Jaune</li>
    </ul>
  </li>
</ul>

<!-- Liste ordonnée (numéros) -->
<ol>
  <li>Préchauffer le four à 180°C</li>
  <li>Mélanger les ingrédients</li>
  <li>Cuire 25 minutes</li>
</ol>`,
    },
    {
      title: "Tableaux <table>",
      description: "table crée le tableau. thead pour l'en-tête. tbody pour les données. tr est une ligne. th est une cellule d'en-tête (gras et centré par défaut). td est une cellule de données. colspan et rowspan fusionnent des cellules.",
      example: `<table border="1" style="border-collapse: collapse; width: 100%;">
  <thead style="background: #333; color: white;">
    <tr>
      <th>Nom</th>
      <th>Note</th>
      <th>Mention</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Alice</td>
      <td>16</td>
      <td>Bien</td>
    </tr>
    <tr>
      <td>Bob</td>
      <td>12</td>
      <td>Passable</td>
    </tr>
  </tbody>
</table>`,
    },
  ]},
  { emoji: "📝", name: "Formulaires", lessons: [
    {
      title: "Inputs et formulaires",
      description: "form regroupe les champs. label lie un texte à un champ (for doit correspondre à l'id du champ). input a de nombreux types : text, email, number, password, checkbox, radio, date, color. button soumet le formulaire.",
      example: `<form>
  <div>
    <label for="nom">Nom :</label>
    <input type="text" id="nom" placeholder="Ton nom" required>
  </div>
  <div>
    <label for="email">Email :</label>
    <input type="email" id="email" placeholder="ton@email.com">
  </div>
  <div>
    <label for="age">Âge :</label>
    <input type="number" id="age" min="0" max="120" value="17">
  </div>
  <div>
    <label>
      <input type="checkbox" id="accept"> J'accepte les conditions
    </label>
  </div>
  <button type="submit">Envoyer</button>
</form>`,
    },
    {
      title: "Select et textarea",
      description: "select crée un menu déroulant. option représente chaque choix. value est la valeur envoyée au serveur (différente du texte affiché). textarea crée une zone de texte multi-lignes. rows et cols définissent sa taille.",
      example: `<label for="pays">Pays :</label>
<select id="pays">
  <option value="">-- Choisir --</option>
  <option value="fr">France</option>
  <option value="be">Belgique</option>
  <option value="ch" selected>Suisse (sélectionné)</option>
</select>

<br><br>

<label for="message">Message :</label><br>
<textarea id="message" rows="5" cols="40"
  placeholder="Écris ton message ici..."></textarea>`,
    },
  ]},
  { emoji: "🎨", name: "CSS — Bases", lessons: [
    {
      title: "Sélecteurs et propriétés",
      description: "Le CSS stylise le HTML. Un sélecteur cible des éléments (par balise, classe .nom, ou id #nom). Une propriété définit l'aspect (couleur, taille, etc.). Les classes s'ajoutent sur l'élément HTML avec class='ma-classe'.",
      example: `<style>
  body {
    background: #1a1a2e;
    color: white;
    font-family: sans-serif;
    margin: 20px;
  }

  h1 { color: #a78bfa; font-size: 2rem; }

  .carte {
    background: #16213e;
    padding: 20px;
    border-radius: 12px;
    border: 1px solid #a78bfa30;
    margin: 10px 0;
  }

  #special { color: gold; font-weight: bold; }
</style>
<h1>Titre violet</h1>
<div class="carte">Carte avec style</div>
<p id="special">Texte doré unique</p>`,
    },
    {
      title: "Flexbox — alignement",
      description: "Flexbox organise des éléments en ligne ou colonne. display:flex active Flexbox sur le conteneur. justify-content aligne horizontalement. align-items aligne verticalement. gap espace les éléments.",
      example: `<style>
  .conteneur {
    display: flex;
    justify-content: center;   /* centré horizontalement */
    align-items: center;       /* centré verticalement */
    gap: 16px;
    height: 150px;
    background: #1a1a2e;
    border-radius: 12px;
  }
  .box {
    width: 60px; height: 60px;
    border-radius: 8px;
    display: flex; align-items: center; justify-content: center;
    color: white; font-weight: bold;
  }
</style>
<div class="conteneur">
  <div class="box" style="background:#ef4444">1</div>
  <div class="box" style="background:#22c55e">2</div>
  <div class="box" style="background:#3b82f6">3</div>
</div>`,
    },
    {
      title: "CSS Grid — grille 2D",
      description: "CSS Grid permet de créer des mises en page en deux dimensions (lignes ET colonnes). grid-template-columns définit le nombre et la largeur des colonnes. fr est une unité proportionnelle. gap espace les cellules.",
      example: `<style>
  .grille {
    display: grid;
    grid-template-columns: 1fr 2fr 1fr;  /* 3 colonnes */
    gap: 10px;
    padding: 10px;
    background: #111;
  }
  .cellule {
    background: #7c3aed;
    color: white;
    padding: 20px;
    border-radius: 8px;
    text-align: center;
  }
</style>
<div class="grille">
  <div class="cellule">Gauche</div>
  <div class="cellule">Centre (2x)</div>
  <div class="cellule">Droite</div>
</div>`,
    },
    {
      title: "Transitions et animations",
      description: "transition anime le changement d'une propriété CSS lors d'un événement (:hover, :focus). @keyframes définit une animation avec des étapes. animation applique l'animation à un élément.",
      example: `<style>
  .btn {
    background: #7c3aed;
    color: white;
    padding: 12px 24px;
    border: none;
    border-radius: 8px;
    cursor: pointer;
    font-size: 16px;
    transition: background 0.3s ease, transform 0.2s ease;
  }
  .btn:hover {
    background: #5b21b6;
    transform: scale(1.05);
  }

  @keyframes pulser {
    0%   { opacity: 1; transform: scale(1); }
    50%  { opacity: 0.6; transform: scale(1.1); }
    100% { opacity: 1; transform: scale(1); }
  }
  .cercle {
    width: 60px; height: 60px;
    background: #ef4444;
    border-radius: 50%;
    animation: pulser 1.5s ease-in-out infinite;
  }
</style>
<button class="btn">Survole-moi !</button>
<br><br>
<div class="cercle"></div>`,
    },
  ]},
];

// ═══════════════════════════════════════════════════════
//  TYPESCRIPT
// ═══════════════════════════════════════════════════════
const TYPESCRIPT: Category[] = [
  { emoji: "📦", name: "Types de base", lessons: [
    {
      title: "Annoter les variables et fonctions",
      description: "TypeScript ajoute des types à JavaScript. On écrit : type après le nom de la variable. Les types de base sont string, number, boolean, null, undefined, any (à éviter) et unknown (plus sûr que any).",
      example: `const nom: string = "Ibo";
const age: number = 17;
const actif: boolean = true;
let data: unknown;   // plus sûr que any

function saluer(prenom: string): string {
  return \`Bonjour \${prenom} !\`;
}

function additionner(a: number, b: number): number {
  return a + b;
}

console.log(saluer("Ibo"));         // → Bonjour Ibo !
console.log(additionner(3, 7));     // → 10`,
    },
    {
      title: "Arrays, tuples et union types",
      description: "type[] ou Array<type> pour les tableaux. Les tuples ont un nombre et des types fixes. Le type union (A | B) accepte l'un OU l'autre. Le type littéral n'accepte que des valeurs précises.",
      example: `const notes: number[] = [14, 18, 11];
const noms: Array<string> = ["Alice", "Bob"];

// Tuple : taille et types fixes
const point: [number, number] = [3, 7];
const personne: [string, number] = ["Ibo", 17];

// Union : accepte plusieurs types
let id: string | number;
id = 42;      // OK
id = "abc";   // OK aussi

// Type littéral : seulement ces valeurs
type Statut = "actif" | "inactif" | "banni";
let statut: Statut = "actif";`,
    },
  ]},
  { emoji: "📐", name: "Interfaces & Types", lessons: [
    {
      title: "interface — décrire un objet",
      description: "Une interface décrit la forme qu'un objet doit avoir. ? rend une propriété optionnelle. readonly empêche la modification après création. Les interfaces peuvent s'étendre avec extends.",
      example: `interface Utilisateur {
  readonly id: number;  // ne peut pas être modifié
  nom: string;
  email?: string;       // optionnel
  score: number;
}

const user: Utilisateur = {
  id: 1,
  nom: "Ibo",
  score: 1500
};

console.log(user.nom);   // → Ibo
// user.id = 2;          // ERREUR: readonly !

interface Admin extends Utilisateur {
  role: "admin" | "moderateur";
}`,
    },
    {
      title: "Utility types — transformer des types",
      description: "TypeScript fournit des types utilitaires pour transformer d'autres types. Partial rend tout optionnel, Required rend tout obligatoire, Readonly empêche les modifications, Pick sélectionne des champs, Omit en retire.",
      example: `interface User { id: number; nom: string; email: string; age: number; }

// Partial : tout optionnel (utile pour les mises à jour)
type UserUpdate = Partial<User>;
const update: UserUpdate = { nom: "Ibo" };  // OK sans id, email, age

// Pick : ne garder que certains champs
type UserPublic = Pick<User, "id" | "nom">;
const pub: UserPublic = { id: 1, nom: "Ibo" };

// Omit : enlever certains champs
type UserSansEmail = Omit<User, "email">;

// Readonly : tout en lecture seule
type UserImmuable = Readonly<User>;`,
    },
  ]},
  { emoji: "🔧", name: "Génériques", lessons: [
    {
      title: "<T> — fonctions génériques",
      description: "Les génériques permettent d'écrire du code qui fonctionne avec n'importe quel type tout en préservant l'information de type. T est une convention pour 'Type', tu peux utiliser n'importe quelle lettre.",
      example: `// Sans générique : perd le type
function premier1(arr: any[]): any { return arr[0]; }

// Avec générique : préserve le type
function premier<T>(arr: T[]): T | undefined {
  return arr[0];
}

const n = premier([1, 2, 3]);           // TypeScript sait que n: number
const s = premier(["a", "b", "c"]);    // TypeScript sait que s: string

console.log(n);   // → 1
console.log(s);   // → a

// Interface générique
interface Boite<T> { valeur: T; etiquette: string; }
const b: Boite<number> = { valeur: 42, etiquette: "Score" };`,
    },
  ]},
];

// ═══════════════════════════════════════════════════════
//  LUA
// ═══════════════════════════════════════════════════════
const LUA: Category[] = [
  { emoji: "📦", name: "Bases du langage", lessons: [
    {
      title: "Variables et types",
      description: "En Lua, on utilise local pour créer une variable locale (fortement recommandé). Sans local, la variable est globale et accessible partout. Les types sont : number, string, boolean, nil (vide), table (tableaux et dicts), function.",
      example: `local age = 17           -- number
local nom = "Ibo"        -- string
local actif = true       -- boolean
local vide = nil         -- nil (pas de valeur)

-- Affichage et type
print(age)              -- → 17
print(type(age))        -- → number
print(type(nom))        -- → string

-- Concaténation avec ..
print("Bonjour " .. nom)   -- → Bonjour Ibo`,
    },
    {
      title: "print et formatage",
      description: "print() affiche des valeurs séparées par des tabulations. tostring() convertit en chaîne. tonumber() convertit en nombre. string.format() formate comme printf en C.",
      example: `local prenom = "Ibo"
local age = 17
local pi = 3.14159

print(prenom, age)    -- → Ibo    17  (séparé par tabulation)
print("Bonjour " .. prenom .. " !")  -- → Bonjour Ibo !

-- Formatage précis
print(string.format("Nom: %s, Age: %d", prenom, age))
-- → Nom: Ibo, Age: 17

print(string.format("Pi = %.2f", pi))
-- → Pi = 3.14`,
    },
  ]},
  { emoji: "🔀", name: "Conditions & Boucles", lessons: [
    {
      title: "if / elseif / else",
      description: "En Lua, les conditions s'écrivent if ... then ... end. elseif (sans espace) pour plusieurs conditions. L'opérateur différent est ~= (pas != comme dans d'autres langages). Les opérateurs logiques sont and, or, not.",
      example: `local note = 14

if note >= 16 then
    print("Très bien")
elseif note >= 12 then
    print("Bien")
elseif note >= 10 then
    print("Passable")        -- → Passable
else
    print("Insuffisant")
end

-- ~= signifie "différent de"
if note ~= 0 then
    print("Note non nulle")  -- → Note non nulle
end`,
    },
    {
      title: "Boucles for, while, repeat",
      description: "for numérique de début à fin avec un pas optionnel. for générique avec ipairs() pour les tableaux (index commence à 1 !). while répète tant que la condition est vraie. repeat...until s'exécute au moins une fois.",
      example: `-- for numérique (index commence à 1 en Lua !)
for i = 1, 5 do
    io.write(i .. " ")
end
print()   -- → 1 2 3 4 5

-- for générique avec ipairs
local fruits = {"pomme", "banane", "kiwi"}
for i, fruit in ipairs(fruits) do
    print(i, fruit)
end
-- → 1  pomme
-- → 2  banane
-- → 3  kiwi`,
    },
  ]},
  { emoji: "🧩", name: "Fonctions & Tables", lessons: [
    {
      title: "Fonctions en Lua",
      description: "Lua supporte plusieurs valeurs de retour, ce qui est très pratique. Les fonctions sont des valeurs de première classe (on peut les assigner à des variables, les passer en argument).",
      example: `local function saluer(nom)
    return "Bonjour " .. nom .. " !"
end
print(saluer("Ibo"))   -- → Bonjour Ibo !

-- Plusieurs valeurs retournées
local function minMax(t)
    local min, max = t[1], t[1]
    for _, v in ipairs(t) do
        if v < min then min = v end
        if v > max then max = v end
    end
    return min, max
end

local mn, mx = minMax({5, 3, 9, 1, 7})
print(mn, mx)   -- → 1    9`,
    },
    {
      title: "Tables — tableaux et dictionnaires",
      description: "Les tables Lua sont la seule structure de données. Elles servent à la fois de tableau (index à partir de 1 !) et de dictionnaire (clé:valeur). # donne la longueur d'un tableau.",
      example: `-- Tableau (index commence à 1 !)
local fruits = {"pomme", "banane", "kiwi"}
print(fruits[1])      -- → pomme  (pas [0] !)
print(#fruits)        -- → 3

table.insert(fruits, "mangue")   -- ajouter
print(#fruits)        -- → 4

-- Dictionnaire
local joueur = {nom = "Ibo", score = 1500}
print(joueur.nom)         -- → Ibo
print(joueur["score"])    -- → 1500
joueur.niveau = 3         -- ajouter une clé

for cle, val in pairs(joueur) do
    print(cle, val)
end`,
    },
  ]},
];

// ═══════════════════════════════════════════════════════
//  JAVA
// ═══════════════════════════════════════════════════════
const JAVA: Category[] = [
  { emoji: "🏗️", name: "Structure Java", lessons: [
    {
      title: "Structure de base",
      description: "Tout code Java vit dans une classe. La méthode main(String[] args) est le point d'entrée (obligatoire et exactement comme ça). System.out.println() affiche avec saut de ligne. System.out.printf() permet le formatage.",
      example: `public class Main {
    public static void main(String[] args) {
        System.out.println("Bonjour le monde !");
        System.out.printf("2 + 2 = %d%n", 4);

        String nom = "Ibo";
        int age = 17;
        System.out.println("Nom: " + nom + ", Age: " + age);
        // → Bonjour le monde !
        // → 2 + 2 = 4
        // → Nom: Ibo, Age: 17
    }
}`,
    },
  ]},
  { emoji: "📦", name: "Types & Variables", lessons: [
    {
      title: "Types primitifs",
      description: "Java est fortement typé : chaque variable doit avoir un type déclaré. Types primitifs : int (entier), double (décimal), boolean (vrai/faux), char (un caractère). String (avec majuscule) est un objet, pas un primitif.",
      example: `public class Main {
    public static void main(String[] args) {
        int age = 17;
        double prix = 9.99;
        boolean actif = true;
        char lettre = 'A';
        String nom = "Ibo";

        System.out.println(age);        // → 17
        System.out.println(prix);       // → 9.99
        System.out.println(actif);      // → true
        System.out.println(nom.length()); // → 3
        System.out.println(nom.toUpperCase()); // → IBO
    }
}`,
    },
    {
      title: "Conversions de types",
      description: "Java nécessite des conversions explicites entre types. (int) convertit un double en entier (troncature). Integer.parseInt() convertit String vers int. String.valueOf() ou Integer.toString() pour int vers String.",
      example: `public class Main {
    public static void main(String[] args) {
        double d = 3.99;
        int i = (int) d;        // → 3 (troncature, pas arrondi)
        System.out.println(i);

        String s = "42";
        int n = Integer.parseInt(s);     // → 42
        double x = Double.parseDouble("3.14");

        String back = String.valueOf(n); // → "42"
        System.out.println(n + 1);       // → 43
        System.out.println(back + 1);    // → "421" (concaténation !)
    }
}`,
    },
  ]},
  { emoji: "🔀", name: "Conditions & Boucles", lessons: [
    {
      title: "if / else if / switch",
      description: "if/else identique à JavaScript. Pour les String, il faut utiliser .equals() pour comparer (jamais == qui compare les références). switch teste une valeur contre plusieurs cas.",
      example: `public class Main {
    public static void main(String[] args) {
        int note = 14;
        if (note >= 16) {
            System.out.println("Très bien");
        } else if (note >= 10) {
            System.out.println("Passable");  // → Passable
        } else {
            System.out.println("Insuffisant");
        }

        String langue = "fr";
        if (langue.equals("fr")) {
            System.out.println("Bonjour !"); // → Bonjour !
        }
        // NE PAS utiliser langue == "fr" (compare références !)
    }
}`,
    },
    {
      title: "Boucles for, for-each, while",
      description: "for classique avec initialisation, condition, incrément. for-each (for amélioré) pour parcourir un tableau ou collection. while et do-while comme en JavaScript.",
      example: `public class Main {
    public static void main(String[] args) {
        // for classique
        for (int i = 0; i < 5; i++) {
            System.out.print(i + " ");
        }
        System.out.println();   // → 0 1 2 3 4

        // for-each sur tableau
        String[] fruits = {"pomme", "banane", "kiwi"};
        for (String fruit : fruits) {
            System.out.println(fruit);
        }
        // → pomme  banane  kiwi

        // while
        int n = 0;
        while (n < 3) { System.out.print(n++ + " "); }
        // → 0 1 2
    }
}`,
    },
  ]},
  { emoji: "🧩", name: "Méthodes & Classes", lessons: [
    {
      title: "Définir des méthodes",
      description: "En Java, les fonctions s'appellent méthodes et vivent dans des classes. static permet d'appeler la méthode sans créer d'instance. void si rien n'est retourné. Les paramètres ont des types obligatoires.",
      example: `public class Main {
    static int additionner(int a, int b) {
        return a + b;
    }

    static String saluer(String nom) {
        return "Bonjour " + nom + " !";
    }

    static boolean estPair(int n) {
        return n % 2 == 0;
    }

    public static void main(String[] args) {
        System.out.println(additionner(3, 7));  // → 10
        System.out.println(saluer("Ibo"));      // → Bonjour Ibo !
        System.out.println(estPair(4));         // → true
        System.out.println(estPair(7));         // → false
    }
}`,
    },
    {
      title: "Classes et objets",
      description: "Une classe Java définit un modèle. Le constructeur (même nom que la classe) initialise les attributs. this fait référence à l'objet courant. On crée une instance avec new.",
      example: `class Chien {
    String nom;
    int energie;

    Chien(String nom) {        // constructeur
        this.nom = nom;
        this.energie = 100;
    }

    void aboyer() {
        System.out.println(nom + ": Wouf !");
    }

    void manger(int quantite) {
        energie += quantite;
    }
}

public class Main {
    public static void main(String[] args) {
        Chien rex = new Chien("Rex");
        rex.aboyer();           // → Rex: Wouf !
        rex.manger(20);
        System.out.println(rex.energie);  // → 120
    }
}`,
    },
  ]},
];

// ═══════════════════════════════════════════════════════
//  C++
// ═══════════════════════════════════════════════════════
const CPP: Category[] = [
  { emoji: "🏗️", name: "Structure C++", lessons: [
    {
      title: "Structure et affichage",
      description: "#include importe des bibliothèques. using namespace std évite d'écrire std:: partout. cout affiche du texte. endl (ou '\\n') passe à la ligne. Les instructions se terminent par un point-virgule.",
      example: `#include <iostream>
#include <string>
using namespace std;

int main() {
    string nom = "Ibo";
    int age = 17;

    cout << "Bonjour " << nom << " !" << endl;
    // → Bonjour Ibo !

    cout << "Tu as " << age << " ans" << endl;
    // → Tu as 17 ans

    cout << "2 + 2 = " << (2 + 2) << endl;
    // → 2 + 2 = 4

    return 0;   // obligatoire dans main
}`,
    },
    {
      title: "cin — saisie clavier",
      description: "cin >> lit une valeur depuis l'entrée standard (clavier). getline(cin, variable) lit une ligne entière (y compris les espaces). Le type de la variable détermine ce qui est lu.",
      example: `#include <iostream>
#include <string>
using namespace std;

int main() {
    string nom;
    int age;

    cout << "Ton nom : ";
    cin >> nom;

    cout << "Ton age : ";
    cin >> age;

    cout << "Bonjour " << nom << " !" << endl;
    cout << "Tu as " << age << " ans" << endl;

    return 0;
}`,
    },
  ]},
  { emoji: "🔀", name: "Conditions & Boucles", lessons: [
    {
      title: "if / else / switch",
      description: "Même structure qu'en Java et JavaScript. Les comparaisons fonctionnent de la même façon. Pour les strings en C++ moderne, == fonctionne correctement (contrairement à Java).",
      example: `#include <iostream>
using namespace std;

int main() {
    int note = 14;

    if (note >= 16) {
        cout << "Tres bien" << endl;
    } else if (note >= 10) {
        cout << "Passable" << endl;   // → Passable
    } else {
        cout << "Insuffisant" << endl;
    }

    // Opérateur ternaire
    string statut = (note >= 10) ? "admis" : "recale";
    cout << statut << endl;           // → admis

    return 0;
}`,
    },
    {
      title: "Boucles for, while, range-for",
      description: "for classique avec initialisation, condition, incrément. while répète tant que la condition est vraie. La range-based for (for moderne) parcourt les éléments d'un vecteur ou tableau.",
      example: `#include <iostream>
#include <vector>
using namespace std;

int main() {
    // for classique
    for (int i = 0; i < 5; i++) {
        cout << i << " ";
    }
    cout << endl;   // → 0 1 2 3 4

    // range-based for (C++ moderne)
    vector<string> fruits = {"pomme", "banane", "kiwi"};
    for (const string& f : fruits) {
        cout << f << endl;
    }
    // → pomme   banane   kiwi

    return 0;
}`,
    },
  ]},
  { emoji: "🧩", name: "Fonctions & Vecteurs", lessons: [
    {
      title: "Fonctions en C++",
      description: "En C++, chaque fonction doit déclarer le type de ses paramètres et son type de retour. void si rien n'est retourné. Les fonctions doivent être déclarées AVANT leur utilisation (ou avec un prototype en haut).",
      example: `#include <iostream>
#include <string>
using namespace std;

int additionner(int a, int b) {
    return a + b;
}

string saluer(string nom) {
    return "Bonjour " + nom + " !";
}

bool estPair(int n) {
    return n % 2 == 0;
}

int main() {
    cout << additionner(3, 7) << endl;    // → 10
    cout << saluer("Ibo") << endl;        // → Bonjour Ibo !
    cout << estPair(4) << endl;           // → 1 (true)
    return 0;
}`,
    },
    {
      title: "vector<T> — tableau dynamique",
      description: "vector est le tableau dynamique de C++. push_back() ajoute à la fin. size() donne le nombre d'éléments. L'accès se fait avec [index]. pop_back() retire le dernier élément.",
      example: `#include <iostream>
#include <vector>
using namespace std;

int main() {
    vector<int> scores;
    scores.push_back(85);
    scores.push_back(92);
    scores.push_back(78);
    scores.push_back(95);

    cout << "Taille: " << scores.size() << endl; // → 4
    cout << "Premier: " << scores[0] << endl;    // → 85
    cout << "Dernier: " << scores.back() << endl; // → 95

    for (int s : scores) {
        cout << s << " ";
    }
    cout << endl;   // → 85 92 78 95

    return 0;
}`,
    },
  ]},
];

// ═══════════════════════════════════════════════════════
//  PHP
// ═══════════════════════════════════════════════════════
const PHP: Category[] = [
  { emoji: "🏗️", name: "Bases PHP", lessons: [
    {
      title: "Syntaxe de base",
      description: "PHP commence par <?php. echo affiche du texte (ou print). Les variables commencent TOUJOURS par $. Le point . sert à concaténer les chaînes. Les instructions se terminent par ;",
      example: `<?php
$nom = "Ibo";
$age = 17;

echo "Bonjour $nom !\n";           // → Bonjour Ibo !
echo "Tu as " . $age . " ans\n";  // → Tu as 17 ans

// Guillemets doubles → variables interprétées
echo "Nom: $nom\n";               // → Nom: Ibo

// Guillemets simples → texte brut
echo 'Nom: $nom\n';               // → Nom: $nom\n  (littéral)

$resultat = 3 + 4;
echo $resultat . "\n";            // → 7
?>`,
    },
    {
      title: "Types et conversions",
      description: "PHP est faiblement typé : la plupart des conversions sont automatiques. Les types principaux sont string, int, float, bool, null, array. gettype() retourne le type. PHP 8 permet d'annoter les types dans les fonctions.",
      example: `<?php
$texte = "42";
$nombre = (int) $texte;      // → 42
$decimal = (float) $texte;   // → 42.0
$booleen = (bool) $texte;    // → true

echo gettype($texte) . "\n";    // → string
echo gettype($nombre) . "\n";   // → integer

// intval() pour convertir proprement
$s = "123abc";
echo intval($s) . "\n";   // → 123

// settype() modifie en place
$x = "3.14";
settype($x, "float");
echo $x . "\n";   // → 3.14
?>`,
    },
  ]},
  { emoji: "🔀", name: "Conditions & Boucles", lessons: [
    {
      title: "if / elseif / else",
      description: "Comme JavaScript mais avec $ devant les variables. Utilise === (triple égal) pour comparer valeur ET type. == fait une conversion automatique. match() est le switch moderne de PHP 8.",
      example: `<?php
$note = 14;

if ($note >= 16) {
    echo "Tres bien\n";
} elseif ($note >= 12) {
    echo "Bien\n";
} elseif ($note >= 10) {
    echo "Passable\n";   // → Passable
} else {
    echo "Insuffisant\n";
}

// === strict (recommandé)
$val = "10";
if ($val === 10) {
    echo "Entier 10\n";
} else {
    echo "Pas l'entier 10\n";  // → Pas l'entier 10
}
?>`,
    },
    {
      title: "Boucles et foreach",
      description: "for, while et foreach (le plus utilisé pour les tableaux). foreach parcourt chaque élément d'un tableau. La syntaxe foreach ($array as $val) ou foreach ($array as $cle => $val).",
      example: `<?php
// for classique
for ($i = 0; $i < 5; $i++) {
    echo $i . " ";
}
echo "\n";   // → 0 1 2 3 4

// foreach — tableau simple
$fruits = ["pomme", "banane", "kiwi"];
foreach ($fruits as $fruit) {
    echo $fruit . "\n";
}
// → pomme  banane  kiwi

// foreach — tableau associatif
$ages = ["Alice" => 25, "Bob" => 30];
foreach ($ages as $nom => $age) {
    echo "$nom a $age ans\n";
}
// → Alice a 25 ans
// → Bob a 30 ans
?>`,
    },
  ]},
  { emoji: "🧩", name: "Fonctions & Tableaux", lessons: [
    {
      title: "Fonctions PHP",
      description: "function nomFonction($params) {}. PHP 7+ permet d'annoter les types des paramètres et du retour. PHP supporte les valeurs par défaut. Les fonctions peuvent retourner plusieurs valeurs via un tableau.",
      example: `<?php
function saluer(string $nom): string {
    return "Bonjour $nom !";
}

function additionner(int $a, int $b = 0): int {
    return $a + $b;
}

function statistiques(array $notes): array {
    return [
        "min" => min($notes),
        "max" => max($notes),
        "moy" => array_sum($notes) / count($notes)
    ];
}

echo saluer("Ibo") . "\n";          // → Bonjour Ibo !
echo additionner(3, 7) . "\n";      // → 10

$stats = statistiques([14, 18, 11, 16]);
echo "Moy: " . $stats["moy"] . "\n"; // → Moy: 14.75
?>`,
    },
    {
      title: "Fonctions de tableau",
      description: "PHP a de nombreuses fonctions pour manipuler les tableaux. array_map() transforme, array_filter() filtre, sort() trie, array_push() ajoute, in_array() cherche, implode() joint, explode() découpe.",
      example: `<?php
$nombres = [5, 3, 8, 1, 9, 2];
sort($nombres);
print_r($nombres);
// → [1, 2, 3, 5, 8, 9]

$pairs = array_filter($nombres, fn($n) => $n % 2 === 0);
print_r($pairs);  // → [2, 8]

$doubles = array_map(fn($n) => $n * 2, $nombres);
print_r($doubles); // → [2, 4, 6, 10, 16, 18]

// in_array : chercher un élément
echo in_array(8, $nombres) ? "Trouvé\n" : "Absent\n";
// → Trouvé

// explode/implode
$csv = "Alice,Bob,Charlie";
$noms = explode(",", $csv);
echo implode(" | ", $noms) . "\n";
// → Alice | Bob | Charlie
?>`,
    },
  ]},
];

// ═══════════════════════════════════════════════════════
//  GO
// ═══════════════════════════════════════════════════════
const GO: Category[] = [
  { emoji: "🏗️", name: "Structure Go", lessons: [
    {
      title: "Package, imports et main",
      description: "Tout fichier Go appartient à un package. Le package main est le point d'entrée. import permet d'importer des packages. fmt est le package de formatage/affichage. := déclare et assigne en une seule étape.",
      example: `package main

import (
    "fmt"
    "math"
)

func main() {
    nom := "Ibo"       // déclare et assigne
    age := 17
    pi := math.Pi

    fmt.Println("Bonjour", nom)
    // → Bonjour Ibo

    fmt.Printf("Age: %d, Pi: %.2f\n", age, pi)
    // → Age: 17, Pi: 3.14
}`,
    },
    {
      title: "Types et variables",
      description: "Go est fortement typé. var déclare explicitement avec un type. := devine le type automatiquement. Les types numériques principaux : int, int64, float64. Attention : Go n'autorise pas les variables non utilisées.",
      example: `package main

import "fmt"

func main() {
    var score int = 100
    var pi float64 = 3.14159
    var actif bool = true
    nom := "Ibo"   // type déduit : string

    fmt.Println(score, pi, actif, nom)
    // → 100 3.14159 true Ibo

    fmt.Printf("Type de score : %T\n", score)
    // → Type de score : int

    // Constante
    const MAX = 1000
    fmt.Println(MAX)   // → 1000
}`,
    },
  ]},
  { emoji: "🔀", name: "Conditions & Boucles", lessons: [
    {
      title: "if / else / switch",
      description: "Go n'utilise pas de parenthèses autour des conditions. if peut inclure une instruction d'initialisation avant la condition. switch est plus propre qu'en Java/C (pas de fallthrough par défaut).",
      example: `package main

import "fmt"

func main() {
    note := 14
    if note >= 16 {
        fmt.Println("Tres bien")
    } else if note >= 10 {
        fmt.Println("Passable")    // → Passable
    } else {
        fmt.Println("Insuffisant")
    }

    // switch propre (pas besoin de break)
    jour := "lundi"
    switch jour {
    case "samedi", "dimanche":
        fmt.Println("Weekend")
    default:
        fmt.Println("Semaine")    // → Semaine
    }
}`,
    },
    {
      title: "for — la seule boucle de Go",
      description: "Go n'a qu'un seul mot-clé de boucle : for. Il peut fonctionner comme un for classique, comme un while, ou être infini. range permet de parcourir les slices, maps et chaînes.",
      example: `package main

import "fmt"

func main() {
    // for classique
    for i := 0; i < 5; i++ {
        fmt.Print(i, " ")
    }
    fmt.Println()   // → 0 1 2 3 4

    // for comme while
    n := 10
    for n > 0 {
        fmt.Print(n, " ")
        n -= 3
    }
    fmt.Println()   // → 10 7 4 1

    // range sur slice
    fruits := []string{"pomme", "banane", "kiwi"}
    for i, f := range fruits {
        fmt.Printf("%d: %s\n", i, f)
    }
    // → 0: pomme  1: banane  2: kiwi
}`,
    },
  ]},
  { emoji: "🧩", name: "Fonctions & Collections", lessons: [
    {
      title: "Fonctions et multi-retour",
      description: "Les fonctions Go retournent souvent deux valeurs : (résultat, erreur). C'est un pattern central en Go. nil signifie 'pas d'erreur'. On vérifie toujours l'erreur immédiatement.",
      example: `package main

import (
    "errors"
    "fmt"
)

func diviser(a, b float64) (float64, error) {
    if b == 0 {
        return 0, errors.New("division par zero")
    }
    return a / b, nil
}

func main() {
    res, err := diviser(10, 3)
    if err != nil {
        fmt.Println("Erreur:", err)
    } else {
        fmt.Printf("%.4f\n", res)   // → 3.3333
    }

    _, err2 := diviser(10, 0)
    if err2 != nil {
        fmt.Println(err2)   // → division par zero
    }
}`,
    },
    {
      title: "Slices et Maps",
      description: "Les slices sont des tableaux dynamiques. append() ajoute des éléments. Les maps sont des dictionnaires. make() crée une slice ou map vide. La virgule-ok idiom vérifie si une clé existe.",
      example: `package main

import "fmt"

func main() {
    // Slice dynamique
    fruits := []string{"pomme", "banane"}
    fruits = append(fruits, "kiwi")
    fmt.Println(fruits)      // → [pomme banane kiwi]
    fmt.Println(len(fruits)) // → 3

    // Map (dictionnaire)
    ages := map[string]int{
        "Alice": 25,
        "Bob":   30,
    }
    ages["Charlie"] = 22
    fmt.Println(ages["Alice"])  // → 25

    // Vérifier existence
    val, ok := ages["Dave"]
    fmt.Println(val, ok)   // → 0 false
}`,
    },
  ]},
];

// ═══════════════════════════════════════════════════════
//  RUST
// ═══════════════════════════════════════════════════════
const RUST: Category[] = [
  { emoji: "🏗️", name: "Structure Rust", lessons: [
    {
      title: "Variables et mutabilité",
      description: "En Rust, toutes les variables sont IMMUTABLES par défaut. Il faut explicitement écrire mut pour rendre une variable modifiable. Les fonctions sont définies avec fn. println! est une macro (note le !).",
      example: `fn main() {
    let nom = "Ibo";     // immutable par défaut
    let mut score = 0;   // mut = modifiable

    println!("Bonjour {} !", nom);   // → Bonjour Ibo !
    println!("Score: {}", score);    // → Score: 0

    score += 10;
    println!("Nouveau score: {}", score);  // → Nouveau score: 10

    // nom = "Bob";  // ERREUR: immutable !
    // score = "dix"; // ERREUR: mauvais type !
}`,
    },
    {
      title: "Types en Rust",
      description: "Rust est très fortement typé. i32 est le type entier par défaut, f64 pour les flottants, bool pour les booléens. &str est une référence vers une chaîne (souvent littérale), String est une chaîne propriétaire.",
      example: `fn main() {
    let entier: i32 = 42;
    let grand: i64 = 1_000_000;  // underscores pour la lisibilité
    let decimal: f64 = 3.14;
    let vrai: bool = true;
    let texte: &str = "Bonjour";    // référence
    let texte2 = String::from("Monde");  // String propriétaire

    println!("{} {} {} {} {} {}", entier, grand, decimal, vrai, texte, texte2);
    // → 42 1000000 3.14 true Bonjour Monde

    println!("{:?}", (entier, vrai));  // debug
    // → (42, true)
}`,
    },
  ]},
  { emoji: "🔀", name: "Conditions & Boucles", lessons: [
    {
      title: "if — expression en Rust",
      description: "En Rust, if est une EXPRESSION qui retourne une valeur. Pas de parenthèses autour de la condition. Le dernier bloc détermine la valeur retournée (sans point-virgule à la fin).",
      example: `fn main() {
    let note = 14;

    if note >= 16 {
        println!("Tres bien");
    } else if note >= 10 {
        println!("Passable");   // → Passable
    } else {
        println!("Insuffisant");
    }

    // if comme expression (retourne une valeur)
    let statut = if note >= 10 { "admis" } else { "recale" };
    println!("{}", statut);   // → admis

    // Ternaire-like
    let emoji = if note >= 10 { "ok" } else { "non" };
    println!("{}", emoji);    // → ok
}`,
    },
    {
      title: "loop, while, for et range",
      description: "loop crée une boucle infinie (break pour sortir, et break peut retourner une valeur). while avec condition. for...in avec des plages (ranges) ou des itérateurs.",
      example: `fn main() {
    // for avec range (0..5 = 0 à 4 inclus)
    for i in 0..5 {
        print!("{} ", i);
    }
    println!();   // → 0 1 2 3 4

    // for avec range inclus (0..=5)
    for i in 0..=5 {
        print!("{} ", i);
    }
    println!();   // → 0 1 2 3 4 5

    // Parcourir un vecteur
    let fruits = vec!["pomme", "banane", "kiwi"];
    for f in &fruits {
        println!("{}", f);
    }
    // → pomme   banane   kiwi
}`,
    },
  ]},
  { emoji: "🧩", name: "Fonctions & Vecteurs", lessons: [
    {
      title: "Fonctions Rust",
      description: "fn nom(param: type) -> typeRetour {}. La dernière expression sans point-virgule est retournée automatiquement. return existe aussi pour quitter plus tôt. &str pour les références de chaîne, String pour les chaînes propriétaires.",
      example: `fn additionner(a: i32, b: i32) -> i32 {
    a + b   // pas de ; = retour implicite
}

fn saluer(nom: &str) -> String {
    format!("Bonjour {} !", nom)
}

fn est_pair(n: i32) -> bool {
    n % 2 == 0
}

fn main() {
    println!("{}", additionner(3, 7));   // → 10
    println!("{}", saluer("Ibo"));       // → Bonjour Ibo !
    println!("{}", est_pair(4));         // → true
    println!("{}", est_pair(7));         // → false
}`,
    },
    {
      title: "Vec<T> et ownership simplifié",
      description: "Vec<T> est le vecteur dynamique de Rust. vec! créée un vecteur avec des valeurs initiales. push() ajoute. L'ownership (propriété) est le concept central de Rust : & emprunte sans prendre la propriété, &mut pour emprunter de façon mutable.",
      example: `fn afficher(v: &Vec<i32>) {  // emprunte sans prendre
    for n in v {
        print!("{} ", n);
    }
    println!();
}

fn main() {
    let mut nombres = vec![1, 2, 3, 4, 5];
    nombres.push(6);

    afficher(&nombres);      // → 1 2 3 4 5 6
    println!("{}", nombres.len());   // → 6

    // On peut encore utiliser nombres car on a seulement emprunté
    println!("{}", nombres[0]);   // → 1

    // Filtrer et transformer
    let pairs: Vec<i32> = nombres.iter()
        .filter(|&&x| x % 2 == 0)
        .copied()
        .collect();
    println!("{:?}", pairs);   // → [2, 4, 6]
}`,
    },
  ]},
];

// ═══════════════════════════════════════════════════════
//  REGISTRY
// ═══════════════════════════════════════════════════════
const LESSONS_BY_LANG: Record<string, Category[]> = {
  python:     PYTHON,
  javascript: JAVASCRIPT,
  html:       HTML,
  typescript: TYPESCRIPT,
  lua:        LUA,
  java:       JAVA,
  cpp:        CPP,
  php:        PHP,
  go:         GO,
  rust:       RUST,
};

const LANG_DISPLAY: Record<string, { name: string; emoji: string }> = {
  python:     { name: "Python",     emoji: "🐍" },
  javascript: { name: "JavaScript", emoji: "⚡" },
  html:       { name: "HTML/CSS",   emoji: "🌐" },
  typescript: { name: "TypeScript", emoji: "🔷" },
  lua:        { name: "Lua",        emoji: "🌙" },
  java:       { name: "Java",       emoji: "☕" },
  cpp:        { name: "C++",        emoji: "⚙️"  },
  php:        { name: "PHP",        emoji: "🐘" },
  go:         { name: "Go",         emoji: "🚀" },
  rust:       { name: "Rust",       emoji: "🦀" },
};

interface LearningPanelProps {
  onClose: () => void;
  language: string;
}

export function LearningPanel({ onClose, language }: LearningPanelProps) {
  const categories = LESSONS_BY_LANG[language] ?? LESSONS_BY_LANG.python;
  const display = LANG_DISPLAY[language] ?? { name: language, emoji: "📄" };
  const totalLessons = categories.reduce((a, c) => a + c.lessons.length, 0);

  const [openCategory, setOpenCategory] = useState<string | null>(categories[0]?.name ?? null);
  const [openLesson, setOpenLesson] = useState<string | null>(null);
  const [search, setSearch] = useState("");

  const filtered = search.trim()
    ? categories.map(cat => ({
        ...cat,
        lessons: cat.lessons.filter(l =>
          l.title.toLowerCase().includes(search.toLowerCase()) ||
          l.description.toLowerCase().includes(search.toLowerCase())
        ),
      })).filter(cat => cat.lessons.length > 0)
    : categories;

  return (
    <div className="fixed inset-0 z-50 flex flex-col bg-[#0a0f1e]">
      {/* Header */}
      <div className="border-b border-white/5 shrink-0 bg-[#0a0f1e]">
        <div className="h-14 flex items-center justify-between px-4">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-gradient-to-br from-emerald-500 to-cyan-500 flex items-center justify-center shrink-0">
              <span className="text-xs font-bold text-white">A</span>
            </div>
            <div>
              <span className="text-sm font-semibold text-zinc-200">{display.emoji} {display.name}</span>
              <span className="ml-2 text-xs text-zinc-600">{totalLessons} leçons</span>
            </div>
          </div>
          <button onClick={onClose} className="w-8 h-8 flex items-center justify-center rounded-xl text-zinc-500 hover:text-zinc-300 hover:bg-white/5 transition">
            <X className="w-4 h-4" />
          </button>
        </div>
        <div className="px-4 pb-3">
          <div className="flex items-center gap-2 bg-white/5 border border-white/8 rounded-xl px-3 py-2 focus-within:border-emerald-500/30 transition-colors">
            <Search className="w-3.5 h-3.5 text-zinc-500 shrink-0" />
            <input
              type="text"
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder={`Chercher dans ${display.name}...`}
              className="flex-1 bg-transparent text-sm text-zinc-300 outline-none placeholder:text-zinc-600"
            />
          </div>
        </div>
      </div>

      <div className="flex-1 overflow-auto p-3 space-y-2">
        {filtered.length === 0 && (
          <div className="text-center py-10 text-zinc-600 text-sm">Aucun résultat pour &ldquo;{search}&rdquo;</div>
        )}
        {filtered.map((cat) => (
          <div key={cat.name} className="rounded-2xl border border-white/5 overflow-hidden">
            <button
              className="w-full flex items-center justify-between px-4 py-3 bg-white/4 hover:bg-white/7 transition text-left"
              onClick={() => {
                setOpenCategory(openCategory === cat.name ? null : cat.name);
                setOpenLesson(null);
              }}
            >
              <div className="flex items-center gap-2">
                <span className="text-base">{cat.emoji}</span>
                <span className="text-sm font-semibold text-zinc-200">{cat.name}</span>
                <span className="text-xs text-zinc-600 bg-white/5 px-1.5 py-0.5 rounded-full">{cat.lessons.length}</span>
              </div>
              {(openCategory === cat.name || search.trim())
                ? <ChevronDown className="w-4 h-4 text-zinc-500 shrink-0" />
                : <ChevronRight className="w-4 h-4 text-zinc-500 shrink-0" />
              }
            </button>

            {(openCategory === cat.name || search.trim()) && (
              <div className="divide-y divide-white/4">
                {cat.lessons.map((lesson) => {
                  const key = `${cat.name}::${lesson.title}`;
                  const isOpen = openLesson === key;
                  return (
                    <div key={lesson.title}>
                      <button
                        className="w-full flex items-center justify-between px-4 py-3 hover:bg-white/5 transition text-left"
                        onClick={() => setOpenLesson(isOpen ? null : key)}
                      >
                        <span className="text-sm font-mono text-violet-300">{lesson.title}</span>
                        {isOpen
                          ? <ChevronDown className="w-3.5 h-3.5 text-zinc-600 shrink-0" />
                          : <ChevronRight className="w-3.5 h-3.5 text-zinc-600 shrink-0" />
                        }
                      </button>
                      {isOpen && (
                        <div className="px-4 pb-4 space-y-3">
                          <p className="text-sm text-zinc-300 leading-relaxed">{lesson.description}</p>
                          <div className="rounded-xl overflow-hidden border border-white/5">
                            <div className="px-3 py-1.5 bg-white/5 border-b border-white/5 flex items-center gap-2">
                              <span className="text-xs text-zinc-600 font-mono">exemple de code</span>
                              <span className="text-xs text-zinc-700">· les lignes avec # → ou // → montrent ce qui s'affiche</span>
                            </div>
                            <pre className="p-3 text-xs font-mono text-emerald-300 bg-black/40 overflow-x-auto whitespace-pre leading-[1.7]">
                              {lesson.example}
                            </pre>
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
