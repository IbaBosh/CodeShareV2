import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";

export interface Session {
  id: number;
  code: string;
  language: string;
  content: string;
  createdAt: string;
  updatedAt: string;
}

export interface SessionInput {
  language: string;
}

export const getGetSessionQueryKey = (code: string) => [`/api/sessions/${code}`] as const;

async function fetchSession(code: string): Promise<Session> {
  const res = await fetch(`/api/sessions/${code}`);
  if (!res.ok) {
    const err = await res.json().catch(() => ({ error: "Session introuvable" }));
    throw new Error(err.error ?? "Session introuvable");
  }
  return res.json();
}

export function useGetSession(
  code: string,
  options?: { query?: { retry?: boolean } }
) {
  return useQuery({
    queryKey: getGetSessionQueryKey(code),
    queryFn: () => fetchSession(code),
    retry: options?.query?.retry ?? false,
    enabled: !!code,
  });
}

export function useCreateSession() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (vars: { data: SessionInput }) => {
      const res = await fetch("/api/sessions", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(vars.data),
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({ error: "Erreur création" }));
        throw new Error(err.error ?? "Erreur création");
      }
      return res.json() as Promise<Session>;
    },
    onSuccess: (session) => {
      queryClient.setQueryData(getGetSessionQueryKey(session.code), session);
    },
  });
}
