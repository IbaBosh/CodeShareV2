import { useState } from "react";
import { useLocation } from "wouter";
import { useCreateSession, getGetSessionQueryKey } from "@/lib/api";
import { useSessionHistory } from "@/hooks/use-session-history";
import { History, ChevronRight, Terminal, Loader2, ChevronDown } from "lucide-react";
import { useQueryClient } from "@tanstack/react-query";
import { formatDistanceToNow } from "date-fns";
import { fr } from "date-fns/locale";

type Language = "python" | "html" | "javascript" | "typescript" | "lua" | "java" | "cpp" | "php" | "go" | "rust";

interface LangInfo {
  id: Language;
  label: string;
  color: string;
  bg: string;
  exec: string;
  emoji: string;
}

const LANGUAGES: LangInfo[] = [
  { id: "python",     label: "Python",      color: "#10b981", bg: "#10b98120", exec: "Exécution complète", emoji: "🐍" },
  { id: "javascript", label: "JavaScript",  color: "#eab308", bg: "#eab30820", exec: "Exécution navigateur", emoji: "⚡" },
  { id: "html",       label: "HTML / CSS",  color: "#f97316", bg: "#f9731620", exec: "Aperçu en direct", emoji: "🌐" },
  { id: "typescript", label: "TypeScript",  color: "#06b6d4", bg: "#06b6d420", exec: "Éditeur avancé", emoji: "🔷" },
  { id: "lua",        label: "Lua",         color: "#a78bfa", bg: "#a78bfa20", exec: "Éditeur avancé", emoji: "🌙" },
  { id: "java",       label: "Java",        color: "#ef4444", bg: "#ef444420", exec: "Éditeur avancé", emoji: "☕" },
  { id: "cpp",        label: "C++",         color: "#8b5cf6", bg: "#8b5cf620", exec: "Éditeur avancé", emoji: "⚙️" },
  { id: "php",        label: "PHP",         color: "#818cf8", bg: "#818cf820", exec: "Éditeur avancé", emoji: "🐘" },
  { id: "go",         label: "Go",          color: "#22d3ee", bg: "#22d3ee20", exec: "Éditeur avancé", emoji: "🚀" },
  { id: "rust",       label: "Rust",        color: "#f59e0b", bg: "#f59e0b20", exec: "Éditeur avancé", emoji: "🦀" },
];

const LANG_COLORS: Record<string, string> = Object.fromEntries(LANGUAGES.map(l => [l.id, l.color]));
export { LANG_COLORS };

export default function Home() {
  const [, setLocation] = useLocation();
  const { history, addSession } = useSessionHistory();
  const createSession = useCreateSession();
  const queryClient = useQueryClient();
  const [joinCode, setJoinCode] = useState("");
  const [isJoining, setIsJoining] = useState(false);
  const [joinError, setJoinError] = useState("");
  const [creatingLang, setCreatingLang] = useState<Language | null>(null);
  const [showAll, setShowAll] = useState(false);

  const handleCreate = (lang: Language) => {
    setCreatingLang(lang);
    createSession.mutate(
      { data: { language: lang } },
      {
        onSuccess: (session) => {
          addSession({ code: session.code, language: session.language as Language });
          setLocation(`/session/${session.code}`);
        },
        onSettled: () => setCreatingLang(null),
      }
    );
  };

  const handleJoin = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setJoinError("");
    const code = joinCode.replace(/\D/g, "");
    if (code.length !== 10) {
      setJoinError("Le code doit comporter exactement 10 chiffres");
      return;
    }
    setIsJoining(true);
    try {
      const session = await queryClient.fetchQuery({
        queryKey: getGetSessionQueryKey(code),
        queryFn: () =>
          fetch(`/api/sessions/${code}`).then((res) => {
            if (!res.ok) throw new Error("Session not found");
            return res.json();
          }),
      });
      addSession({ code: session.code, language: session.language });
      setLocation(`/session/${session.code}`);
    } catch {
      setJoinError("Session introuvable ou expirée");
    } finally {
      setIsJoining(false);
    }
  };

  const primary = LANGUAGES.slice(0, 3);
  const extra = LANGUAGES.slice(3);
  const visibleExtra = showAll ? extra : extra.slice(0, 3);

  return (
    <div className="min-h-[100dvh] bg-[#0d0d1a] flex flex-col items-center px-4 pt-10 pb-8 max-w-md mx-auto">

      {/* Logo */}
      <div className="flex flex-col items-center gap-2 mb-8">
        <div className="w-14 h-14 rounded-2xl bg-violet-600/20 border border-violet-500/30 flex items-center justify-center mb-1">
          <Terminal className="w-7 h-7 text-violet-400" />
        </div>
        <h1 className="text-3xl font-bold tracking-tight text-white">CodeShare</h1>
        <p className="text-sm text-zinc-500">Éditeur collaboratif · 10 langages</p>
      </div>

      {/* Create section */}
      <div className="w-full mb-6">
        <p className="text-xs font-bold text-zinc-600 uppercase tracking-widest mb-3">Nouvelle session</p>

        {/* Primary 3 languages */}
        <div className="space-y-2.5 mb-2.5">
          {primary.map((lang) => (
            <button
              key={lang.id}
              className="w-full h-14 rounded-2xl font-semibold text-white text-sm flex items-center gap-3 px-4 transition-all active:scale-[0.98] disabled:opacity-50 border border-white/5"
              style={{ background: lang.bg, borderColor: `${lang.color}25` }}
              onClick={() => handleCreate(lang.id)}
              disabled={creatingLang !== null}
            >
              {creatingLang === lang.id
                ? <Loader2 className="w-5 h-5 animate-spin" style={{ color: lang.color }} />
                : <span className="text-lg">{lang.emoji}</span>
              }
              <div className="text-left flex-1">
                <div className="font-bold" style={{ color: lang.color }}>{lang.label}</div>
                <div className="text-xs text-zinc-500 font-normal">{lang.exec}</div>
              </div>
            </button>
          ))}
        </div>

        {/* Extra languages grid */}
        <div className="grid grid-cols-3 gap-2">
          {visibleExtra.map((lang) => (
            <button
              key={lang.id}
              className="h-20 rounded-2xl flex flex-col items-center justify-center gap-1.5 transition-all active:scale-[0.97] disabled:opacity-50 border border-white/5"
              style={{ background: lang.bg, borderColor: `${lang.color}20` }}
              onClick={() => handleCreate(lang.id)}
              disabled={creatingLang !== null}
            >
              {creatingLang === lang.id
                ? <Loader2 className="w-5 h-5 animate-spin" style={{ color: lang.color }} />
                : <span className="text-2xl">{lang.emoji}</span>
              }
              <span className="text-xs font-semibold" style={{ color: lang.color }}>{lang.label}</span>
            </button>
          ))}
        </div>

        {!showAll && (
          <button
            className="w-full mt-2 py-2.5 rounded-xl text-xs text-zinc-500 hover:text-zinc-300 flex items-center justify-center gap-1 transition hover:bg-white/4"
            onClick={() => setShowAll(true)}
          >
            <ChevronDown className="w-3.5 h-3.5" />
            Voir Go, PHP, Rust, C++...
          </button>
        )}
      </div>

      {/* Divider */}
      <div className="w-full flex items-center gap-3 mb-6">
        <div className="flex-1 h-px bg-white/6" />
        <span className="text-xs text-zinc-600 uppercase tracking-widest">ou rejoindre</span>
        <div className="flex-1 h-px bg-white/6" />
      </div>

      {/* Join section */}
      <div className="w-full mb-6">
        <form onSubmit={handleJoin} className="space-y-2.5">
          <div className="flex gap-2">
            <input
              className="flex-1 h-14 rounded-2xl bg-white/5 border border-white/8 text-white font-mono text-lg text-center tracking-widest placeholder:text-zinc-700 outline-none focus:border-violet-500/50 focus:bg-violet-500/5 transition-all"
              placeholder="0000000000"
              value={joinCode}
              onChange={(e) => setJoinCode(e.target.value.replace(/\D/g, "").slice(0, 10))}
              inputMode="numeric"
              type="text"
            />
            <button
              type="submit"
              className="h-14 px-5 rounded-2xl font-semibold text-white bg-violet-600 hover:bg-violet-500 transition-all active:scale-[0.98] disabled:opacity-60"
              disabled={isJoining || joinCode.length !== 10}
            >
              {isJoining ? <Loader2 className="w-5 h-5 animate-spin" /> : "Rejoindre"}
            </button>
          </div>
          {joinError && <p className="text-red-400 text-xs text-center">{joinError}</p>}
        </form>
      </div>

      {/* History */}
      {history.length > 0 && (
        <div className="w-full">
          <div className="flex items-center gap-2 mb-3">
            <History className="w-3.5 h-3.5 text-zinc-600" />
            <p className="text-xs font-bold text-zinc-600 uppercase tracking-widest">Sessions récentes</p>
          </div>
          <div className="space-y-2">
            {history.slice(0, 5).map((item) => {
              const langInfo = LANGUAGES.find(l => l.id === item.language);
              const color = langInfo?.color ?? "#6b7280";
              const bg = langInfo?.bg ?? "#6b728015";
              const emoji = langInfo?.emoji ?? "📄";
              return (
                <button
                  key={item.code}
                  className="w-full flex items-center gap-3 p-3.5 rounded-2xl bg-white/4 hover:bg-white/7 border border-white/5 transition-all active:scale-[0.99] text-left"
                  onClick={() => setLocation(`/session/${item.code}`)}
                >
                  <div className="w-9 h-9 rounded-xl flex items-center justify-center shrink-0 text-lg" style={{ background: bg }}>
                    {emoji}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-mono text-sm font-medium text-zinc-200">{item.code}</p>
                    <p className="text-xs mt-0.5 capitalize" style={{ color }}>{item.language} · {formatDistanceToNow(new Date(item.lastAccessed), { addSuffix: true, locale: fr })}</p>
                  </div>
                  <ChevronRight className="w-4 h-4 text-zinc-600 shrink-0" />
                </button>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}
