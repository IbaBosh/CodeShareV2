import { useState, useEffect, useRef, useCallback } from "react";
import { useParams, useLocation } from "wouter";
import { useGetSession } from "@/lib/api";
import { useWebSocket } from "@/hooks/use-websocket";
import { useSessionHistory } from "@/hooks/use-session-history";
import { CodeEditor, type CodeEditorHandle } from "@/components/code-editor";
import { AIPanel } from "@/components/ai-panel";
import { LearningPanel } from "@/components/learning-panel";
import {
  Play, Settings, Copy, Check, X, MonitorPlay, Trash2,
  Clipboard, Code, ChevronLeft, AlertTriangle, Users, Square,
  BookOpen, Wand2, Lightbulb, ExternalLink,
} from "lucide-react";

async function deleteSessionApi(code: string) {
  const res = await fetch(`/api/sessions/${code}`, { method: "DELETE" });
  if (!res.ok) throw new Error("Failed to delete session");
}

async function callAIFix(code: string, error: string, language: string) {
  const res = await fetch("/api/ai/fix", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ code, error, language }),
  });
  if (!res.ok) throw new Error("AI error");
  return res.json() as Promise<{ explanation: string; fixedCode: string | null; lines: number[] }>;
}

type ConsoleLine =
  | { kind: "output"; text: string; isError?: boolean }
  | { kind: "user_input"; value: string };

let lineId = 0;
const mkId = () => String(++lineId);

const AI_AUTOCORRECT_KEY = "codeshare_ai_autocorrect";

const LANG_INFO: Record<string, { color: string; emoji: string; label: string; execMode: "python" | "javascript" | "html" | "none" }> = {
  python:     { color: "#10b981", emoji: "🐍", label: "Python",     execMode: "python" },
  javascript: { color: "#eab308", emoji: "⚡", label: "JavaScript", execMode: "javascript" },
  html:       { color: "#f97316", emoji: "🌐", label: "HTML/CSS",   execMode: "html" },
  typescript: { color: "#06b6d4", emoji: "🔷", label: "TypeScript", execMode: "none" },
  lua:        { color: "#a78bfa", emoji: "🌙", label: "Lua",        execMode: "none" },
  java:       { color: "#ef4444", emoji: "☕", label: "Java",       execMode: "none" },
  cpp:        { color: "#8b5cf6", emoji: "⚙️",  label: "C++",       execMode: "none" },
  php:        { color: "#818cf8", emoji: "🐘", label: "PHP",        execMode: "none" },
  go:         { color: "#22d3ee", emoji: "🚀", label: "Go",         execMode: "none" },
  rust:       { color: "#f59e0b", emoji: "🦀", label: "Rust",       execMode: "none" },
};

export default function Session() {
  const params = useParams();
  const code = params.code as string;
  const [, setLocation] = useLocation();
  const { addSession, removeSession } = useSessionHistory();

  const { data: session, isLoading, error } = useGetSession(code, { query: { retry: false } });

  const [content, setContent] = useState("");
  const codeEditorRef = useRef<CodeEditorHandle>(null);

  const [consoleLines, setConsoleLines] = useState<Array<ConsoleLine & { id: string }>>([]);
  const [isRunning, setIsRunning] = useState(false);
  const [isConsoleOpen, setIsConsoleOpen] = useState(false);
  const [showPreview, setShowPreview] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [copiedCode, setCopiedCode] = useState(false);
  const [copiedSession, setCopiedSession] = useState(false);
  const [userCount, setUserCount] = useState(1);
  const [joinToast, setJoinToast] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);
  const [showAI, setShowAI] = useState(false);
  const [showLearning, setShowLearning] = useState(false);

  const [aiAutoCorrect, setAiAutoCorrect] = useState(() => localStorage.getItem(AI_AUTOCORRECT_KEY) === "true");
  const [aiFix, setAiFix] = useState<{ explanation: string; fixedCode: string | null; lines: number[] } | null>(null);
  const [aiFixLoading, setAiFixLoading] = useState(false);
  const [aiFixApplied, setAiFixApplied] = useState(false);

  const [inputValue, setInputValue] = useState("");
  const [waitingInput, setWaitingInput] = useState(false);
  const [inputPrompt, setInputPrompt] = useState("");
  const inputRef = useRef<HTMLInputElement>(null);
  const consoleEndRef = useRef<HTMLDivElement>(null);
  const jsCleanupRef = useRef<(() => void) | null>(null);

  const contentRef = useRef(content);
  useEffect(() => { contentRef.current = content; }, [content]);

  const lastErrorRef = useRef<string>("");

  useEffect(() => {
    if (waitingInput) setTimeout(() => inputRef.current?.focus(), 50);
  }, [waitingInput]);

  useEffect(() => {
    consoleEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [consoleLines, waitingInput]);

  const addLine = useCallback((line: ConsoleLine) => {
    setConsoleLines(prev => [...prev, { ...line, id: mkId() }]);
  }, []);

  const handleInitCode = useCallback((c: string) => {
    setContent(c);
    codeEditorRef.current?.setValue(c);
  }, []);

  const handleCodeUpdate = useCallback((c: string) => {
    setContent(c);
    codeEditorRef.current?.setValue(c);
  }, []);

  const handleUserJoined = useCallback(() => {
    setJoinToast(true);
    setTimeout(() => setJoinToast(false), 4000);
  }, []);

  const handleUserCount = useCallback((n: number) => setUserCount(n), []);

  const handleOutputChunk = useCallback((text: string, isError: boolean) => {
    if (!text) return;
    if (isError) lastErrorRef.current += text;
    const lines = text.split(/(?<=\n)/);
    for (const line of lines) {
      if (line) addLine({ kind: "output", text: line, isError });
    }
  }, [addLine]);

  const handleInputNeeded = useCallback((prompt: string) => {
    setInputPrompt(prompt);
    setWaitingInput(true);
  }, []);

  const handleExecutionDone = useCallback(async (exitCode: number) => {
    setIsRunning(false);
    setWaitingInput(false);

    if (exitCode !== 0 && exitCode !== -1) {
      addLine({ kind: "output", text: `\nProcess exited with code ${exitCode}\n`, isError: true });
      if (aiAutoCorrect && lastErrorRef.current && contentRef.current) {
        setAiFixLoading(true);
        setAiFix(null);
        try {
          const fix = await callAIFix(contentRef.current, lastErrorRef.current, session?.language ?? "python");
          setAiFix(fix);
        } catch { /* silent */ }
        finally { setAiFixLoading(false); }
      }
    } else if (exitCode === -1) {
      addLine({ kind: "output", text: "Execution stopped.\n", isError: false });
    }
  }, [aiAutoCorrect, addLine, session?.language]);

  const handleSessionNotFound = useCallback(() => {
    setLocation("/");
  }, [setLocation]);

  const { status, sendCodeUpdate, sendExecute, sendInputResponse, sendKill } = useWebSocket({
    sessionCode: code,
    onInitCode: handleInitCode,
    onCodeUpdate: handleCodeUpdate,
    onUserJoined: handleUserJoined,
    onUserCount: handleUserCount,
    onOutputChunk: handleOutputChunk,
    onInputNeeded: handleInputNeeded,
    onExecutionDone: handleExecutionDone,
    onSessionNotFound: handleSessionNotFound,
  });

  useEffect(() => {
    if (session) addSession({ code: session.code, language: session.language });
  }, [session]); // eslint-disable-line

  const handleCodeChange = useCallback((val: string) => {
    setContent(val);
    sendCodeUpdate(val);
  }, [sendCodeUpdate]);

  // --- JavaScript browser execution ---
  const executeJavaScript = useCallback(() => {
    const currentCode = contentRef.current;
    setConsoleLines([]);
    setIsRunning(true);
    setIsConsoleOpen(true);
    setShowPreview(false);
    setAiFix(null);
    lastErrorRef.current = "";
    addLine({ kind: "output", text: "⚡ Exécution JavaScript...\n" });

    const iframe = document.createElement("iframe");
    iframe.setAttribute("sandbox", "allow-scripts");
    iframe.style.cssText = "display:none;position:absolute;width:0;height:0;";
    document.body.appendChild(iframe);

    let done = false;

    const cleanup = () => {
      if (done) return;
      done = true;
      clearTimeout(timeoutId);
      window.removeEventListener("message", handler);
      if (document.body.contains(iframe)) document.body.removeChild(iframe);
    };

    jsCleanupRef.current = () => {
      cleanup();
      addLine({ kind: "output", text: "■ Arrêté.\n", isError: false });
      setIsRunning(false);
    };

    const timeoutId = setTimeout(() => {
      cleanup();
      addLine({ kind: "output", text: "\n⏱ Timeout : exécution interrompue après 10s.\n", isError: true });
      setIsRunning(false);
    }, 10000);

    const handler = (event: MessageEvent) => {
      if (!event.data || typeof event.data !== "object") return;
      const { type, text, exitCode } = event.data as { type: string; text?: string; exitCode?: number };
      if (type === "log") {
        addLine({ kind: "output", text: (text ?? "") + "\n" });
      } else if (type === "error") {
        addLine({ kind: "output", text: (text ?? "") + "\n", isError: true });
        lastErrorRef.current += (text ?? "") + "\n";
      } else if (type === "done") {
        cleanup();
        if ((exitCode ?? 0) !== 0) {
          addLine({ kind: "output", text: `\nCode de sortie : ${exitCode}\n`, isError: true });
          if (aiAutoCorrect && lastErrorRef.current) {
            setAiFixLoading(true);
            callAIFix(currentCode, lastErrorRef.current, "javascript")
              .then(fix => setAiFix(fix))
              .catch(() => {})
              .finally(() => setAiFixLoading(false));
          }
        }
        setIsRunning(false);
      }
    };

    window.addEventListener("message", handler);

    const escaped = currentCode.replace(/<\/script>/gi, "<\\/script>");
    iframe.srcdoc = `<!DOCTYPE html><html><body><script>(function(){
  function _s(v){
    if(v===null)return'null';
    if(v===undefined)return'undefined';
    if(typeof v==='function')return'[Function: '+v.name+']';
    if(typeof v==='object'){try{return JSON.stringify(v,null,2);}catch(e){return String(v);}}
    return String(v);
  }
  function _send(type,args){
    window.parent.postMessage({type:type,text:args.map(_s).join(' ')},'*');
  }
  console.log=function(){_send('log',[].slice.call(arguments));};
  console.info=function(){_send('log',[].slice.call(arguments));};
  console.warn=function(){_send('log',[].slice.call(arguments));};
  console.error=function(){_send('error',[].slice.call(arguments));};
  console.debug=function(){_send('log',[].slice.call(arguments));};
  window.onerror=function(msg,src,line,col,err){
    var txt=err?(err.stack||err.toString()):String(msg);
    if(line)txt+=' (ligne '+line+')';
    window.parent.postMessage({type:'error',text:txt},'*');
    window.parent.postMessage({type:'done',exitCode:1},'*');
    return true;
  };
  window.addEventListener('unhandledrejection',function(e){
    window.parent.postMessage({type:'error',text:'Promesse rejetée: '+e.reason},'*');
    window.parent.postMessage({type:'done',exitCode:1},'*');
  });
  try{
    ${escaped}
    window.parent.postMessage({type:'done',exitCode:0},'*');
  }catch(e){
    window.parent.postMessage({type:'error',text:e.stack||e.toString()},'*');
    window.parent.postMessage({type:'done',exitCode:1},'*');
  }
})();<\/script></body></html>`;
  }, [addLine, aiAutoCorrect]);

  const handleExecute = useCallback(() => {
    const lang = session?.language ?? "python";
    const execMode = LANG_INFO[lang]?.execMode ?? "none";

    if (execMode === "html") {
      setShowPreview(true);
      setIsConsoleOpen(false);
      return;
    }
    if (execMode === "javascript") {
      executeJavaScript();
      return;
    }
    if (execMode === "python") {
      setConsoleLines([]);
      setIsRunning(true);
      setIsConsoleOpen(true);
      setShowPreview(false);
      setWaitingInput(false);
      setAiFix(null);
      lastErrorRef.current = "";
      addLine({ kind: "output", text: "🐍 Exécution Python...\n" });
      sendExecute(contentRef.current);
      return;
    }
    // none — show info in console
    setConsoleLines([]);
    setIsConsoleOpen(true);
    const online: Record<string, string> = {
      typescript: "https://www.typescriptlang.org/play",
      java: "https://onecompiler.com/java",
      cpp: "https://onecompiler.com/cpp",
      lua: "https://www.lua.org/demo.html",
      php: "https://onecompiler.com/php",
      go: "https://go.dev/play",
      rust: "https://play.rust-lang.org",
    };
    addLine({ kind: "output", text: `⚙️  L'exécution ${lang.toUpperCase()} n'est pas encore disponible ici.\n`, isError: false });
    addLine({ kind: "output", text: `💡 Copie ton code et colle-le sur : ${online[lang] ?? "onecompiler.com"}\n`, isError: false });
  }, [session?.language, executeJavaScript, addLine, sendExecute]);

  const handleStop = useCallback(() => {
    const lang = session?.language ?? "python";
    const execMode = LANG_INFO[lang]?.execMode ?? "none";
    if (execMode === "javascript") {
      jsCleanupRef.current?.();
      jsCleanupRef.current = null;
    } else {
      sendKill();
    }
    setIsRunning(false);
    setWaitingInput(false);
  }, [session?.language, sendKill]);

  const handleInputSubmit = (e?: React.FormEvent) => {
    e?.preventDefault();
    if (!waitingInput) return;
    const val = inputValue;
    addLine({ kind: "user_input", value: (inputPrompt || "") + val });
    setInputValue("");
    setWaitingInput(false);
    setInputPrompt("");
    sendInputResponse(val);
  };

  const applyCode = useCallback((newCode: string) => {
    setContent(newCode);
    codeEditorRef.current?.setValue(newCode);
    sendCodeUpdate(newCode);
  }, [sendCodeUpdate]);

  const handleApplyAIFix = () => {
    if (!aiFix?.fixedCode) return;
    applyCode(aiFix.fixedCode);
    setAiFixApplied(true);
    setTimeout(() => { setAiFixApplied(false); setAiFix(null); }, 1500);
  };

  const handleCopyEditorCode = () => {
    navigator.clipboard.writeText(content);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  const handleCopySessionCode = () => {
    navigator.clipboard.writeText(code);
    setCopiedSession(true);
    setTimeout(() => setCopiedSession(false), 2000);
  };

  const handleDeleteSession = async () => {
    setIsDeleting(true);
    try {
      await deleteSessionApi(code);
      removeSession(code);
      setLocation("/");
    } catch { setIsDeleting(false); }
  };

  const toggleAutoCorrect = () => {
    const next = !aiAutoCorrect;
    setAiAutoCorrect(next);
    localStorage.setItem(AI_AUTOCORRECT_KEY, String(next));
  };

  const lang = session?.language ?? "python";
  const langInfo = LANG_INFO[lang] ?? LANG_INFO.python;
  const execMode = langInfo.execMode;

  const execButtonLabel = execMode === "python" ? "Exécuter" : execMode === "javascript" ? "Exécuter JS" : execMode === "html" ? "Aperçu HTML" : "Voir compilateur";
  const execButtonColor = langInfo.color;

  if (isLoading) {
    return (
      <div className="min-h-[100dvh] flex flex-col items-center justify-center gap-6 bg-[#0d0d1a]">
        <div className="w-10 h-10 rounded-full border-2 border-violet-500 border-t-transparent animate-spin" />
        <p className="text-sm text-zinc-500 tracking-widest uppercase">Connexion...</p>
      </div>
    );
  }

  if (error || !session) {
    return (
      <div className="min-h-[100dvh] flex flex-col items-center justify-center gap-4 bg-[#0d0d1a] p-6">
        <AlertTriangle className="w-10 h-10 text-red-500" />
        <p className="text-zinc-300 font-medium">Session introuvable ou expirée</p>
        <button onClick={() => setLocation("/")} className="mt-2 px-6 py-3 rounded-xl bg-violet-600 text-white text-sm font-medium">
          Retour à l'accueil
        </button>
      </div>
    );
  }

  return (
    <div className="min-h-[100dvh] flex flex-col bg-[#0d0d1a] relative overflow-hidden">

      {/* Join toast */}
      {joinToast && (
        <div className="absolute top-4 left-1/2 -translate-x-1/2 z-[60] flex items-center gap-2 px-4 py-2.5 rounded-2xl bg-emerald-500/20 border border-emerald-500/30 backdrop-blur-sm text-emerald-400 text-sm font-medium shadow-xl animate-in fade-in slide-in-from-top-2 duration-300">
          <Users className="w-4 h-4" />
          Un ami a rejoint !
        </div>
      )}

      {/* Header */}
      <header className="h-14 border-b border-white/5 flex items-center justify-between px-2 shrink-0 bg-[#0d0d1a]/95 backdrop-blur-sm gap-1 relative z-10">
        <div className="flex items-center gap-1.5 shrink-0">
          <button className="w-9 h-9 flex items-center justify-center rounded-xl text-zinc-500 hover:text-zinc-300 hover:bg-white/5 transition-all" onClick={() => setLocation("/")}>
            <ChevronLeft className="w-5 h-5" />
          </button>
          <span className="text-xs font-bold tracking-widest px-2 py-1 rounded-lg" style={{ color: langInfo.color, background: `${langInfo.color}18`, border: `1px solid ${langInfo.color}30` }}>
            {langInfo.emoji} {langInfo.label.toUpperCase()}
          </span>
        </div>

        <div className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-white/5 border border-white/8 min-w-0">
          <div className={`w-1.5 h-1.5 rounded-full shrink-0 ${status === "connected" ? "bg-emerald-500" : status === "connecting" ? "bg-yellow-500 animate-pulse" : "bg-red-500"}`} />
          <span className="text-xs font-mono text-zinc-400 tracking-wider truncate">{code}</span>
          {userCount > 1 && (
            <span className="text-xs text-violet-400 font-medium shrink-0">{userCount} 👥</span>
          )}
        </div>

        <div className="flex items-center gap-1 shrink-0">
          <button
            className="h-8 px-2 flex items-center gap-1 rounded-xl text-xs font-semibold transition-all border"
            style={{ color: "#34d399", background: "#34d39910", borderColor: "#34d39925" }}
            onClick={() => { setShowLearning(true); setShowAI(false); setIsSettingsOpen(false); }}
          >
            <BookOpen className="w-3.5 h-3.5" />
            <span className="hidden xs:inline">Apprendre</span>
          </button>

          <button
            className="h-8 px-2 flex items-center gap-1 rounded-xl text-violet-400 text-xs font-semibold bg-violet-500/10 hover:bg-violet-500/20 transition-all border border-violet-500/20"
            onClick={() => { setShowAI(true); setShowLearning(false); setIsSettingsOpen(false); }}
          >
            <Wand2 className="w-3.5 h-3.5" />
            <span className="hidden xs:inline">IA</span>
          </button>

          <button
            className="w-8 h-8 flex items-center justify-center rounded-xl text-zinc-400 hover:text-zinc-200 hover:bg-white/8 transition-all"
            onClick={() => { setIsSettingsOpen(prev => !prev); setShowAI(false); setShowLearning(false); setShowDeleteConfirm(false); }}
          >
            <Settings className="w-4 h-4" />
          </button>
        </div>
      </header>

      {/* Editor */}
      <main className="flex-1 relative flex flex-col min-h-0 overflow-hidden">
        <CodeEditor
          ref={codeEditorRef}
          value={content}
          language={lang}
          onChange={handleCodeChange}
        />

        {/* HTML Preview — full-screen modal */}
        {showPreview && execMode === "html" && (
          <div className="fixed inset-0 z-[60] flex flex-col bg-white">
            <div className="h-12 bg-[#1a1a2e] border-b border-white/10 flex items-center justify-between px-4 shrink-0">
              <div className="flex items-center gap-2">
                <span className="text-sm font-semibold text-zinc-200">🌐 Aperçu HTML/CSS</span>
              </div>
              <div className="flex items-center gap-2">
                <button
                  className="h-8 px-3 rounded-lg text-xs font-medium text-zinc-300 hover:text-white bg-white/8 hover:bg-white/15 transition flex items-center gap-1.5"
                  onClick={() => {
                    const b = window.open("", "_blank");
                    if (b) { b.document.write(content); b.document.close(); }
                  }}
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                  Ouvrir
                </button>
                <button
                  className="w-8 h-8 flex items-center justify-center rounded-lg bg-red-500/15 text-red-400 hover:bg-red-500/25 transition"
                  onClick={() => setShowPreview(false)}
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>
            <iframe
              srcDoc={content}
              className="flex-1 w-full border-none"
              title="Aperçu HTML"
              sandbox="allow-scripts allow-forms allow-modals"
            />
          </div>
        )}
      </main>

      {/* AI auto-fix banner */}
      {(aiFix || aiFixLoading) && !isRunning && (
        <div className="mx-3 mb-2 p-3 rounded-2xl bg-violet-500/10 border border-violet-500/20 space-y-2 shrink-0">
          {aiFixLoading ? (
            <div className="flex items-center gap-2 text-violet-400 text-sm">
              <div className="w-4 h-4 border-2 border-violet-400 border-t-transparent rounded-full animate-spin" />
              Analyse IA en cours...
            </div>
          ) : aiFix && (
            <>
              <div className="flex items-start gap-2">
                <Lightbulb className="w-4 h-4 text-violet-400 mt-0.5 shrink-0" />
                <div className="space-y-1 flex-1">
                  {aiFix.lines.length > 0 && (
                    <p className="text-xs font-semibold text-violet-400">Ligne{aiFix.lines.length > 1 ? "s" : ""} {aiFix.lines.join(", ")}</p>
                  )}
                  <p className="text-xs text-zinc-300 leading-relaxed">{aiFix.explanation}</p>
                </div>
                <button onClick={() => setAiFix(null)} className="shrink-0 text-zinc-600 hover:text-zinc-400">
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>
              {aiFix.fixedCode && (
                <button
                  onClick={handleApplyAIFix}
                  className={`w-full py-2 rounded-xl text-xs font-semibold transition-all ${
                    aiFixApplied
                      ? "bg-emerald-500/20 text-emerald-400 border border-emerald-500/30"
                      : "bg-violet-600 text-white hover:bg-violet-500"
                  }`}
                >
                  {aiFixApplied ? <><Check className="w-3.5 h-3.5 inline mr-1" />Appliqué !</> : "✦ Utiliser la solution IA"}
                </button>
              )}
            </>
          )}
        </div>
      )}

      {/* Execute button */}
      <div className="px-3 pb-3 pt-2 shrink-0">
        {isRunning ? (
          <button
            className="w-full h-12 rounded-2xl font-semibold text-white flex items-center justify-center gap-2 transition-all active:scale-[0.98] bg-red-600 hover:bg-red-500"
            onClick={handleStop}
          >
            <Square className="w-4 h-4 fill-current" />
            Arrêter
          </button>
        ) : (
          <button
            className="w-full h-12 rounded-2xl font-bold text-white flex items-center justify-center gap-2 transition-all active:scale-[0.98]"
            style={{ background: execMode === "none" ? "#374151" : execButtonColor }}
            onClick={handleExecute}
          >
            {execMode === "html" ? <MonitorPlay className="w-5 h-5" /> :
             execMode === "none" ? <ExternalLink className="w-4 h-4" /> :
             <Play className="w-5 h-5 fill-current" />}
            {execButtonLabel}
          </button>
        )}
      </div>

      {/* Interactive Console Drawer (Python + JS) */}
      {isConsoleOpen && (
        <div className="absolute bottom-0 left-0 right-0 bg-[#080d17] border-t border-white/8 shadow-2xl flex flex-col z-20 animate-in slide-in-from-bottom-full duration-250" style={{ height: "44vh" }}>
          <div className="h-10 flex items-center justify-between px-4 border-b border-white/5 shrink-0">
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold tracking-widest text-zinc-600 uppercase">Console</span>
              {isRunning && (
                <span className="flex items-center gap-1 text-xs" style={{ color: execButtonColor }}>
                  <span className="w-1.5 h-1.5 rounded-full animate-pulse" style={{ background: execButtonColor }} />
                  running
                </span>
              )}
            </div>
            <div className="flex items-center gap-1">
              <button
                className="h-6 px-2 rounded-lg text-xs text-zinc-600 hover:text-zinc-400 hover:bg-white/5 transition"
                onClick={() => setConsoleLines([])}
              >
                Vider
              </button>
              <button className="w-7 h-7 flex items-center justify-center rounded-lg text-zinc-600 hover:text-zinc-300 hover:bg-white/5" onClick={() => setIsConsoleOpen(false)}>
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          <div className="flex-1 overflow-auto p-3 space-y-0.5 font-mono text-sm">
            {consoleLines.map((line) => {
              if (line.kind === "output") {
                return (
                  <pre key={line.id} className={`whitespace-pre-wrap leading-relaxed break-words ${line.isError ? "text-red-400" : "text-zinc-300"}`}>
                    {line.text}
                  </pre>
                );
              }
              if (line.kind === "user_input") {
                return (
                  <div key={line.id} className="flex items-baseline gap-1">
                    <span className="text-violet-400 select-none">›</span>
                    <span className="text-violet-300">{line.value}</span>
                  </div>
                );
              }
              return null;
            })}

            {waitingInput && (
              <form onSubmit={handleInputSubmit} className="flex items-center gap-2 mt-1">
                {inputPrompt && <span className="text-zinc-300 whitespace-pre">{inputPrompt}</span>}
                <span className="text-violet-400 select-none">›</span>
                <input
                  ref={inputRef}
                  type="text"
                  value={inputValue}
                  onChange={(e) => setInputValue(e.target.value)}
                  onKeyDown={(e) => { if (e.key === "Enter") handleInputSubmit(); }}
                  className="flex-1 bg-transparent outline-none text-violet-200 caret-violet-400 min-w-0"
                  placeholder="Entrée..."
                  autoComplete="off" autoCorrect="off" autoCapitalize="off" spellCheck={false}
                />
                <button type="submit" className="text-xs text-violet-400 px-2 py-0.5 rounded bg-violet-500/15 hover:bg-violet-500/25 shrink-0">OK</button>
              </form>
            )}
            <div ref={consoleEndRef} />
          </div>
        </div>
      )}

      {/* AI Panel — fixed fullscreen */}
      {showAI && (
        <AIPanel
          onClose={() => setShowAI(false)}
          currentCode={content}
          language={lang}
          onApplySolution={applyCode}
        />
      )}

      {/* Learning Panel — fixed fullscreen */}
      {showLearning && (
        <LearningPanel
          onClose={() => setShowLearning(false)}
          language={lang}
        />
      )}

      {/* Settings Sheet — fixed on top of everything */}
      {isSettingsOpen && (
        <div className="fixed inset-0 z-[55] flex flex-col justify-end">
          <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" onClick={() => { setIsSettingsOpen(false); setShowDeleteConfirm(false); }} />
          <div className="relative bg-[#111827] border-t border-white/8 rounded-t-3xl p-5 animate-in slide-in-from-bottom-full duration-250 space-y-3 max-h-[88vh] overflow-auto">
            <div className="w-10 h-1 bg-white/20 rounded-full mx-auto mb-3" />

            {/* Session code */}
            <div className="flex items-center justify-between bg-white/5 border border-white/8 rounded-2xl px-4 py-3">
              <div>
                <p className="text-xs text-zinc-500 mb-1">Code de session</p>
                <p className="font-mono text-xl font-bold tracking-widest text-violet-400">{code}</p>
              </div>
              <button onClick={handleCopySessionCode} className="w-10 h-10 flex items-center justify-center rounded-xl bg-violet-500/15 text-violet-400 hover:bg-violet-500/25 transition-all active:scale-[0.95]">
                {copiedSession ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
              </button>
            </div>

            {/* Language info */}
            <div className="flex items-center gap-3 px-4 py-3 rounded-2xl bg-white/4 border border-white/5">
              <span className="text-2xl">{langInfo.emoji}</span>
              <div>
                <p className="text-sm font-semibold" style={{ color: langInfo.color }}>{langInfo.label}</p>
                <p className="text-xs text-zinc-500">{execMode === "none" ? "Éditeur + coloration syntaxique" : "Exécution disponible"}</p>
              </div>
            </div>

            {/* AI Auto-corrector */}
            <div className="flex items-center justify-between px-4 py-3.5 rounded-2xl bg-white/5 border border-white/5">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-violet-500/15 flex items-center justify-center text-violet-400 shrink-0">
                  <Lightbulb className="w-4 h-4" />
                </div>
                <div>
                  <p className="text-sm font-medium text-zinc-200">Auto-correcteur IA</p>
                  <p className="text-xs text-zinc-500">Analyse les erreurs après exécution</p>
                </div>
              </div>
              <button
                onClick={toggleAutoCorrect}
                className={`w-11 h-6 rounded-full transition-all relative shrink-0 ${aiAutoCorrect ? "bg-violet-600" : "bg-zinc-700"}`}
              >
                <div className={`absolute top-1 w-4 h-4 rounded-full bg-white transition-all ${aiAutoCorrect ? "left-6" : "left-1"}`} />
              </button>
            </div>

            {/* Copy code */}
            <button onClick={handleCopyEditorCode} className="w-full flex items-center gap-3 px-4 py-3.5 rounded-2xl bg-white/5 hover:bg-white/8 transition-all text-left active:scale-[0.99]">
              <div className="w-9 h-9 rounded-xl bg-blue-500/15 flex items-center justify-center text-blue-400 shrink-0"><Code className="w-4 h-4" /></div>
              <div className="flex-1">
                <p className="text-sm font-medium text-zinc-200">Copier le code</p>
                <p className="text-xs text-zinc-500">Contenu de l'éditeur</p>
              </div>
              {copiedCode && <Check className="w-4 h-4 text-emerald-400" />}
            </button>

            {/* Copy session */}
            <button onClick={handleCopySessionCode} className="w-full flex items-center gap-3 px-4 py-3.5 rounded-2xl bg-white/5 hover:bg-white/8 transition-all text-left active:scale-[0.99]">
              <div className="w-9 h-9 rounded-xl bg-violet-500/15 flex items-center justify-center text-violet-400 shrink-0"><Clipboard className="w-4 h-4" /></div>
              <div className="flex-1">
                <p className="text-sm font-medium text-zinc-200">Copier le code de session</p>
                <p className="text-xs text-zinc-500">Partager avec un ami</p>
              </div>
              {copiedSession && <Check className="w-4 h-4 text-emerald-400" />}
            </button>

            {/* Clear code */}
            <button onClick={() => { applyCode(""); setIsSettingsOpen(false); }} className="w-full flex items-center gap-3 px-4 py-3.5 rounded-2xl bg-white/5 hover:bg-white/8 transition-all text-left active:scale-[0.99]">
              <div className="w-9 h-9 rounded-xl bg-amber-500/15 flex items-center justify-center text-amber-400 shrink-0"><X className="w-4 h-4" /></div>
              <div>
                <p className="text-sm font-medium text-zinc-200">Effacer le code</p>
                <p className="text-xs text-zinc-500">Vider l'éditeur pour tout le monde</p>
              </div>
            </button>

            {/* Delete session */}
            {!showDeleteConfirm ? (
              <button onClick={() => setShowDeleteConfirm(true)} className="w-full flex items-center gap-3 px-4 py-3.5 rounded-2xl bg-red-500/8 hover:bg-red-500/15 transition-all text-left border border-red-500/15 active:scale-[0.99]">
                <div className="w-9 h-9 rounded-xl bg-red-500/15 flex items-center justify-center text-red-400 shrink-0"><Trash2 className="w-4 h-4" /></div>
                <div>
                  <p className="text-sm font-medium text-red-400">Supprimer la session</p>
                  <p className="text-xs text-red-400/60">Action irréversible</p>
                </div>
              </button>
            ) : (
              <div className="p-4 rounded-2xl bg-red-500/10 border border-red-500/20 space-y-3">
                <p className="text-sm text-red-300 font-medium text-center">Supprimer cette session ?</p>
                <p className="text-xs text-red-400/70 text-center">Cette action supprime la session pour tout le monde.</p>
                <div className="flex gap-2">
                  <button onClick={() => setShowDeleteConfirm(false)} className="flex-1 py-2.5 rounded-xl bg-white/8 text-zinc-300 text-sm font-medium">Annuler</button>
                  <button onClick={handleDeleteSession} disabled={isDeleting} className="flex-1 py-2.5 rounded-xl bg-red-600 text-white text-sm font-medium disabled:opacity-60">
                    {isDeleting ? "Suppression..." : "Supprimer"}
                  </button>
                </div>
              </div>
            )}

            <div className="h-2" />
          </div>
        </div>
      )}
    </div>
  );
}
