import { useState, useRef, useEffect, useCallback } from "react";
import { X, Send, Loader2, Check, RefreshCw } from "lucide-react";
import { callAIChat } from "@/lib/gemini";

interface Message {
  id: string;
  role: "user" | "assistant";
  text: string;
  codeBlock?: string | null;
}

interface AIPanelProps {
  onClose: () => void;
  currentCode: string;
  language: string;
  sessionCode: string;
  onApplySolution: (code: string) => void;
}

let msgId = 0;
const mkId = () => String(++msgId);

const EXAMPLES: Record<string, string[]> = {
  python: [
    "Explique comment fonctionne range()",
    "Rends ce code plus court et plus propre",
    "Ajoute un système de liste de courses",
    "Corrige les erreurs dans mon code",
  ],
  javascript: [
    "Explique async/await avec un exemple",
    "Ajoute la gestion d'erreurs à ce code",
    "Convertis ce code en arrow functions",
    "Crée un système de panier d'achat",
  ],
  html: [
    "Rends ce design plus moderne",
    "Ajoute un formulaire de contact",
    "Améliore la responsivité mobile",
    "Ajoute des animations CSS",
  ],
  default: [
    "Explique ce que fait ce code",
    "Améliore la lisibilité du code",
    "Trouve et corrige les erreurs",
    "Ajoute des commentaires",
  ],
};

function getHistoryKey(sessionCode: string) {
  return `codeshare_chat_${sessionCode}`;
}

function loadHistory(sessionCode: string): Message[] {
  try {
    const raw = localStorage.getItem(getHistoryKey(sessionCode));
    if (!raw) return [];
    return JSON.parse(raw) as Message[];
  } catch {
    return [];
  }
}

function saveHistory(sessionCode: string, messages: Message[]) {
  try {
    const toSave = messages.slice(-60);
    localStorage.setItem(getHistoryKey(sessionCode), JSON.stringify(toSave));
  } catch {}
}

export function AIPanel({ onClose, currentCode, language, sessionCode, onApplySolution }: AIPanelProps) {
  const [messages, setMessages] = useState<Message[]>(() => loadHistory(sessionCode));
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [appliedId, setAppliedId] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const bottomRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);
  const abortRef = useRef<AbortController | null>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, isLoading]);

  useEffect(() => {
    const t = setTimeout(() => inputRef.current?.focus(), 150);
    return () => clearTimeout(t);
  }, []);

  useEffect(() => {
    saveHistory(sessionCode, messages);
  }, [messages, sessionCode]);

  const sendMessage = useCallback(async () => {
    const text = input.trim();
    if (!text || isLoading) return;

    setError(null);
    const userMsg: Message = { id: mkId(), role: "user", text };
    const updatedMessages = [...messages, userMsg];
    setMessages(updatedMessages);
    setInput("");
    setIsLoading(true);

    const controller = new AbortController();
    abortRef.current = controller;

    try {
      const apiMessages = updatedMessages.map((m) => ({
        role: m.role,
        text: m.text,
      }));

      const data = await callAIChat(apiMessages, currentCode, language);

      const assistantMsg: Message = {
        id: mkId(),
        role: "assistant",
        text: data.response || "Aucune réponse reçue.",
        codeBlock: data.codeBlock,
      };
      setMessages((prev) => [...prev, assistantMsg]);
    } catch (err: unknown) {
      if (err instanceof Error && err.name === "AbortError") return;
      const errMsg = err instanceof Error ? err.message : String(err);
      const msg =
        errMsg.includes("quota") || errMsg.includes("429")
          ? "Limite de l'IA atteinte. Réessaie dans quelques secondes."
          : errMsg.includes("VITE_GEMINI_API_KEY")
          ? errMsg
          : "Erreur de connexion à l'IA. Vérifie ta clé API et réessaie.";
      setError(msg);
    } finally {
      setIsLoading(false);
      abortRef.current = null;
      setTimeout(() => inputRef.current?.focus(), 50);
    }
  }, [input, isLoading, messages, currentCode, language]);

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  const handleApply = (msg: Message) => {
    if (!msg.codeBlock) return;
    onApplySolution(msg.codeBlock);
    setAppliedId(msg.id);
    setTimeout(() => setAppliedId(null), 2000);
  };

  const handleClear = () => {
    setMessages([]);
    setError(null);
    saveHistory(sessionCode, []);
  };

  function renderMessageText(text: string) {
    const parts = text.split(/(```[\w]*\n?[\s\S]*?```)/g);
    return parts.map((part, i) => {
      const codeMatch = part.match(/```[\w]*\n?([\s\S]*?)```/);
      if (codeMatch) {
        return (
          <pre
            key={i}
            className="my-2 p-3 rounded-xl bg-black/50 text-emerald-300 text-xs font-mono overflow-x-auto whitespace-pre-wrap border border-white/8"
          >
            {codeMatch[1].trim()}
          </pre>
        );
      }
      return (
        <span key={i} className="whitespace-pre-wrap">
          {part}
        </span>
      );
    });
  }

  const examples = EXAMPLES[language] ?? EXAMPLES.default;

  return (
    <div className="fixed inset-0 z-50 flex flex-col bg-[#0a0f1e]">
      {/* Header */}
      <div className="h-14 border-b border-white/5 flex items-center justify-between px-4 shrink-0 bg-[#0a0f1e]">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-lg bg-gradient-to-br from-violet-500 to-pink-500 flex items-center justify-center shrink-0">
            <span className="text-xs font-bold text-white">IA</span>
          </div>
          <div>
            <span className="text-sm font-semibold text-zinc-200">Assistant IA</span>
            <span className="ml-2 text-xs text-zinc-600 capitalize">{language}</span>
          </div>
        </div>
        <div className="flex items-center gap-1">
          {messages.length > 0 && (
            <button
              onClick={handleClear}
              className="w-8 h-8 flex items-center justify-center rounded-xl text-zinc-500 hover:text-zinc-300 hover:bg-white/5 transition"
              title="Nouvelle conversation"
            >
              <RefreshCw className="w-3.5 h-3.5" />
            </button>
          )}
          <button
            onClick={onClose}
            className="w-8 h-8 flex items-center justify-center rounded-xl text-zinc-500 hover:text-zinc-300 hover:bg-white/5 transition"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-auto p-4 space-y-4 overscroll-contain">
        {messages.length === 0 && (
          <div className="pt-6 space-y-4">
            <div className="text-center space-y-2">
              <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-violet-500/20 to-pink-500/20 border border-violet-500/20 flex items-center justify-center mx-auto">
                <span className="text-xl">✦</span>
              </div>
              <p className="text-zinc-400 text-sm">Pose une question sur ton code</p>
            </div>
            <div className="space-y-2">
              {examples.map((ex, i) => (
                <button
                  key={i}
                  className="w-full text-left text-xs text-zinc-400 px-3 py-2.5 rounded-xl bg-white/4 hover:bg-white/8 border border-white/5 transition active:scale-[0.98]"
                  onClick={() => setInput(ex)}
                >
                  {ex}
                </button>
              ))}
            </div>
          </div>
        )}

        {messages.map((msg) => (
          <div
            key={msg.id}
            className={`flex flex-col gap-1.5 ${msg.role === "user" ? "items-end" : "items-start"}`}
          >
            <div
              className={`max-w-[90%] px-4 py-3 rounded-2xl text-sm leading-relaxed ${
                msg.role === "user"
                  ? "bg-violet-600 text-white rounded-tr-sm"
                  : "bg-[#1a2035] text-zinc-200 rounded-tl-sm border border-white/5"
              }`}
            >
              {renderMessageText(msg.text)}
            </div>

            {msg.role === "assistant" && msg.codeBlock && (
              <button
                onClick={() => handleApply(msg)}
                className={`flex items-center gap-2 px-3 py-1.5 rounded-xl text-xs font-medium transition-all active:scale-[0.97] ${
                  appliedId === msg.id
                    ? "bg-emerald-500/20 text-emerald-400 border border-emerald-500/30"
                    : "bg-violet-500/15 text-violet-400 border border-violet-500/20 hover:bg-violet-500/25"
                }`}
              >
                {appliedId === msg.id ? (
                  <>
                    <Check className="w-3.5 h-3.5" />
                    Appliqué !
                  </>
                ) : (
                  "✦ Utiliser la solution"
                )}
              </button>
            )}
          </div>
        ))}

        {isLoading && (
          <div className="flex items-start">
            <div className="px-4 py-3 rounded-2xl rounded-tl-sm bg-[#1a2035] border border-white/5 flex items-center gap-2 text-zinc-500 text-sm">
              <Loader2 className="w-4 h-4 animate-spin text-violet-400" />
              <span className="text-zinc-400">Analyse en cours...</span>
            </div>
          </div>
        )}

        {error && (
          <div className="flex items-center gap-2 px-3 py-2.5 rounded-xl bg-red-500/10 border border-red-500/20 text-red-400 text-xs">
            <span className="flex-1">{error}</span>
            <button onClick={() => setError(null)} className="shrink-0 hover:text-red-300">
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        )}

        <div ref={bottomRef} />
      </div>

      {/* Input */}
      <div className="border-t border-white/5 p-3 bg-[#0a0f1e] shrink-0">
        <div className="flex items-end gap-2 bg-white/5 border border-white/10 rounded-2xl px-3 py-2 focus-within:border-violet-500/40 transition-colors">
          <textarea
            ref={inputRef}
            value={input}
            onChange={(e) => {
              setInput(e.target.value);
              e.target.style.height = "auto";
              e.target.style.height = Math.min(e.target.scrollHeight, 120) + "px";
            }}
            onKeyDown={handleKeyDown}
            placeholder="Pose une question ou demande une modification..."
            rows={1}
            className="flex-1 bg-transparent text-zinc-200 text-sm resize-none outline-none placeholder:text-zinc-600"
            style={{ minHeight: "22px", maxHeight: "120px" }}
          />
          <button
            onClick={sendMessage}
            disabled={!input.trim() || isLoading}
            className="w-8 h-8 rounded-xl bg-violet-600 flex items-center justify-center text-white disabled:opacity-30 transition active:scale-[0.92] shrink-0 mb-0.5"
          >
            <Send className="w-3.5 h-3.5" />
          </button>
        </div>
        <p className="text-xs text-zinc-700 mt-1.5 text-center">
          Entrée pour envoyer · Shift+Entrée pour sauter une ligne
        </p>
      </div>
    </div>
  );
}
