import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";

export interface Session {
  id: number;
  code: string;
  language: string;
  content: string;
  createdAt: string;
  updatedAt: string;
}

export interface SessionInput {
  language: string;
}

function generateCode(): string {
  return Array.from({ length: 10 }, () => Math.floor(Math.random() * 10)).join("");
}

const SESSION_PREFIX = "codeshare_session_";

function saveSession(session: Session) {
  try { localStorage.setItem(SESSION_PREFIX + session.code, JSON.stringify(session)); } catch {}
}

export function loadSession(code: string): Session | null {
  try {
    const stored = localStorage.getItem(SESSION_PREFIX + code);
    return stored ? (JSON.parse(stored) as Session) : null;
  } catch { return null; }
}

export function removeSession(code: string) {
  try { localStorage.removeItem(SESSION_PREFIX + code); } catch {}
}

export const getGetSessionQueryKey = (code: string) => [`/api/sessions/${code}`] as const;

export function useGetSession(
  code: string,
  options?: { query?: { retry?: boolean } }
) {
  return useQuery({
    queryKey: getGetSessionQueryKey(code),
    queryFn: () => {
      const session = loadSession(code);
      if (!session) throw new Error("Session not found");
      return Promise.resolve(session);
    },
    retry: options?.query?.retry ?? false,
    enabled: !!code,
  });
}

export function useCreateSession() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (vars: { data: SessionInput }) => {
      const code = generateCode();
      const session: Session = {
        id: Date.now(),
        code,
        language: vars.data.language,
        content: "",
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };
      saveSession(session);
      return Promise.resolve(session);
    },
    onSuccess: (session) => {
      queryClient.setQueryData(getGetSessionQueryKey(session.code), session);
    },
  });
}
