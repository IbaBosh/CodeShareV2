const GEMINI_MODEL = "gemini-2.5-flash";
const MAX_RETRIES = 3;
const RETRY_DELAY_MS = 1200;

function getApiKey(): string {
  const key = import.meta.env.VITE_GEMINI_API_KEY as string | undefined;
  if (!key) throw new Error("VITE_GEMINI_API_KEY n'est pas configuré. Ajoute cette variable dans les paramètres Netlify (Site settings → Environment variables).");
  return key;
}

async function sleep(ms: number) {
  return new Promise((r) => setTimeout(r, ms));
}

async function geminiRequest(body: object, retries = MAX_RETRIES): Promise<string> {
  const apiKey = getApiKey();
  const url = `https://generativelanguage.googleapis.com/v1beta/models/${GEMINI_MODEL}:generateContent?key=${apiKey}`;

  for (let attempt = 0; attempt <= retries; attempt++) {
    try {
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 30000);

      const res = await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
        signal: controller.signal,
      });

      clearTimeout(timeout);

      if (res.status === 429 || res.status === 503) {
        if (attempt < retries) {
          await sleep(RETRY_DELAY_MS * (attempt + 1));
          continue;
        }
        throw new Error("L'IA est saturée, réessaie dans quelques secondes.");
      }

      if (!res.ok) {
        const errText = await res.text().catch(() => "");
        if (attempt < retries && (res.status >= 500 || res.status === 408)) {
          await sleep(RETRY_DELAY_MS * (attempt + 1));
          continue;
        }
        throw new Error(`Erreur Gemini ${res.status}: ${errText.slice(0, 120)}`);
      }

      const data = (await res.json()) as {
        candidates?: { content?: { parts?: { text?: string }[] } }[];
        error?: { message?: string };
      };

      if (data.error?.message) throw new Error(data.error.message);

      const text = data?.candidates?.[0]?.content?.parts?.[0]?.text ?? "";
      if (!text && attempt < retries) {
        await sleep(RETRY_DELAY_MS);
        continue;
      }
      return text;
    } catch (err) {
      if (err instanceof Error && err.name === "AbortError") {
        if (attempt < retries) { await sleep(RETRY_DELAY_MS); continue; }
        throw new Error("Timeout — l'IA met trop de temps à répondre.");
      }
      if (attempt >= retries) throw err;
      await sleep(RETRY_DELAY_MS * (attempt + 1));
    }
  }
  throw new Error("L'IA n'a pas répondu après plusieurs tentatives.");
}

export async function geminiGenerate(prompt: string): Promise<string> {
  return geminiRequest({
    contents: [{ role: "user", parts: [{ text: prompt }] }],
    generationConfig: { temperature: 0.3, maxOutputTokens: 2048 },
  });
}

export async function geminiChat(messages: { role: string; text: string }[]): Promise<string> {
  const contents = messages.map((m) => ({
    role: m.role === "assistant" || m.role === "model" ? "model" : "user",
    parts: [{ text: m.text }],
  }));
  return geminiRequest({
    contents,
    generationConfig: { temperature: 0.5, maxOutputTokens: 2048 },
  });
}

export async function callAIFix(
  code: string,
  error: string,
  language: string
): Promise<{ explanation: string; fixedCode: string | null; lines: number[] }> {
  const langName = { python: "Python", javascript: "JavaScript", html: "HTML/CSS", typescript: "TypeScript", lua: "Lua", java: "Java", cpp: "C++", php: "PHP", go: "Go", rust: "Rust" }[language] ?? language;

  const prompt = `Tu es un expert ${langName}.
Analyse ce code et cette erreur. Réponds UNIQUEMENT avec du JSON valide, sans backticks ni markdown.
Format exact : {"lines":[1,2],"explanation":"Explication courte et claire en français de l'erreur — 2-3 phrases max, commence directement par le problème","fixedCode":"code complet corrigé ici"}

Code :
\`\`\`${language}
${code.slice(0, 3000)}
\`\`\`

Erreur :
${error.slice(0, 800)}`;

  const raw = await geminiGenerate(prompt);
  const jsonMatch = raw.match(/\{[\s\S]*\}/);
  if (!jsonMatch) return { explanation: raw.trim().slice(0, 300), fixedCode: null, lines: [] };
  try {
    const parsed = JSON.parse(jsonMatch[0]) as { explanation?: string; fixedCode?: string | null; lines?: number[] };
    return { explanation: parsed.explanation ?? "", fixedCode: parsed.fixedCode ?? null, lines: parsed.lines ?? [] };
  } catch {
    return { explanation: raw.trim().slice(0, 300), fixedCode: null, lines: [] };
  }
}

export async function callAIChat(
  messages: { role: string; text: string }[],
  currentCode: string,
  language: string
): Promise<{ response: string; codeBlock: string | null }> {
  const langName = { python: "Python", javascript: "JavaScript", html: "HTML/CSS", typescript: "TypeScript", lua: "Lua", java: "Java", cpp: "C++", php: "PHP", go: "Go", rust: "Rust" }[language] ?? language;

  const systemText = `Tu es un assistant expert en ${langName} intégré dans un éditeur de code collaboratif. Tu réponds toujours en français, de façon directe et concise.
Règles : ne salue jamais, commence directement. Si tu écris du code, utilise des blocs \`\`\`${language}. Pour les modifications, fournis le code COMPLET modifié.

Code actuel :
\`\`\`${language}
${currentCode.slice(0, 2000) || "(vide)"}
\`\`\``;

  const allMessages = [
    { role: "user", text: systemText },
    { role: "model", text: "Compris, je suis prêt." },
    ...messages.slice(-20).map((m) => ({
      role: m.role === "assistant" ? "model" : "user",
      text: m.text,
    })),
  ];

  const response = await geminiChat(allMessages);
  const codeBlockMatch = response.match(/```(?:python|html|py|js|javascript|typescript|ts|css|lua|java|cpp|php|go|rust)?\n?([\s\S]*?)```/);
  const codeBlock = codeBlockMatch ? codeBlockMatch[1].trim() : null;
  return { response, codeBlock };
}
