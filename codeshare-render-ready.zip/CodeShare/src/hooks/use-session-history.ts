import { useState, useEffect, useCallback } from "react";

export type SessionHistoryItem = {
  code: string;
  language: string;
  lastAccessed: string;
};

const HISTORY_KEY = "codeshare_sessions";

export function useSessionHistory() {
  const [history, setHistory] = useState<SessionHistoryItem[]>([]);

  useEffect(() => {
    try {
      const stored = localStorage.getItem(HISTORY_KEY);
      if (stored) setHistory(JSON.parse(stored));
    } catch {}
  }, []);

  const addSession = useCallback((session: { code: string; language: string }) => {
    setHistory((prev) => {
      const filtered = prev.filter((item) => item.code !== session.code);
      const newItem: SessionHistoryItem = {
        code: session.code,
        language: session.language,
        lastAccessed: new Date().toISOString(),
      };
      const updated = [newItem, ...filtered].slice(0, 20);
      try { localStorage.setItem(HISTORY_KEY, JSON.stringify(updated)); } catch {}
      return updated;
    });
  }, []);

  const removeSession = useCallback((code: string) => {
    setHistory((prev) => {
      const updated = prev.filter((item) => item.code !== code);
      try { localStorage.setItem(HISTORY_KEY, JSON.stringify(updated)); } catch {}
      return updated;
    });
  }, []);

  return { history, addSession, removeSession };
}
