import { useState, useEffect, useRef, useCallback } from "react";

export type WebSocketStatus = "connecting" | "connected" | "disconnected";

export interface ConsoleEntry {
  id: string;
  type: "output" | "error" | "input_prompt" | "user_input";
  text: string;
}

interface UseWebSocketOptions {
  sessionCode: string | undefined;
  onInitCode: (content: string) => void;
  onCodeUpdate: (content: string) => void;
  onUserJoined?: () => void;
  onUserCount?: (count: number) => void;
  onOutputChunk?: (text: string, isError: boolean) => void;
  onInputNeeded?: (prompt: string) => void;
  onExecutionDone?: (exitCode: number) => void;
  onSessionNotFound?: () => void;
}

function getOrCreateHwid(): string {
  const key = "codeshare_hwid";
  let hwid = localStorage.getItem(key);
  if (!hwid) {
    hwid = `${Date.now()}-${Math.random().toString(36).slice(2)}-${Math.random().toString(36).slice(2)}`;
    localStorage.setItem(key, hwid);
  }
  return hwid;
}

export function useWebSocket({
  sessionCode,
  onInitCode,
  onCodeUpdate,
  onUserJoined,
  onUserCount,
  onOutputChunk,
  onInputNeeded,
  onExecutionDone,
  onSessionNotFound,
}: UseWebSocketOptions) {
  const [status, setStatus] = useState<WebSocketStatus>("disconnected");
  const wsRef = useRef<WebSocket | null>(null);
  const reconnectTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const mountedRef = useRef(true);

  const cbRefs = useRef({
    onInitCode, onCodeUpdate, onUserJoined, onUserCount,
    onOutputChunk, onInputNeeded, onExecutionDone, onSessionNotFound,
  });
  useEffect(() => {
    cbRefs.current = { onInitCode, onCodeUpdate, onUserJoined, onUserCount, onOutputChunk, onInputNeeded, onExecutionDone, onSessionNotFound };
  });

  const connect = useCallback(() => {
    if (!sessionCode || !mountedRef.current) return;
    if (wsRef.current && wsRef.current.readyState !== WebSocket.CLOSED) wsRef.current.close();

    setStatus("connecting");
    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const ws = new WebSocket(`${protocol}//${window.location.host}/ws`);
    wsRef.current = ws;

    ws.onopen = () => {
      if (!mountedRef.current) return;
      setStatus("connected");
      ws.send(JSON.stringify({ type: "join", sessionCode, hwid: getOrCreateHwid() }));
    };

    ws.onmessage = (event) => {
      if (!mountedRef.current) return;
      try {
        const data = JSON.parse(event.data);
        const cb = cbRefs.current;
        if (data.type === "init")               cb.onInitCode(data.content);
        else if (data.type === "code_update")    cb.onCodeUpdate(data.content);
        else if (data.type === "user_joined")    cb.onUserJoined?.();
        else if (data.type === "user_count")     cb.onUserCount?.(data.count);
        else if (data.type === "output_chunk")   cb.onOutputChunk?.(data.text, data.isError ?? false);
        else if (data.type === "input_needed")   cb.onInputNeeded?.(data.prompt ?? "");
        else if (data.type === "execution_done") cb.onExecutionDone?.(data.exitCode ?? 0);
        else if (data.type === "session_not_found") cb.onSessionNotFound?.();
      } catch (e) {
        console.error("WS parse error", e);
      }
    };

    ws.onclose = () => {
      if (!mountedRef.current) return;
      setStatus("disconnected");
      reconnectTimeoutRef.current = setTimeout(() => { if (mountedRef.current) connect(); }, 2000);
    };

    ws.onerror = () => {};
  }, [sessionCode]);

  useEffect(() => {
    mountedRef.current = true;
    connect();
    return () => {
      mountedRef.current = false;
      if (reconnectTimeoutRef.current) clearTimeout(reconnectTimeoutRef.current);
      if (wsRef.current) wsRef.current.close();
    };
  }, [connect]);

  const sendRaw = useCallback((obj: object) => {
    if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify(obj));
    }
  }, []);

  const sendCodeUpdate    = useCallback((content: string) => sendRaw({ type: "code_update", content }), [sendRaw]);
  const sendExecute       = useCallback((code: string)    => sendRaw({ type: "execute", code }), [sendRaw]);
  const sendInputResponse = useCallback((value: string)   => sendRaw({ type: "input_response", value }), [sendRaw]);
  const sendKill          = useCallback(()                => sendRaw({ type: "kill_execution" }), [sendRaw]);

  return { status, sendCodeUpdate, sendExecute, sendInputResponse, sendKill };
}
