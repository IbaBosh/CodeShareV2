import express from "express";
import http from "http";
import path from "path";
import { fileURLToPath } from "url";
import cors from "cors";
import { Pool } from "pg";
import { drizzle } from "drizzle-orm/node-postgres";
import { pgTable, serial, text, timestamp } from "drizzle-orm/pg-core";
import { eq } from "drizzle-orm";
import { WebSocketServer, WebSocket } from "ws";
import { spawn, type ChildProcessWithoutNullStreams } from "child_process";
import { writeFile, unlink } from "fs/promises";
import { tmpdir } from "os";
import { join } from "path";
import { execSync } from "child_process";

const __dirname = path.dirname(fileURLToPath(import.meta.url));

// ── Database ──────────────────────────────────────────────────────────────────
const sessionsTable = pgTable("sessions", {
  id: serial("id").primaryKey(),
  code: text("code").notNull().unique(),
  language: text("language").notNull(),
  content: text("content").notNull().default(""),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

const pool = new Pool({
  connectionString: process.env["DATABASE_URL"],
  ssl: process.env["NODE_ENV"] === "production" ? { rejectUnauthorized: false } : false,
});

const db = drizzle(pool, { schema: { sessionsTable } });

// Auto-create table on startup
pool.query(`
  CREATE TABLE IF NOT EXISTS sessions (
    id SERIAL PRIMARY KEY,
    code TEXT NOT NULL UNIQUE,
    language TEXT NOT NULL,
    content TEXT NOT NULL DEFAULT '',
    created_at TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP NOT NULL DEFAULT NOW()
  )
`).then(() => console.log("[DB] Table ready")).catch((e) => console.error("[DB] Init error:", e));

// ── Python ────────────────────────────────────────────────────────────────────
function findPython(): string {
  const candidates = [
    "/nix/store/flbj8bq2vznkcwss7sm0ky8rd0k6kar7-python-wrapped-0.1.0/bin/python3",
    "python3", "python",
  ];
  for (const c of candidates) {
    try { execSync(`${c} --version`, { timeout: 3000, stdio: "pipe" }); return c; } catch {}
  }
  return "python3";
}
const PYTHON_BIN = findPython();
const INPUT_MARKER = "\x00INPUT_REQ\x00";
const PYTHON_WRAPPER = [
  "import sys as __sys, builtins as __builtins_mod",
  "def input(prompt=''):",
  "    __sys.stdout.write('\\x00INPUT_REQ\\x00' + str(prompt))",
  "    __sys.stdout.flush()",
  "    return __sys.stdin.readline().rstrip('\\n')",
  "__builtins_mod.input = input",
  "",
].join("\n");

// ── Gemini ────────────────────────────────────────────────────────────────────
async function callGemini(prompt: string): Promise<string> {
  const apiKey = process.env["GEMINI_API_KEY"];
  if (!apiKey) throw new Error("GEMINI_API_KEY not set");
  const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${apiKey}`;
  const res = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      contents: [{ role: "user", parts: [{ text: prompt }] }],
      generationConfig: { temperature: 0.3, maxOutputTokens: 2048 },
    }),
  });
  if (!res.ok) throw new Error(`Gemini ${res.status}`);
  const data = await res.json() as any;
  return data?.candidates?.[0]?.content?.parts?.[0]?.text ?? "";
}

async function callGeminiChat(messages: { role: string; text: string }[]): Promise<string> {
  const apiKey = process.env["GEMINI_API_KEY"];
  if (!apiKey) throw new Error("GEMINI_API_KEY not set");
  const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${apiKey}`;
  const contents = messages.map(m => ({
    role: m.role === "assistant" ? "model" : "user",
    parts: [{ text: m.text }],
  }));
  const res = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ contents, generationConfig: { temperature: 0.5, maxOutputTokens: 2048 } }),
  });
  if (!res.ok) throw new Error(`Gemini ${res.status}`);
  const data = await res.json() as any;
  return data?.candidates?.[0]?.content?.parts?.[0]?.text ?? "";
}

// ── Default code templates ────────────────────────────────────────────────────
const DEFAULT_CONTENT: Record<string, string> = {
  python: '# Code Python\nprint("Hello, world!")\n',
  html: '<!DOCTYPE html>\n<html lang="fr">\n<head>\n  <meta charset="UTF-8">\n  <title>Ma Page</title>\n  <style>\n    body { font-family: sans-serif; background: #0d0d1a; color: white; display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; }\n    h1 { color: #a78bfa; }\n  </style>\n</head>\n<body>\n  <h1>Hello, world!</h1>\n</body>\n</html>\n',
  javascript: '// JavaScript\nconsole.log("Hello, world!");\n',
  typescript: '// TypeScript\nconst message: string = "Hello, world!";\nconsole.log(message);\n',
  lua: '-- Lua\nprint("Hello, world!")\n',
  java: '// Java\npublic class Main {\n    public static void main(String[] args) {\n        System.out.println("Hello, world!");\n    }\n}\n',
  cpp: '// C++\n#include <iostream>\nusing namespace std;\nint main() {\n    cout << "Hello, world!" << endl;\n    return 0;\n}\n',
  php: '<?php\necho "Hello, world!\\n";\n?>',
  go: '// Go\npackage main\nimport "fmt"\nfunc main() {\n    fmt.Println("Hello, world!")\n}\n',
  rust: '// Rust\nfn main() {\n    println!("Hello, world!");\n}\n',
};

function generateCode(): string {
  return Array.from({ length: 10 }, () => Math.floor(Math.random() * 10)).join("");
}

// ── Express ───────────────────────────────────────────────────────────────────
const app = express();
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Keepalive for UptimeRobot
app.get("/ping", (_req, res) => res.json({ status: "ok", ts: Date.now() }));
app.get("/api/healthz", (_req, res) => res.json({ status: "ok" }));

// Sessions CRUD
const SUPPORTED = ["python","html","javascript","typescript","lua","java","cpp","php","go","rust"];

app.post("/api/sessions", async (req, res) => {
  try {
    const { language } = req.body;
    if (!SUPPORTED.includes(language)) {
      res.status(400).json({ error: `Language doit être: ${SUPPORTED.join(", ")}` }); return;
    }
    let code = generateCode();
    for (let i = 0; i < 10; i++) {
      const ex = await db.select({ id: sessionsTable.id }).from(sessionsTable).where(eq(sessionsTable.code, code));
      if (ex.length === 0) break;
      code = generateCode();
    }
    const content = DEFAULT_CONTENT[language] ?? `// ${language}\n`;
    const [s] = await db.insert(sessionsTable).values({ code, language, content }).returning();
    res.status(201).json({ id: s.id, code: s.code, language: s.language, content: s.content, createdAt: s.createdAt.toISOString(), updatedAt: s.updatedAt.toISOString() });
  } catch (e) { console.error(e); res.status(500).json({ error: "Erreur serveur" }); }
});

app.get("/api/sessions/:code", async (req, res) => {
  try {
    const [s] = await db.select().from(sessionsTable).where(eq(sessionsTable.code, req.params.code));
    if (!s) { res.status(404).json({ error: "Session introuvable" }); return; }
    res.json({ id: s.id, code: s.code, language: s.language, content: s.content, createdAt: s.createdAt.toISOString(), updatedAt: s.updatedAt.toISOString() });
  } catch (e) { console.error(e); res.status(500).json({ error: "Erreur serveur" }); }
});

app.delete("/api/sessions/:code", async (req, res) => {
  try {
    const del = await db.delete(sessionsTable).where(eq(sessionsTable.code, req.params.code)).returning({ id: sessionsTable.id });
    if (del.length === 0) { res.status(404).json({ error: "Session introuvable" }); return; }
    res.json({ success: true });
  } catch (e) { console.error(e); res.status(500).json({ error: "Erreur serveur" }); }
});

// AI fix
app.post("/api/ai/fix", async (req, res) => {
  try {
    const { code, error, language } = req.body as { code: string; error: string; language: string };
    const prompt = `Tu es expert en ${language}. Analyse ce code et cette erreur. Réponds UNIQUEMENT en JSON valide sans backticks.
Format: {"lines":[1],"explanation":"explication courte en français","fixedCode":"code complet corrigé"}
Code:\n\`\`\`${language}\n${code}\n\`\`\`\nErreur:\n${error}`;
    const raw = await callGemini(prompt);
    const match = raw.match(/\{[\s\S]*\}/);
    if (!match) { res.json({ explanation: raw.trim(), fixedCode: null, lines: [] }); return; }
    const parsed = JSON.parse(match[0]);
    res.json({ explanation: parsed.explanation ?? "", fixedCode: parsed.fixedCode ?? null, lines: parsed.lines ?? [] });
  } catch (e: any) { console.error("AI fix:", e.message); res.status(500).json({ error: e.message }); }
});

// AI chat
app.post("/api/ai/chat", async (req, res) => {
  try {
    const { messages, currentCode, language } = req.body as { messages: { role: string; text: string }[]; currentCode: string; language: string };
    const systemText = `Tu es expert en ${language} dans un éditeur collaboratif. Réponds en français, concis, sans salutation. Si tu donnes du code, utilise des blocs markdown.
Code actuel:\n\`\`\`${language}\n${currentCode || "(vide)"}\n\`\`\``;
    const allMessages = [
      { role: "user", text: systemText },
      { role: "model", text: "Compris, je suis prêt." },
      ...messages.map(m => ({ role: m.role === "assistant" ? "model" : "user", text: m.text })),
    ];
    const response = await callGeminiChat(allMessages);
    const cb = response.match(/```(?:[a-z]+)?\n?([\s\S]*?)```/);
    res.json({ response, codeBlock: cb ? cb[1].trim() : null });
  } catch (e: any) { console.error("AI chat:", e.message); res.status(500).json({ error: e.message }); }
});

// Serve built frontend
const distPath = path.join(__dirname, "dist");
app.use(express.static(distPath));
app.get("*", (_req, res) => res.sendFile(path.join(distPath, "index.html")));

// ── HTTP + WebSocket server ───────────────────────────────────────────────────
const server = http.createServer(app);
const wss = new WebSocketServer({ server, path: "/ws" });

interface Client { ws: WebSocket; sessionCode: string; hwid: string; }
const clients: Client[] = [];
function getSessionClients(sc: string) {
  return clients.filter(c => c.sessionCode === sc && c.ws.readyState === WebSocket.OPEN);
}

wss.on("connection", (ws) => {
  let sessionCode = "";
  let hwid = "";
  const exec = { proc: null as ChildProcessWithoutNullStreams | null, buf: "", waitingInput: false, tmpFile: "" };

  function send(obj: object) { if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(obj)); }
  function flushOutput(text: string, isError = false) { if (text) send({ type: "output_chunk", text, isError }); }
  function processBuffer() {
    const idx = exec.buf.indexOf(INPUT_MARKER);
    if (idx !== -1) {
      flushOutput(exec.buf.slice(0, idx));
      const prompt = exec.buf.slice(idx + INPUT_MARKER.length);
      exec.buf = ""; exec.waitingInput = true;
      send({ type: "input_needed", prompt });
    } else { flushOutput(exec.buf); exec.buf = ""; }
  }

  ws.on("message", async (rawMsg) => {
    try {
      const msg = JSON.parse(rawMsg.toString());

      if (msg.type === "join") {
        sessionCode = msg.sessionCode as string;
        hwid = (msg.hwid as string) || "unknown";
        const ei = clients.findIndex(c => c.ws === ws);
        if (ei !== -1) clients.splice(ei, 1);
        const others = getSessionClients(sessionCode);
        const isNew = others.length > 0 && !others.some(c => c.hwid === hwid);
        clients.push({ ws, sessionCode, hwid });
        const [session] = await db.select().from(sessionsTable).where(eq(sessionsTable.code, sessionCode));
        if (!session) { send({ type: "session_not_found" }); return; }
        send({ type: "init", content: session.content, language: session.language });
        if (isNew) for (const c of getSessionClients(sessionCode).filter(c => c.ws !== ws)) c.ws.send(JSON.stringify({ type: "user_joined" }));
        const count = getSessionClients(sessionCode).length;
        for (const c of getSessionClients(sessionCode)) c.ws.send(JSON.stringify({ type: "user_count", count }));
        console.log(`[WS] Joined ${sessionCode} (${hwid})`);
      }

      if (msg.type === "code_update" && sessionCode) {
        const content: string = msg.content;
        await db.update(sessionsTable).set({ content, updatedAt: new Date() }).where(eq(sessionsTable.code, sessionCode));
        for (const c of getSessionClients(sessionCode)) if (c.ws !== ws) c.ws.send(JSON.stringify({ type: "code_update", content }));
      }

      if (msg.type === "execute") {
        if (exec.proc) { try { exec.proc.kill("SIGKILL"); } catch {} exec.proc = null; }
        if (exec.tmpFile) { unlink(exec.tmpFile).catch(() => {}); exec.tmpFile = ""; }
        exec.buf = ""; exec.waitingInput = false;
        const userCode = (msg.code as string) ?? "";
        const tmpFile = join(tmpdir(), `cs_${Date.now()}_${Math.random().toString(36).slice(2)}.py`);
        exec.tmpFile = tmpFile;
        try { await writeFile(tmpFile, PYTHON_WRAPPER + "\n" + userCode, "utf8"); }
        catch (e) { console.error("[WS] write error", e); send({ type: "execution_done", exitCode: 1 }); return; }
        const proc = spawn(PYTHON_BIN, [tmpFile], { stdio: ["pipe", "pipe", "pipe"] });
        exec.proc = proc;
        proc.stdout.on("data", (chunk: Buffer) => { if (!exec.waitingInput) { exec.buf += chunk.toString(); processBuffer(); } });
        proc.stderr.on("data", (chunk: Buffer) => flushOutput(chunk.toString(), true));
        proc.on("close", (exitCode) => {
          exec.proc = null; exec.waitingInput = false;
          if (exec.buf) { flushOutput(exec.buf); exec.buf = ""; }
          send({ type: "execution_done", exitCode: exitCode ?? 0 });
          unlink(tmpFile).catch(() => {}); exec.tmpFile = "";
        });
        proc.on("error", (e) => { console.error("[WS] spawn error", e); send({ type: "output_chunk", text: `Error: ${e.message}`, isError: true }); send({ type: "execution_done", exitCode: 1 }); });
      }

      if (msg.type === "input_response" && exec.proc?.stdin && exec.waitingInput) {
        exec.waitingInput = false;
        exec.proc.stdin.write((msg.value as string) + "\n");
      }

      if (msg.type === "kill_execution") {
        if (exec.proc) { try { exec.proc.kill("SIGKILL"); } catch {} exec.proc = null; }
        exec.waitingInput = false; exec.buf = "";
        send({ type: "execution_done", exitCode: -1 });
      }

    } catch (e) { console.error("[WS] error", e); }
  });

  ws.on("close", () => {
    const i = clients.findIndex(c => c.ws === ws);
    if (i !== -1) clients.splice(i, 1);
    if (exec.proc) { try { exec.proc.kill("SIGKILL"); } catch {} }
    if (exec.tmpFile) unlink(exec.tmpFile).catch(() => {});
    if (sessionCode) {
      const count = getSessionClients(sessionCode).length;
      for (const c of getSessionClients(sessionCode)) c.ws.send(JSON.stringify({ type: "user_count", count }));
    }
  });

  ws.on("error", (e) => console.error("[WS]", e));
});

const port = Number(process.env["PORT"] ?? 5000);
server.listen(port, "0.0.0.0", () => console.log(`[Server] http://localhost:${port}`));
