import { useRef, useCallback, forwardRef, useImperativeHandle } from "react";
import CodeMirror, { type ReactCodeMirrorRef } from "@uiw/react-codemirror";
import { python } from "@codemirror/lang-python";
import { html } from "@codemirror/lang-html";
import { javascript } from "@codemirror/lang-javascript";
import { java } from "@codemirror/lang-java";
import { cpp } from "@codemirror/lang-cpp";
import { php } from "@codemirror/lang-php";
import { rust } from "@codemirror/lang-rust";
import { StreamLanguage } from "@codemirror/language";
import { lua } from "@codemirror/legacy-modes/mode/lua";
import { go } from "@codemirror/legacy-modes/mode/go";
import { EditorView, keymap } from "@codemirror/view";
import { defaultKeymap, indentWithTab } from "@codemirror/commands";
import { autocompletion, CompletionContext, type CompletionResult } from "@codemirror/autocomplete";
import { createTheme } from "@uiw/codemirror-themes";
import { tags as t } from "@lezer/highlight";

const PYTHON_BUILTINS = [
  "print","input","len","range","int","float","str","list","dict","set","tuple",
  "type","isinstance","enumerate","zip","map","filter","sorted","reversed","max",
  "min","sum","abs","round","open","super","hasattr","getattr","setattr","vars",
  "dir","bool","bytes","chr","ord","hex","oct","bin","format","repr","eval",
  "exec","all","any","iter","next","object","property","help","id","hash",
];

const PYTHON_KEYWORDS = [
  "False","None","True","and","as","assert","async","await","break","class",
  "continue","def","del","elif","else","except","finally","for","from","global",
  "if","import","in","is","lambda","nonlocal","not","or","pass","raise","return",
  "try","while","with","yield",
];

const JS_KEYWORDS = [
  "const","let","var","function","return","if","else","for","while","do","break",
  "continue","switch","case","default","class","new","this","typeof","instanceof",
  "null","undefined","true","false","async","await","import","export","from","of",
  "in","throw","try","catch","finally","delete","void","yield","extends","super",
];

const JS_BUILTINS = [
  "console","log","error","warn","Math","Array","Object","String","Number","Boolean",
  "JSON","Date","RegExp","Promise","Set","Map","parseInt","parseFloat","isNaN",
  "isFinite","setTimeout","setInterval","clearTimeout","clearInterval","fetch",
  "document","window","localStorage","sessionStorage","alert","confirm","prompt",
];

function extractUserVars(code: string): string[] {
  const varSet = new Set<string>();
  const patterns = [
    /^[ \t]*(?:const|let|var)\s+([a-zA-Z_$]\w*)/gm,
    /^[ \t]*([a-zA-Z_]\w*)\s*=/gm,
    /\bdef\s+([a-zA-Z_]\w*)/g,
    /\bfunction\s+([a-zA-Z_$]\w*)/g,
    /\bclass\s+([a-zA-Z_]\w*)/g,
  ];
  for (const re of patterns) {
    let m;
    while ((m = re.exec(code)) !== null) varSet.add(m[1]);
  }
  return Array.from(varSet);
}

function getCompletions(code: string, lang: string) {
  return (context: CompletionContext): CompletionResult | null => {
    const word = context.matchBefore(/\w*/);
    if (!word || (word.from === word.to && !context.explicit)) return null;

    const userVars = extractUserVars(code);
    const isPython = lang === "python";
    const isJS = ["javascript", "typescript"].includes(lang);

    const options = [
      ...(isPython ? PYTHON_KEYWORDS : isJS ? JS_KEYWORDS : []).map(k => ({ label: k, type: "keyword" })),
      ...(isPython ? PYTHON_BUILTINS : isJS ? JS_BUILTINS : []).map(b => ({ label: b, type: "function" })),
      ...userVars.map(v => ({ label: v, type: "variable" })),
    ];

    return { from: word.from, options };
  };
}

const darkTheme = createTheme({
  theme: "dark",
  settings: {
    background: "transparent",
    foreground: "#e2e8f0",
    caret: "#a78bfa",
    selection: "#3730a360",
    selectionMatch: "#3730a330",
    lineHighlight: "#ffffff06",
    gutterBackground: "#0d0d1a",
    gutterForeground: "#374151",
    gutterBorder: "transparent",
    fontFamily: "'JetBrains Mono', 'Fira Code', 'Cascadia Code', monospace",
  },
  styles: [
    { tag: t.keyword,                  color: "#f472b6" },
    { tag: t.definitionKeyword,        color: "#c084fc" },
    { tag: t.controlKeyword,           color: "#f472b6" },
    { tag: t.string,                   color: "#fbbf24" },
    { tag: t.special(t.string),        color: "#fcd34d" },
    { tag: t.comment,                  color: "#4b5563", fontStyle: "italic" },
    { tag: t.number,                   color: "#34d399" },
    { tag: t.bool,                     color: "#f472b6" },
    { tag: t.null,                     color: "#f472b6" },
    { tag: t.function(t.variableName), color: "#60a5fa" },
    { tag: t.definition(t.variableName), color: "#93c5fd" },
    { tag: t.variableName,             color: "#e2e8f0" },
    { tag: t.propertyName,             color: "#86efac" },
    { tag: t.operator,                 color: "#a5b4fc" },
    { tag: t.punctuation,              color: "#94a3b8" },
    { tag: t.typeName,                 color: "#c084fc" },
    { tag: t.className,                color: "#c084fc" },
    { tag: t.tagName,                  color: "#f472b6" },
    { tag: t.attributeName,            color: "#60a5fa" },
    { tag: t.attributeValue,           color: "#fbbf24" },
    { tag: t.angleBracket,             color: "#94a3b8" },
    { tag: t.meta,                     color: "#6b7280" },
    { tag: t.moduleKeyword,            color: "#c084fc" },
    { tag: t.namespace,                color: "#c084fc" },
  ],
});

function getLangExtension(lang: string) {
  switch (lang) {
    case "python":     return python();
    case "html":       return html();
    case "javascript": return javascript({ jsx: false });
    case "typescript": return javascript({ typescript: true });
    case "java":       return java();
    case "cpp":        return cpp();
    case "php":        return php({ plain: false });
    case "rust":       return rust();
    case "lua":        return StreamLanguage.define(lua);
    case "go":         return StreamLanguage.define(go);
    default:           return javascript();
  }
}

export interface CodeEditorHandle {
  setValue: (value: string) => void;
}

interface CodeEditorProps {
  value: string;
  language: string;
  onChange: (value: string) => void;
}

export const CodeEditor = forwardRef<CodeEditorHandle, CodeEditorProps>(
  ({ value, language, onChange }, ref) => {
    const editorRef = useRef<ReactCodeMirrorRef>(null);

    useImperativeHandle(ref, () => ({
      setValue: (newValue: string) => {
        const view = editorRef.current?.view;
        if (!view) return;
        const current = view.state.doc.toString();
        if (current === newValue) return;

        const sel = view.state.selection;
        const newLen = newValue.length;
        view.dispatch({
          changes: { from: 0, to: current.length, insert: newValue },
          selection: {
            anchor: Math.min(sel.main.anchor, newLen),
            head: Math.min(sel.main.head, newLen),
          },
          scrollIntoView: false,
        });
      },
    }), []);

    const handleChange = useCallback((val: string) => {
      onChange(val);
    }, [onChange]);

    const extensions = [
      getLangExtension(language),
      autocompletion({ override: [getCompletions(value, language)], activateOnTyping: true }),
      keymap.of([indentWithTab, ...defaultKeymap]),
      EditorView.lineWrapping,
      EditorView.theme({
        "&": { height: "100%", fontSize: "14px" },
        ".cm-scroller": { overflow: "auto", fontFamily: "'JetBrains Mono', 'Fira Code', monospace" },
        ".cm-content": { padding: "12px 16px", caretColor: "#a78bfa" },
        ".cm-focused": { outline: "none" },
        ".cm-tooltip-autocomplete": {
          background: "#1e293b",
          border: "1px solid #334155",
          borderRadius: "12px",
          overflow: "hidden",
          boxShadow: "0 8px 32px rgba(0,0,0,0.7)",
          zIndex: "100",
        },
        ".cm-tooltip-autocomplete ul li": {
          padding: "7px 14px",
          fontFamily: "'JetBrains Mono', monospace",
          fontSize: "13px",
          color: "#cbd5e1",
        },
        ".cm-tooltip-autocomplete ul li[aria-selected]": {
          background: "#4c1d95",
          color: "#e2e8f0",
        },
        ".cm-completionIcon-keyword":  { "&::after": { content: "'kw'", color: "#f472b6", fontSize: "10px" } },
        ".cm-completionIcon-function": { "&::after": { content: "'fn'", color: "#60a5fa", fontSize: "10px" } },
        ".cm-completionIcon-variable": { "&::after": { content: "'var'", color: "#93c5fd", fontSize: "10px" } },
        ".cm-gutters": { background: "#0d0d1a", borderRight: "1px solid #ffffff08" },
        ".cm-lineNumbers .cm-gutterElement": { color: "#374151", padding: "0 8px 0 12px" },
        ".cm-activeLine": { background: "#ffffff04" },
        ".cm-activeLineGutter": { background: "#ffffff08", color: "#6b7280" },
        "& .cm-selectionBackground": { background: "#3730a360 !important" },
        ".cm-cursor": { borderLeftColor: "#a78bfa" },
      }),
    ];

    return (
      <CodeMirror
        ref={editorRef}
        value={value}
        onChange={handleChange}
        extensions={extensions}
        theme={darkTheme}
        basicSetup={{
          lineNumbers: true,
          foldGutter: false,
          dropCursor: false,
          allowMultipleSelections: false,
          indentOnInput: true,
          bracketMatching: true,
          closeBrackets: true,
          autocompletion: false,
          highlightActiveLine: true,
          highlightSelectionMatches: false,
          history: true,
        }}
        style={{ height: "100%", flex: 1, minHeight: 0 }}
      />
    );
  }
);

CodeEditor.displayName = "CodeEditor";
