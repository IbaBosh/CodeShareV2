# CodeShare — Éditeur collaboratif

## Configuration requise pour l'IA

1. Crée une clé API Gemini **gratuite** sur : https://aistudio.google.com/app/apikey

2. Dans ton site Netlify : **Site settings → Environment variables** → Ajoute :
   - `VITE_GEMINI_API_KEY` = ta clé Gemini

3. Pour les sessions (backend) : ajoute aussi `VITE_API_URL` avec l'URL de ton backend Express.

## Installation locale

```bash
npm install
cp .env.example .env.local
# Remplis VITE_GEMINI_API_KEY dans .env.local
npm run dev
```

## Build pour Netlify

```bash
npm run build
# Le dossier dist/ contient les fichiers à déployer
```

## Fonctionnalités IA

- **Auto-correct IA** : quand ton code a une erreur, l'IA propose automatiquement une correction
- **Assistant IA** (bouton "IA" en haut) : chat avec l'IA sur ton code, historique sauvegardé par session dans le navigateur
