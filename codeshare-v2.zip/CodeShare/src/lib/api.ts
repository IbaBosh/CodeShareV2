import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";

export interface Session {
  id: number;
  code: string;
  language: string;
  content: string;
  name?: string;
  createdAt: string;
  updatedAt: string;
}

export interface SessionInput {
  language: string;
  name?: string;
}

function generateCode(): string {
  return Array.from({ length: 10 }, () => Math.floor(Math.random() * 10)).join("");
}

export const SESSION_PREFIX = "codeshare_session_";
const HISTORY_KEY = "codeshare_sessions";

function getLangSessionCount(language: string): number {
  try {
    const raw = localStorage.getItem(HISTORY_KEY);
    if (!raw) return 0;
    const hist = JSON.parse(raw) as { language: string }[];
    return hist.filter(h => h.language === language).length;
  } catch { return 0; }
}

function autoName(language: string): string {
  const labels: Record<string, string> = {
    python: "Python", javascript: "JavaScript", html: "HTML/CSS",
    typescript: "TypeScript", lua: "Lua", java: "Java",
    cpp: "C++", php: "PHP", go: "Go", rust: "Rust",
  };
  const label = labels[language] ?? language;
  const n = getLangSessionCount(language) + 1;
  return `Session ${label} ${n}`;
}

export function saveSession(session: Session) {
  try { localStorage.setItem(SESSION_PREFIX + session.code, JSON.stringify(session)); } catch {}
}

export function loadSession(code: string): Session | null {
  try {
    const stored = localStorage.getItem(SESSION_PREFIX + code);
    return stored ? (JSON.parse(stored) as Session) : null;
  } catch { return null; }
}

export function deleteSessionStorage(code: string) {
  try { localStorage.removeItem(SESSION_PREFIX + code); } catch {}
}

export function updateSessionField(code: string, fields: Partial<Session>) {
  const s = loadSession(code);
  if (s) saveSession({ ...s, ...fields, updatedAt: new Date().toISOString() });
}

export const getGetSessionQueryKey = (code: string) => [`/api/sessions/${code}`] as const;

export function useGetSession(
  code: string,
  options?: { query?: { retry?: boolean } }
) {
  return useQuery({
    queryKey: getGetSessionQueryKey(code),
    queryFn: () => {
      const session = loadSession(code);
      if (!session) throw new Error("Session not found");
      return Promise.resolve(session);
    },
    retry: options?.query?.retry ?? false,
    enabled: !!code,
  });
}

export function useCreateSession() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (vars: { data: SessionInput }) => {
      const code = generateCode();
      const name = vars.data.name?.trim() || autoName(vars.data.language);
      const session: Session = {
        id: Date.now(),
        code,
        language: vars.data.language,
        content: "",
        name,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };
      saveSession(session);
      return Promise.resolve(session);
    },
    onSuccess: (session) => {
      queryClient.setQueryData(getGetSessionQueryKey(session.code), session);
    },
  });
}
