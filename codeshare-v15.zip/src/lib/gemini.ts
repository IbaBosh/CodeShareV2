const MAX_RETRIES = 3;
const RETRY_DELAY_MS = 1200;

async function sleep(ms: number) {
  return new Promise((r) => setTimeout(r, ms));
}

async function apiFetch(path: string, body: object): Promise<Response> {
  const base = typeof window !== "undefined" ? window.location.origin : "";
  for (let attempt = 0; attempt <= MAX_RETRIES; attempt++) {
    try {
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 35000);
      const res = await fetch(`${base}${path}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
        signal: controller.signal,
      });
      clearTimeout(timeout);
      if (res.status === 429 || res.status === 503 || res.status === 502 || res.status === 500) {
        if (attempt < MAX_RETRIES) { await sleep(RETRY_DELAY_MS * (attempt + 1)); continue; }
      }
      return res;
    } catch (err) {
      if (err instanceof Error && err.name === "AbortError") {
        if (attempt < MAX_RETRIES) { await sleep(RETRY_DELAY_MS); continue; }
        throw new Error("L'IA met trop de temps à répondre. Réessaie dans un instant.");
      }
      if (attempt >= MAX_RETRIES) throw err;
      await sleep(RETRY_DELAY_MS * (attempt + 1));
    }
  }
  throw new Error("L'IA n'est pas disponible pour le moment. Réessaie dans un instant.");
}

export async function callAIFix(
  code: string,
  error: string,
  language: string
): Promise<{ explanation: string; fixedCode: string | null; lines: number[] }> {
  for (let attempt = 0; attempt <= MAX_RETRIES; attempt++) {
    try {
      const res = await apiFetch("/api/ai/fix", {
        code: code.slice(0, 3000),
        error: error.slice(0, 800),
        language,
      });
      if (!res.ok) {
        const data = await res.json().catch(() => ({})) as { error?: string };
        if (attempt < MAX_RETRIES) { await sleep(RETRY_DELAY_MS * (attempt + 1)); continue; }
        throw new Error(data.error ?? "L'IA est temporairement indisponible. Réessaie dans un instant.");
      }
      const data = await res.json() as { explanation?: string; fixedCode?: string | null; lines?: number[]; error?: string };
      if (data.error) {
        if (attempt < MAX_RETRIES) { await sleep(RETRY_DELAY_MS * (attempt + 1)); continue; }
        throw new Error("L'IA est temporairement indisponible. Réessaie dans un instant.");
      }
      return { explanation: data.explanation ?? "", fixedCode: data.fixedCode ?? null, lines: data.lines ?? [] };
    } catch (err) {
      if (err instanceof Error && (err.message.includes("trop de temps") || err.message.includes("disponible"))) throw err;
      if (attempt >= MAX_RETRIES) throw err;
      await sleep(RETRY_DELAY_MS * (attempt + 1));
    }
  }
  throw new Error("L'IA n'est pas disponible pour le moment. Réessaie dans un instant.");
}

export async function callAIChat(
  messages: { role: string; text: string }[],
  currentCode: string,
  language: string
): Promise<{ response: string; codeBlock: string | null }> {
  for (let attempt = 0; attempt <= MAX_RETRIES; attempt++) {
    try {
      const res = await apiFetch("/api/ai/chat", { messages, currentCode, language });
      if (!res.ok) {
        const data = await res.json().catch(() => ({})) as { error?: string };
        if (attempt < MAX_RETRIES) { await sleep(RETRY_DELAY_MS * (attempt + 1)); continue; }
        throw new Error(data.error ?? "L'IA est temporairement indisponible. Réessaie dans un instant.");
      }
      const data = await res.json() as { response?: string; codeBlock?: string | null; error?: string };
      if (data.error) {
        if (attempt < MAX_RETRIES) { await sleep(RETRY_DELAY_MS * (attempt + 1)); continue; }
        throw new Error("L'IA est temporairement indisponible. Réessaie dans un instant.");
      }
      const response = data.response ?? "";
      if (!response && attempt < MAX_RETRIES) { await sleep(RETRY_DELAY_MS); continue; }
      return { response: response || "Aucune réponse reçue.", codeBlock: data.codeBlock ?? null };
    } catch (err) {
      if (err instanceof Error && (err.message.includes("trop de temps") || err.message.includes("disponible"))) throw err;
      if (attempt >= MAX_RETRIES) throw err;
      await sleep(RETRY_DELAY_MS * (attempt + 1));
    }
  }
  throw new Error("L'IA n'est pas disponible pour le moment. Réessaie dans un instant.");
}
