const MODELS = ["gemini-1.5-flash", "gemini-1.5-flash-latest", "gemini-2.0-flash"];
const MAX_RETRIES = 5;
const RETRY_DELAY_MS = 1500;

function getApiKey(): string {
  const key = import.meta.env.VITE_GEMINI_API_KEY as string | undefined;
  if (!key) throw new Error("VITE_GEMINI_API_KEY n'est pas configure. Ajoute cette variable dans les parametres Render (Environment -> Add Environment Variable).");
  return key;
}

async function sleep(ms: number) {
  return new Promise((r) => setTimeout(r, ms));
}

async function geminiRequest(body: object): Promise<string> {
  const apiKey = getApiKey();

  for (let attempt = 0; attempt <= MAX_RETRIES; attempt++) {
    const model = MODELS[attempt % MODELS.length];
    const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${apiKey}`;
    try {
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 30000);

      const res = await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
        signal: controller.signal,
      });

      clearTimeout(timeout);

      if (res.status === 429 || res.status === 503 || res.status === 500 || res.status === 502) {
        if (attempt < MAX_RETRIES) { await sleep(RETRY_DELAY_MS * (attempt + 1)); continue; }
        throw new Error("L'IA est temporairement saturee, reessaie dans quelques secondes.");
      }

      if (!res.ok) {
        if (attempt < MAX_RETRIES) { await sleep(RETRY_DELAY_MS * (attempt + 1)); continue; }
        throw new Error(`L'IA n'est pas disponible. Reessaie dans un instant.`);
      }

      const data = (await res.json()) as {
        candidates?: { content?: { parts?: { text?: string }[] } }[];
        error?: { message?: string };
      };

      if (data.error?.message) {
        if (attempt < MAX_RETRIES) { await sleep(RETRY_DELAY_MS * (attempt + 1)); continue; }
        throw new Error("L'IA est temporairement indisponible. Reessaie dans un instant.");
      }

      const text = data?.candidates?.[0]?.content?.parts?.[0]?.text ?? "";
      if (!text && attempt < MAX_RETRIES) { await sleep(RETRY_DELAY_MS); continue; }
      return text;
    } catch (err) {
      if (err instanceof Error && err.name === "AbortError") {
        if (attempt < MAX_RETRIES) { await sleep(RETRY_DELAY_MS); continue; }
        throw new Error("L'IA met trop de temps a repondre. Reessaie dans un instant.");
      }
      if (err instanceof Error && (err.message.includes("VITE_GEMINI") || err.message.includes("configure"))) throw err;
      if (attempt >= MAX_RETRIES) throw err;
      await sleep(RETRY_DELAY_MS * (attempt + 1));
    }
  }
  throw new Error("L'IA n'est pas disponible pour le moment. Reessaie dans un instant.");
}

export async function geminiGenerate(prompt: string): Promise<string> {
  return geminiRequest({
    contents: [{ role: "user", parts: [{ text: prompt }] }],
    generationConfig: { temperature: 0.3, maxOutputTokens: 2048 },
  });
}

export async function geminiChat(messages: { role: string; text: string }[]): Promise<string> {
  const contents = messages.map((m) => ({
    role: m.role === "assistant" || m.role === "model" ? "model" : "user",
    parts: [{ text: m.text }],
  }));
  return geminiRequest({
    contents,
    generationConfig: { temperature: 0.5, maxOutputTokens: 2048 },
  });
}

export async function callAIFix(
  code: string,
  error: string,
  language: string
): Promise<{ explanation: string; fixedCode: string | null; lines: number[] }> {
  const langName = { python: "Python", javascript: "JavaScript", html: "HTML/CSS", typescript: "TypeScript", lua: "Lua", java: "Java", cpp: "C++", php: "PHP", go: "Go", rust: "Rust" }[language] ?? language;

  const prompt = `Tu es un expert ${langName}.
Analyse ce code et cette erreur. Reponds UNIQUEMENT avec du JSON valide, sans backticks ni markdown.
Format exact : {"lines":[1,2],"explanation":"Explication courte et claire en francais de l'erreur","fixedCode":"code complet corrige ici"}

Code :
\`\`\`${language}
${code.slice(0, 3000)}
\`\`\`

Erreur :
${error.slice(0, 800)}`;

  const raw = await geminiGenerate(prompt);
  const jsonMatch = raw.match(/\{[\s\S]*\}/);
  if (!jsonMatch) return { explanation: raw.trim().slice(0, 300), fixedCode: null, lines: [] };
  try {
    const parsed = JSON.parse(jsonMatch[0]) as { explanation?: string; fixedCode?: string | null; lines?: number[] };
    return { explanation: parsed.explanation ?? "", fixedCode: parsed.fixedCode ?? null, lines: parsed.lines ?? [] };
  } catch {
    return { explanation: raw.trim().slice(0, 300), fixedCode: null, lines: [] };
  }
}

export async function callAIChat(
  messages: { role: string; text: string }[],
  currentCode: string,
  language: string
): Promise<{ response: string; codeBlock: string | null }> {
  const langName = language || "code";
  const systemText = `Tu es un assistant expert en ${langName} dans un éditeur de code collaboratif. Réponds en français, de manière concise et directe (2-4 phrases max). Ne génère JAMAIS de plan de cours, curriculum, liste de leçons ou liste numérotée longue. Si tu fournis du code, utilise des blocs markdown. Code actuel dans l'éditeur :\n\`\`\`${langName}\n${currentCode || "(vide)"}\n\`\`\``;
  const allMessages = [
    { role: "user", text: systemText },
    { role: "model", text: "Compris, je t'aide de façon concise." },
    ...messages,
  ];
  const response = await geminiChat(allMessages);
  const cb = response.match(/```(?:[a-z]*)\n?([\s\S]*?)```/);
  return { response, codeBlock: cb ? cb[1].trim() : null };
}
