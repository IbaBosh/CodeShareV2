import express from "express";
import http from "http";
import path from "path";
import { fileURLToPath } from "url";
import cors from "cors";
import { WebSocketServer, WebSocket } from "ws";
import { spawn, type ChildProcessWithoutNullStreams } from "child_process";
import { writeFile, unlink } from "fs/promises";
import { tmpdir } from "os";
import { join } from "path";
import { execSync } from "child_process";

const __dirname = path.dirname(fileURLToPath(import.meta.url));

// ── In-memory sessions (no DB needed) ────────────────────────────────────────
interface SessionData {
  code: string;
  language: string;
  content: string;
  updatedAt: number;
}
const sessions = new Map<string, SessionData>();

// ── Python detection ──────────────────────────────────────────────────────────
function findPython(): string {
  const candidates = [
    "/nix/store/flbj8bq2vznkcwss7sm0ky8rd0k6kar7-python-wrapped-0.1.0/bin/python3",
    "python3", "python",
  ];
  for (const c of candidates) {
    try { execSync(`${c} --version`, { timeout: 3000, stdio: "pipe" }); return c; } catch {}
  }
  return "python3";
}
const PYTHON_BIN = findPython();
console.log(`[Python] Using: ${PYTHON_BIN}`);

const INPUT_MARKER = "\x00INPUT_REQ\x00";
const PYTHON_WRAPPER = [
  "import sys as __sys, builtins as __builtins_mod",
  "def input(prompt=''):",
  "    __sys.stdout.write('\\x00INPUT_REQ\\x00' + str(prompt))",
  "    __sys.stdout.flush()",
  "    return __sys.stdin.readline().rstrip('\\n')",
  "__builtins_mod.input = input",
  "",
].join("\n");

// ── Gemini AI ─────────────────────────────────────────────────────────────────
const GEMINI_MODELS = [
  "gemini-2.5-flash-lite",
  "gemini-2.5-flash",
  "gemini-2.5-flash-lite",
  "gemini-2.5-flash",
];
const GEMINI_RETRY_DELAY = 1500;

function getGeminiKey(): string {
  const key =
    process.env["GEMINI_API_KEY"] ||
    process.env["VITE_GEMINI_API_KEY"] ||
    process.env["VITE_GEMINI_KEY"] ||
    process.env["GEMINI_KEY"] ||
    "";
  if (!key) throw new Error("Clé API Gemini non configurée. Ajoute GEMINI_API_KEY dans les variables d'environnement Render.");
  return key;
}

async function geminiPost(body: object, attempt: number): Promise<string> {
  const apiKey = getGeminiKey();
  const model = GEMINI_MODELS[attempt % GEMINI_MODELS.length];
  const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${apiKey}`;
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 30000);
  try {
    const res = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
      signal: controller.signal,
    });
    clearTimeout(timeout);
    if (res.status === 429 || res.status === 500 || res.status === 502 || res.status === 503) {
      throw Object.assign(new Error(`Gemini ${res.status}`), { retryable: true });
    }
    if (!res.ok) {
      const errData = await res.json().catch(() => ({})) as any;
      const msg = errData?.error?.message ?? `Gemini erreur ${res.status}`;
      throw Object.assign(new Error(msg), { retryable: res.status >= 500 });
    }
    const data = await res.json() as any;
    if (data?.error?.message) throw Object.assign(new Error(data.error.message), { retryable: true });
    return data?.candidates?.[0]?.content?.parts?.[0]?.text ?? "";
  } catch (err) {
    clearTimeout(timeout);
    throw err;
  }
}

async function callGemini(prompt: string): Promise<string> {
  const body = {
    contents: [{ role: "user", parts: [{ text: prompt }] }],
    generationConfig: { temperature: 0.3, maxOutputTokens: 2048 },
  };
  for (let attempt = 0; attempt <= 4; attempt++) {
    try {
      const text = await geminiPost(body, attempt);
      if (!text && attempt < 4) { await new Promise(r => setTimeout(r, GEMINI_RETRY_DELAY)); continue; }
      return text;
    } catch (err: any) {
      if (attempt >= 4) throw err;
      if (err?.retryable !== false) { await new Promise(r => setTimeout(r, GEMINI_RETRY_DELAY * (attempt + 1))); continue; }
      throw err;
    }
  }
  throw new Error("L'IA est indisponible pour le moment.");
}

async function callGeminiChat(messages: { role: string; text: string }[]): Promise<string> {
  const contents = messages.map(m => ({
    role: m.role === "assistant" || m.role === "model" ? "model" : "user",
    parts: [{ text: m.text }],
  }));
  const body = { contents, generationConfig: { temperature: 0.5, maxOutputTokens: 2048 } };
  for (let attempt = 0; attempt <= 4; attempt++) {
    try {
      const text = await geminiPost(body, attempt);
      if (!text && attempt < 4) { await new Promise(r => setTimeout(r, GEMINI_RETRY_DELAY)); continue; }
      return text;
    } catch (err: any) {
      if (attempt >= 4) throw err;
      if (err?.retryable !== false) { await new Promise(r => setTimeout(r, GEMINI_RETRY_DELAY * (attempt + 1))); continue; }
      throw err;
    }
  }
  throw new Error("L'IA est indisponible pour le moment.");
}

// ── Express ───────────────────────────────────────────────────────────────────
const app = express();
app.use(cors());
app.use(express.json());

app.get("/ping", (_req, res) => res.json({ status: "ok", ts: Date.now() }));
app.get("/api/healthz", (_req, res) => res.json({ status: "ok" }));

// AI fix endpoint
app.post("/api/ai/fix", async (req, res) => {
  try {
    const { code, error, language } = req.body as { code: string; error: string; language: string };
    const prompt = `Tu es expert en ${language}. Analyse ce code et cette erreur. Réponds UNIQUEMENT en JSON valide sans backticks.
Format: {"lines":[1],"explanation":"explication courte en français","fixedCode":"code complet corrigé"}
Code:\n\`\`\`${language}\n${code}\n\`\`\`\nErreur:\n${error}`;
    const raw = await callGemini(prompt);
    const match = raw.match(/\{[\s\S]*\}/);
    if (!match) { res.json({ explanation: raw.trim(), fixedCode: null, lines: [] }); return; }
    const parsed = JSON.parse(match[0]);
    res.json({ explanation: parsed.explanation ?? "", fixedCode: parsed.fixedCode ?? null, lines: parsed.lines ?? [] });
  } catch (e: any) { res.status(500).json({ error: e.message }); }
});

// AI chat endpoint
app.post("/api/ai/chat", async (req, res) => {
  try {
    const { messages, currentCode, language } = req.body as { messages: { role: string; text: string }[]; currentCode: string; language: string };
    const systemText = `Tu es expert en ${language} dans un éditeur collaboratif. Réponds en français, concis. Si tu donnes du code, utilise des blocs markdown.
Code actuel:\n\`\`\`${language}\n${currentCode || "(vide)"}\n\`\`\``;
    const allMessages = [
      { role: "user", text: systemText },
      { role: "model", text: "Compris." },
      ...messages.map(m => ({ role: m.role === "assistant" ? "model" : "user", text: m.text })),
    ];
    const response = await callGeminiChat(allMessages);
    const cb = response.match(/```(?:[a-z]+)?\n?([\s\S]*?)```/);
    res.json({ response, codeBlock: cb ? cb[1].trim() : null });
  } catch (e: any) { res.status(500).json({ error: e.message }); }
});

// Serve built frontend
const distPath = path.join(__dirname, "dist");
app.use(express.static(distPath));
app.get("*", (_req, res) => res.sendFile(path.join(distPath, "index.html")));

// ── HTTP + WebSocket ──────────────────────────────────────────────────────────
const server = http.createServer(app);
const wss = new WebSocketServer({ server, path: "/ws" });

interface Client { ws: WebSocket; sessionCode: string; hwid: string; }
const clients: Client[] = [];

function getSessionClients(sc: string) {
  return clients.filter(c => c.sessionCode === sc && c.ws.readyState === WebSocket.OPEN);
}

wss.on("connection", (ws) => {
  let sessionCode = "";
  let hwid = "";
  const exec = {
    proc: null as ChildProcessWithoutNullStreams | null,
    buf: "",
    waitingInput: false,
    tmpFile: "",
  };

  function send(obj: object) {
    if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(obj));
  }

  function flushOutput(text: string, isError = false) {
    if (text) send({ type: "output_chunk", text, isError });
  }

  function processBuffer() {
    const idx = exec.buf.indexOf(INPUT_MARKER);
    if (idx !== -1) {
      flushOutput(exec.buf.slice(0, idx));
      const prompt = exec.buf.slice(idx + INPUT_MARKER.length);
      exec.buf = "";
      exec.waitingInput = true;
      send({ type: "input_needed", prompt });
    } else {
      flushOutput(exec.buf);
      exec.buf = "";
    }
  }

  ws.on("message", async (rawMsg) => {
    try {
      const msg = JSON.parse(rawMsg.toString());

      // ── Join session ──────────────────────────────────────────────────────
      if (msg.type === "join") {
        sessionCode = msg.sessionCode as string;
        hwid = (msg.hwid as string) || "anon";

        // Remove old client entry if reconnecting
        const ei = clients.findIndex(c => c.ws === ws);
        if (ei !== -1) clients.splice(ei, 1);

        const others = getSessionClients(sessionCode);
        const isNew = others.length > 0 && !others.some(c => c.hwid === hwid);
        clients.push({ ws, sessionCode, hwid });

        // Ensure session exists in memory
        if (!sessions.has(sessionCode)) {
          sessions.set(sessionCode, {
            code: sessionCode,
            language: (msg.language as string) || "python",
            content: (msg.content as string) || "",
            updatedAt: Date.now(),
          });
        }

        const session = sessions.get(sessionCode)!;
        send({ type: "init", content: session.content, language: session.language });

        if (isNew) {
          for (const c of getSessionClients(sessionCode).filter(c => c.ws !== ws)) {
            c.ws.send(JSON.stringify({ type: "user_joined" }));
          }
        }

        const count = getSessionClients(sessionCode).length;
        for (const c of getSessionClients(sessionCode)) {
          c.ws.send(JSON.stringify({ type: "user_count", count }));
        }

        console.log(`[WS] ${hwid} joined ${sessionCode} (${getSessionClients(sessionCode).length} users)`);
      }

      // ── Code update ───────────────────────────────────────────────────────
      if (msg.type === "code_update" && sessionCode) {
        const content: string = msg.content;
        const session = sessions.get(sessionCode);
        if (session) {
          session.content = content;
          session.updatedAt = Date.now();
        }
        for (const c of getSessionClients(sessionCode)) {
          if (c.ws !== ws) c.ws.send(JSON.stringify({ type: "code_update", content }));
        }
      }

      // ── Execute Python ────────────────────────────────────────────────────
      if (msg.type === "execute") {
        if (exec.proc) { try { exec.proc.kill("SIGKILL"); } catch {} exec.proc = null; }
        if (exec.tmpFile) { unlink(exec.tmpFile).catch(() => {}); exec.tmpFile = ""; }
        exec.buf = "";
        exec.waitingInput = false;

        const userCode = (msg.code as string) ?? "";
        const tmpFile = join(tmpdir(), `cs_${Date.now()}_${Math.random().toString(36).slice(2)}.py`);
        exec.tmpFile = tmpFile;

        try {
          await writeFile(tmpFile, PYTHON_WRAPPER + "\n" + userCode, "utf8");
        } catch (e) {
          console.error("[WS] write error", e);
          send({ type: "execution_done", exitCode: 1 });
          return;
        }

        const proc = spawn(PYTHON_BIN, ["-u", tmpFile], { stdio: ["pipe", "pipe", "pipe"], env: { ...process.env, PYTHONUNBUFFERED: "1", PYTHONDONTWRITEBYTECODE: "1" } });
        exec.proc = proc;

        proc.stdout.on("data", (chunk: Buffer) => {
          if (!exec.waitingInput) {
            exec.buf += chunk.toString();
            processBuffer();
          }
        });

        proc.stderr.on("data", (chunk: Buffer) => flushOutput(chunk.toString(), true));

        proc.on("close", (exitCode) => {
          exec.proc = null;
          exec.waitingInput = false;
          if (exec.buf) { flushOutput(exec.buf); exec.buf = ""; }
          send({ type: "execution_done", exitCode: exitCode ?? 0 });
          unlink(tmpFile).catch(() => {});
          exec.tmpFile = "";
        });

        proc.on("error", (e) => {
          console.error("[WS] spawn error", e);
          send({ type: "output_chunk", text: `Erreur: ${e.message}\n`, isError: true });
          send({ type: "execution_done", exitCode: 1 });
        });
      }

      // ── Input response ────────────────────────────────────────────────────
      if (msg.type === "input_response" && exec.proc?.stdin && exec.waitingInput) {
        exec.waitingInput = false;
        exec.proc.stdin.write((msg.value as string) + "\n");
      }

      // ── Kill execution ────────────────────────────────────────────────────
      if (msg.type === "kill_execution") {
        if (exec.proc) { try { exec.proc.kill("SIGKILL"); } catch {} exec.proc = null; }
        exec.waitingInput = false;
        exec.buf = "";
        send({ type: "execution_done", exitCode: -1 });
      }

    } catch (e) {
      console.error("[WS] error", e);
    }
  });

  ws.on("close", () => {
    const i = clients.findIndex(c => c.ws === ws);
    if (i !== -1) clients.splice(i, 1);
    if (exec.proc) { try { exec.proc.kill("SIGKILL"); } catch {} }
    if (exec.tmpFile) unlink(exec.tmpFile).catch(() => {});
    if (sessionCode) {
      const count = getSessionClients(sessionCode).length;
      for (const c of getSessionClients(sessionCode)) {
        c.ws.send(JSON.stringify({ type: "user_count", count }));
      }
    }
  });

  ws.on("error", (e) => console.error("[WS]", e));
});

const port = Number(process.env["PORT"] ?? 5000);
server.listen(port, "0.0.0.0", () => {
  console.log(`[Server] http://localhost:${port}`);
  console.log(`[Server] Sessions: in-memory (no DB needed)`);
});
