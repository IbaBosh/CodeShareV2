import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";

const API_URL = (import.meta.env.VITE_API_URL as string | undefined) ?? "";

export interface Session {
  id: number;
  code: string;
  language: string;
  content: string;
  createdAt: string;
  updatedAt: string;
}

export interface SessionInput {
  language: string;
}

async function apiFetch<T>(path: string, options?: RequestInit): Promise<T> {
  const res = await fetch(`${API_URL}${path}`, {
    ...options,
    headers: {
      "Content-Type": "application/json",
      ...options?.headers,
    },
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({ error: res.statusText })) as { error?: string };
    throw new Error(err.error ?? `HTTP ${res.status}`);
  }
  return res.json() as Promise<T>;
}

export const getGetSessionQueryKey = (code: string) => [`/api/sessions/${code}`] as const;

export function useGetSession(
  code: string,
  options?: { query?: { retry?: boolean } }
) {
  return useQuery({
    queryKey: getGetSessionQueryKey(code),
    queryFn: () => apiFetch<Session>(`/api/sessions/${code}`),
    retry: options?.query?.retry ?? false,
    enabled: !!code,
  });
}

export function useCreateSession() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (vars: { data: SessionInput }) =>
      apiFetch<Session>("/api/sessions", {
        method: "POST",
        body: JSON.stringify(vars.data),
      }),
    onSuccess: (session) => {
      queryClient.setQueryData(getGetSessionQueryKey(session.code), session);
    },
  });
}
