import { useState } from "react";
import { useLocation } from "wouter";
import { useCreateSession } from "@/lib/api";
import { useSessionHistory } from "@/hooks/use-session-history";
import { ChevronRight, History, Loader2, Terminal, Zap, Plus } from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import { fr } from "date-fns/locale";

type Language =
  | "python" | "javascript" | "html" | "typescript" | "lua"
  | "java" | "cpp" | "php" | "go" | "rust";

const LANGUAGES = [
  { id: "python",     label: "Python",     color: "#10b981", exec: "Exécution directe",    emoji: "🐍", desc: "Débutant-friendly" },
  { id: "javascript", label: "JavaScript", color: "#eab308", exec: "Exécution navigateur", emoji: "⚡", desc: "Web & Node.js" },
  { id: "html",       label: "HTML / CSS", color: "#f97316", exec: "Aperçu en direct",     emoji: "🌐", desc: "Pages web" },
  { id: "typescript", label: "TypeScript", color: "#06b6d4", exec: "Éditeur avancé",       emoji: "🔷", desc: "JS typé" },
  { id: "lua",        label: "Lua",        color: "#a78bfa", exec: "Éditeur avancé",       emoji: "🌙", desc: "Scripts légers" },
  { id: "java",       label: "Java",       color: "#ef4444", exec: "Éditeur avancé",       emoji: "☕", desc: "Enterprise" },
  { id: "cpp",        label: "C++",        color: "#8b5cf6", exec: "Éditeur avancé",       emoji: "⚙️",  desc: "Performances" },
  { id: "php",        label: "PHP",        color: "#818cf8", exec: "Éditeur avancé",       emoji: "🐘", desc: "Back-end web" },
  { id: "go",         label: "Go",         color: "#22d3ee", exec: "Éditeur avancé",       emoji: "🚀", desc: "Concurrence" },
  { id: "rust",       label: "Rust",       color: "#f59e0b", exec: "Éditeur avancé",       emoji: "🦀", desc: "Mémoire sûre" },
];

export default function Home() {
  const [, setLocation] = useLocation();
  const { history, addSession } = useSessionHistory();
  const createSession = useCreateSession();
  const [joinCode, setJoinCode] = useState("");
  const [isJoining, setIsJoining] = useState(false);
  const [joinError, setJoinError] = useState("");
  const [creatingLang, setCreatingLang] = useState<Language | null>(null);

  const handleCreate = (lang: Language) => {
    setCreatingLang(lang);
    createSession.mutate(
      { data: { language: lang } },
      {
        onSuccess: (session) => {
          addSession({ code: session.code, language: session.language, name: session.name });
          setLocation(`/session/${session.code}`);
        },
        onSettled: () => setCreatingLang(null),
      }
    );
  };

  const handleJoin = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setJoinError("");
    const raw = joinCode.replace(/[^0-9]/g, "");
    if (raw.length !== 10) {
      setJoinError("Le code doit comporter exactement 10 chiffres");
      return;
    }
    setIsJoining(true);
    try {
      const stored = localStorage.getItem(`codeshare_session_${raw}`);
      let session: { code: string; language: string; name?: string };
      if (stored) {
        session = JSON.parse(stored) as { code: string; language: string; name?: string };
      } else {
        // Pas en local — créer un stub pour rejoindre via WebSocket
        const stub = {
          id: Date.now(), code: raw, language: "python", content: "",
          name: `Session ${raw}`,
          createdAt: new Date().toISOString(), updatedAt: new Date().toISOString(),
        };
        localStorage.setItem(`codeshare_session_${raw}`, JSON.stringify(stub));
        session = stub;
      }
      addSession({ code: session.code, language: session.language, name: session.name });
      setLocation(`/session/${session.code}`);
    } finally {
      setIsJoining(false);
    }
  };

  const primary = LANGUAGES.slice(0, 3);
  const extra = LANGUAGES.slice(3);

  return (
    <div className="min-h-[100dvh] bg-[#080810] flex flex-col items-center px-4 pt-8 pb-10 max-w-md mx-auto relative overflow-hidden">
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-80 h-80 bg-violet-600/10 rounded-full blur-3xl pointer-events-none" />

      <div className="flex flex-col items-center gap-3 mb-8 relative">
        <div className="relative">
          <div className="absolute inset-0 bg-violet-500/30 rounded-2xl blur-lg" />
          <div className="relative w-16 h-16 rounded-2xl bg-gradient-to-br from-violet-600 to-indigo-700 flex items-center justify-center shadow-xl border border-violet-400/20">
            <Terminal className="w-8 h-8 text-white" />
          </div>
        </div>
        <div className="text-center">
          <h1 className="text-3xl font-black tracking-tight text-white">CodeShare</h1>
          <p className="text-xs text-zinc-500 mt-0.5 flex items-center justify-center gap-1.5">
            <Zap className="w-3 h-3 text-violet-500" />
            Éditeur collaboratif · 10 langages · IA intégrée
          </p>
        </div>
      </div>

      <div className="w-full mb-5">
        <div className="flex items-center gap-2 mb-3">
          <div className="flex-1 h-px bg-gradient-to-r from-transparent via-white/8 to-transparent" />
          <span className="text-[10px] font-bold text-zinc-600 uppercase tracking-widest flex items-center gap-1">
            <Plus className="w-3 h-3" /> Nouvelle session
          </span>
          <div className="flex-1 h-px bg-gradient-to-r from-transparent via-white/8 to-transparent" />
        </div>

        <div className="space-y-2 mb-3">
          {primary.map((lang) => {
            const isCreating = creatingLang === lang.id;
            return (
              <button
                key={lang.id}
                className="w-full h-[60px] rounded-2xl font-semibold text-white flex items-center gap-3 px-4 transition-all active:scale-[0.98] disabled:opacity-50 relative overflow-hidden group"
                style={{ background: `linear-gradient(135deg, ${lang.color}18 0%, ${lang.color}08 100%)`, border: `1px solid ${lang.color}30` }}
                onClick={() => handleCreate(lang.id as Language)}
                disabled={creatingLang !== null}
              >
                <div className="absolute left-0 top-3 bottom-3 w-0.5 rounded-full" style={{ background: lang.color }} />
                <div className="relative flex items-center gap-3 w-full">
                  {isCreating && <Loader2 className="w-6 h-6 animate-spin shrink-0" style={{ color: lang.color }} />}
                  <div className="text-left flex-1 min-w-0">
                    <div className="font-bold text-sm" style={{ color: lang.color }}>{lang.label}</div>
                    <div className="text-[11px] text-zinc-500 font-normal">{lang.desc}</div>
                  </div>
                  <div className="shrink-0">
                    <span className="text-[10px] px-2 py-1 rounded-lg font-medium" style={{ color: lang.color, background: `${lang.color}18` }}>
                      {lang.exec}
                    </span>
                  </div>
                </div>
              </button>
            );
          })}
        </div>

        <div className="grid grid-cols-4 gap-2">
          {extra.map((lang) => {
            const isCreating = creatingLang === lang.id;
            return (
              <button
                key={lang.id}
                className="h-[72px] rounded-xl flex flex-col items-center justify-center gap-1 transition-all active:scale-[0.96] disabled:opacity-50 relative overflow-hidden group border"
                style={{ background: `linear-gradient(135deg, ${lang.color}15 0%, ${lang.color}06 100%)`, borderColor: `${lang.color}25` }}
                onClick={() => handleCreate(lang.id as Language)}
                disabled={creatingLang !== null}
              >
                {isCreating && <Loader2 className="w-5 h-5 animate-spin relative" style={{ color: lang.color }} />}
                <span className="text-[10px] font-bold relative" style={{ color: lang.color }}>{lang.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      <div className="w-full flex items-center gap-3 mb-5">
        <div className="flex-1 h-px bg-white/5" />
        <span className="text-[10px] text-zinc-700 uppercase tracking-widest">ou rejoindre</span>
        <div className="flex-1 h-px bg-white/5" />
      </div>

      <div className="w-full mb-6">
        <form onSubmit={handleJoin} className="space-y-2">
          <div className="flex gap-2">
            <div className="flex-1 relative">
              <input
                className="w-full h-14 rounded-2xl bg-white/4 border border-white/8 text-white font-mono text-xl text-center tracking-[0.3em] placeholder:text-zinc-800 outline-none focus:border-violet-500/50 focus:bg-violet-500/5 transition-all"
                placeholder="••••••••••"
                value={joinCode}
                onChange={(e) => setJoinCode(e.target.value.replace(/\D/g, "").slice(0, 10))}
                inputMode="numeric"
                type="text"
              />
              {joinCode.length > 0 && joinCode.length < 10 && (
                <div className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-zinc-600 tabular-nums">
                  {joinCode.length}/10
                </div>
              )}
            </div>
            <button
              type="submit"
              className="h-14 px-5 rounded-2xl font-bold text-white bg-gradient-to-r from-violet-600 to-violet-500 hover:from-violet-500 hover:to-violet-400 transition-all active:scale-[0.97] disabled:opacity-50 shadow-lg shadow-violet-900/30"
              disabled={isJoining || joinCode.length !== 10}
            >
              {isJoining ? <Loader2 className="w-5 h-5 animate-spin" /> : "→"}
            </button>
          </div>
          {joinError && (
            <div className="flex items-center gap-2 px-3 py-2 rounded-xl bg-red-500/10 border border-red-500/20">
              <p className="text-red-400 text-xs">{joinError}</p>
            </div>
          )}
        </form>
      </div>

      {history.length > 0 && (
        <div className="w-full">
          <div className="flex items-center gap-2 mb-3">
            <History className="w-3.5 h-3.5 text-zinc-700" />
            <p className="text-[10px] font-bold text-zinc-700 uppercase tracking-widest">Récent</p>
          </div>
          <div className="space-y-1.5">
            {history.slice(0, 6).map((item) => {
              const lang = LANGUAGES.find(l => l.id === item.language);
              const color = lang?.color ?? "#6b7280";
              const displayName = item.name || item.code;
              return (
                <button
                  key={item.code}
                  className="w-full flex items-center gap-3 px-3.5 py-3 rounded-xl bg-white/3 hover:bg-white/6 border border-white/4 hover:border-white/8 transition-all active:scale-[0.99] text-left group"
                  onClick={() => setLocation(`/session/${item.code}`)}
                >
                  <div className="w-8 h-8 rounded-lg flex items-center justify-center shrink-0 text-xs font-bold" style={{ background: `${color}18`, color }}>
                    {item.language.slice(0,2).toUpperCase()}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-semibold text-zinc-300 truncate">{displayName}</p>
                    <p className="text-[10px] mt-0.5" style={{ color: `${color}bb` }}>
                      {item.code} · {formatDistanceToNow(new Date(item.lastAccessed), { addSuffix: true, locale: fr })}
                    </p>
                  </div>
                  <ChevronRight className="w-3.5 h-3.5 text-zinc-700 group-hover:text-zinc-500 transition shrink-0" />
                </button>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}
